DOSSIER — PROGRAMMATION COMPOSITIONNELLE MAILLÉE (NG)
Date : 27 octobre 2026

CONTENU
1. theorie_programation_compositionnelle_2.tex
   Source LaTeX complète de la théorie compositionnelle fournie, conservée comme texte de référence consultable. Corrections typographiques/LaTeX mineures pour compilation et mise en page; le fond du contenu fourni est préservé.

2. formalime_eGenBrain_v4.tex
   Source LaTeX complète du formalisme eGenBrain v4 fourni, conservée comme référence. Les corrections concernent la mise en page des tableaux, les commandes de console et la compilation LaTeX.

3. rapport_et_proposition_th_PC_0.tex
   Rapport critique et proposition de refondation : apports, limites, distinction entre maillage de connaissances et graphe de programme, définition de l'universalité et plan de validation.

4. theorie_programation_compositionnelle_NG_0.tex
   Nouvelle théorie générale de programmation compositionnelle maillée : noyau universel, contrats, types et effets, maillage multi-couches, sémantique opérationnelle, résultats et preuves conditionnelles, expressivité relative, compilation, sécurité, résilience, mémoire, recherche, ASCRC, interfaces et protocole d'évaluation.

PDF
Les quatre PDF portent les mêmes noms de base que les fichiers .tex. Ils sont fournis comme rendus consultables des sources.

VALIDATION EFFECTUÉE
- Compilation LaTeX par pdfLaTeX avec arrêt à la première erreur, puis seconde compilation pour la table des matières/références.
- Comptage des environnements begin/end équilibré dans les quatre sources.
- Contrôle des avertissements de débordement de ligne et références/citations LaTeX non résolues dans les compilations finales.
- Rendu des PDF en images et inspection visuelle par échantillonnage de pages.

PORTÉE ET RÉSERVE
Les seuls matériaux eGenBrain disponibles pour cette tâche étaient les documents textuels insérés dans la demande. Les résultats chiffrés et descriptions d'implémentation qu'ils rapportent sont conservés comme affirmations des sources, mais le runtime, les archives, les tests et le registre de preuves eGenBrain n'ont pas été fournis ici et n'ont donc pas été réexécutés ni audités indépendamment. La théorie NG distingue en conséquence les preuves mathématiques sous hypothèses, les obligations d'implémentation et les affirmations qui doivent être évaluées empiriquement.

COMPILATION
Pour chaque source :
  pdflatex -interaction=nonstopmode -halt-on-error <nom_du_fichier>.tex
  pdflatex -interaction=nonstopmode -halt-on-error <nom_du_fichier>.tex
