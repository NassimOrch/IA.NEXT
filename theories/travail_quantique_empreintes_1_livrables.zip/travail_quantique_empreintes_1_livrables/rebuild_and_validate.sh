#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
python3 validation/algebraic_checks_1.py
python3 quantum_observation_model_1.py
python3 quantum_observation_extension_1.py
python3 validation/theorem_scope_audit_1.py
mkdir -p validation/build_clean
for n in 1 2 3 4 5; do
  pdflatex -interaction=nonstopmode -halt-on-error \
    -output-directory=validation/build_clean th_emp_quantique_dev_1.tex \
    > "validation/pdflatex_clean_pass${n}.log" 2>&1
  if grep -Eq '^! |LaTeX Error:|Undefined control sequence|Emergency stop' \
      "validation/pdflatex_clean_pass${n}.log"; then
    echo "Compilation pdflatex numéro ${n} en échec" >&2
    exit 1
  fi
done
cp validation/build_clean/th_emp_quantique_dev_1.pdf th_emp_quantique_dev_1.pdf
python3 validation/verify_delivery_1.py
