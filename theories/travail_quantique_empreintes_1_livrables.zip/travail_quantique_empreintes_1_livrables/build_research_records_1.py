from pathlib import Path
import json, hashlib, zipfile, datetime, re
ROOT=Path('/mnt/data/travail_quantique_empreintes_1')
PREV=Path('/mnt/data/travail_quantique_empreintes_livraison')

def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def dump(name,obj):
    (ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

src_emp=ROOT/'sources/DDD_Base_theorie_des_empreintes_complete_order_5.tex'
src_obs=ROOT/'sources/NGeGenBrain_observation_formalisme_full_0.tex'
src_zip=ROOT/'sources/observation_formalisme_full_0_bundle.zip'
src_audit=ROOT/'sources/audit_NGeGenBrain_observation_formalisme_full_0.md'
archive=Path('/mnt/data/Nouveau dossier.zip')
source_manifest={
  'title':'Manifeste des sources et de la provenance — développement quantique 1',
  'date':'2026-11-07',
  'original_archive':{'path_as_received':str(archive),'sha256':sha(archive),'zip_test':'PASS','extracted_file_count':1904,'extracted_size_bytes':84342510},
  'primary_sources':[
    {'id':'SRC-EMP-001','path_in_original_archive':'Nouveau dossier/theories/DDD_Base_theorie_des_empreintes_complete_order_5.tex','local_copy':'sources/DDD_Base_theorie_des_empreintes_complete_order_5.tex','sha256':sha(src_emp),'bytes':src_emp.stat().st_size,'identical_copy_count_in_archive':8,'duplicate_sha256_verified_in_iteration_0':True,'key_locations':[
      {'lines':'110-169','topic':'empreintes, équivalence, fibres, quotients et raffinement'},
      {'lines':'900-940','topic':'seuils, mesure sur les paires, perte de l’affectation paire-seuil et règle uniforme des branches'},
      {'lines':'2167-2216','topic':'principe de descente/commutation et limites de portée'},
      {'lines':'3021-3307','topic':'chat de Naszimger et raffinement observationnel'},
      {'lines':'3308-3451','topic':'double résolution et analogie double fente avec avertissement explicite de non-déduction physique'}]},
    {'id':'SRC-OBS-001','path_in_original_archive':'Nouveau dossier/sondes_experiences/sonde_adapt_1_bundle/observation/NGeGenBrain_observation_formalisme_full_0.tex','local_copy':'sources/NGeGenBrain_observation_formalisme_full_0.tex','sha256':sha(src_obs),'bytes':src_obs.stat().st_size,'key_locations':[
      {'lines':'182-225','topic':'objets, contextes, sondes, Phi et noyaux stochastiques Q_f'},
      {'lines':'226-304','topic':'empreintes, équivalence, fibres, quotients et factorisation'},
      {'lines':'780-833','topic':'facettes observationnelles et empreintes multi-vues'},
      {'lines':'1010-1048','topic':'mécanisme stochastique et noyau conjoint L'},
      {'lines':'1261-1308','topic':'abstraction stochastique et composition synchrone'}]},
    {'id':'SRC-OBS-BUNDLE-001','path_in_original_archive':'Nouveau dossier/theories/observation_formalisme_full_0_bundle.zip','local_copy':'sources/observation_formalisme_full_0_bundle.zip','sha256':sha(src_zip),'bytes':src_zip.stat().st_size,'zip_test':'PASS'},
    {'id':'SRC-OBS-AUDIT-001','path_in_original_archive':'Nouveau dossier/sondes_experiences/sonde_adapt_1_bundle/observation/audit_NGeGenBrain_observation_formalisme_full_0.md','local_copy':'sources/audit_NGeGenBrain_observation_formalisme_full_0.md','sha256':sha(src_audit),'bytes':src_audit.stat().st_size,'role':'audit documentaire secondaire ; aucune affirmation mathématique n’est promue sur sa seule autorité'}
  ],
  'previous_iteration':{
    'folder':'/mnt/data/travail_quantique_empreintes_livraison',
    'artifacts':{f.name:sha(f) for f in [PREV/'checklist_travail_0.json',PREV/'laboratoire_0.json',PREV/'laboratoire_next_0.json',PREV/'prouve_th_emp_quantique_dev_.json',PREV/'th_emp_quantique_dev_0.tex',PREV/'th_emp_quantique_dev_0.pdf']},
    'continuity_note':'La version 1 prolonge et conserve l’itération 0 ; elle ne réécrit pas son historique.'
  },
  'scope_note':'Les sources primaires restent les deux traités et le bundle cités. Les objets J, POVM, complétion des effets, représentation de Born et conséquences quantiques sont des extensions construites dans ce manuscrit, non des citations rétrospectives attribuées aux auteurs des sources.'
}
dump('source_manifest_1.json',source_manifest)

attempts=[
('LAB-001','Inférer Born directement de mu_P','REJECTED','mu_P est une mesure de seuils de paires et perd l’affectation paire-seuil ; sa nature et son type ne sont pas ceux d’une loi de résultats de mesure.','DDD_Base lignes 919-940.'),
('LAB-002','Utiliser la loi uniforme de branche |B|/|A|','VALID_BUT_LIMITED','Elle est démontrée lorsque l’échantillonnage uniforme est déclaré ; elle reste une loi de cardinalité de branche, non une loi quadratique de résultat quantique.','DDD_Base lignes 932-940.'),
('LAB-003','Utiliser la loi quadratique pairielle C(|B|,2)/sum C(|B_j|,2)','PROMOTED_LIMITED','La sélection uniforme de paires ayant deux éléments dans une même fibre donne cette loi ; sous proportions positives stables, la limite est proportionnelle au carré. Elle concerne les paires conditionnées et non les issues d’un système unique.','Itération 0 ; preuve reprise dans laboratoire_next_1.'),
('LAB-004','Faire sortir une phase d’une chaîne emboîtée','REJECTED','Les sous-espaces sont emboîtés et les projections conditionnelles commutent ; leur commutateur est nul.','Théorème de raffinement dérivé de DDD_Base et des facettes d’observation.'),
('LAB-005','Construire une circulation par facettes incomparables','PROMOTED_CONDITIONAL','La somme des commutateurs adjacents d’un itinéraire ordonné est réelle et antisymétrique ; elle détecte une incompatibilité d’ordre entre projections.','Observation, facettes lignes 780-833 ; preuve exacte dans le chapitre 4.'),
('LAB-006','Prendre la décomposition polaire pour obtenir J','PROMOTED_LOCAL','Pour C réel antisymétrique, J=-C(-C²)^(-1/2) sur ran C vérifie J²=-I sur le support. J est partiel et non global si C a un noyau.','Preuve fonctionnelle finie dans le chapitre 4.'),
('LAB-007','Supposer que J est indépendant de l’ordre des facettes','REJECTED','Le renversement change J en -J ; une autre permutation peut changer le support. Le caractère global exige une condition de recollement/holonomie explicite.','Contre-modèle numérique dans model_checks_1.json.'),
('LAB-008','Utiliser les directions réelles seules comme états complexes','REJECTED_INCOMPLETE','Sans une quadrature Jv et un secteur J invariant, aucun paramètre de phase relatif n’est représenté.','Construction du produit hermitien au chapitre 4.'),
('LAB-009','Construire les projecteurs complexes par paire quadrature (v,Jv)','PROMOTED','Le projecteur réel sur span_R{v,Jv} commute avec J et devient un projecteur complexe de rang un.','Lemme du chapitre 7.'),
('LAB-010','Compresser les événements de cellule sur le secteur K','PROMOTED','Pi Q_D Pi est positif ; la somme des compressions sur une partition et son complément vaut Pi.','Preuve de compression au chapitre 6.'),
('LAB-011','Moyenner les effets sur U_theta=cos(theta)I+sin(theta)J','PROMOTED','La moyenne de conjugaison préserve positivité, force la J-linéarité et conserve la normalisation.','Théorème POVM au chapitre 6.'),
('LAB-012','Supprimer le résidu anti-J-linéaire','REJECTED','Le résidu renseigne sur la dépendance au choix d’orientation de phase ; l’effacer cacherait une donnée contextuelle.','Remarque du chapitre 6.'),
('LAB-013','Supposer la complétude des profils','REJECTED_AS_GENERAL_CLAIM','Un ensemble de sondes non séparant laisse des directions non identifiables. Dans l’exemple synthétique à cinq contextes, le rang projeté vaut 8/8.','Test numérique ; condition explicite au chapitre 7.'),
('LAB-014','Utiliser Q_f pour obtenir la probabilité sans le confondre avec Phi','PROMOTED','Le traité distingue bien les lois Q_f des valeurs déterministes Phi ; Q_f apporte les réponses probabilistes, mais leurs lois doivent être comparées.','Observation lignes 182-225.'),
('LAB-015','Supposer Q_f déterminé par Phi','REJECTED','Deux noyaux de mesure différents peuvent accompagner la même application d’observation déterministe ; il faut conserver Q_f comme donnée empirique.','Contre-modèles de l’itération 0 ; source observationnelle.'),
('LAB-016','Faire descendre Q_f sur l’effet','PROMOTED_AS_REQUIRED_COMPLETION','Deux implémentations de même effet doivent avoir la même loi de sortie ; sinon l’effet ne résume pas le protocole et il faut enrichir l’empreinte par le contexte résiduel.','Condition nouvelle explicitée au chapitre 8.'),
('LAB-017','Obtenir additivité et convexité des probabilités','PROMOTED','L’additivité suit du regroupement des sorties d’un noyau de probabilité ; l’affinité suit de la randomisation des mécanismes/protocoles.','Définition Q_f et composition probabiliste.'),
('LAB-018','Dériver un fonctionnel linéaire sur les matrices hermitiennes','PROMOTED','Définir L_+(A)=t m(A/t), prouver l’indépendance de t, puis additivité et extension par parties positives.','Preuve complète du théorème Born au chapitre 8.'),
('LAB-019','Dériver une matrice d’état positive de trace un','PROMOTED','Le dual de l’espace fini des hermitiens et la positivité de L fournissent un unique rho>=0, Tr rho=1.','Preuve complète du théorème Born au chapitre 8.'),
('LAB-020','Dériver Born pour projecteurs quadratures','PROMOTED_CONDITIONAL','Tr(rho |phi><phi|)=|<phi,psi>|² pour une préparation pure ; la règle quadratique n’est pas introduite dans les prémisses du théorème.','Théorème Born, chapitre 8.'),
('LAB-021','Dériver les franges de deux chemins','PROMOTED_CONDITIONAL','La superposition de profils complexes dans un secteur J recolé donne le terme croisé par développement de la norme au carré issue de Born.','Chapitre 9.'),
('LAB-022','Représenter la mémoire du détecteur par son recouvrement','PROMOTED_CONDITIONAL','La trace partielle produit un terme hors-diagonale multiplié par gamma=<D_R,D_L> ; la visibilité décroît avec |gamma|.','Chapitre 9 et tests numériques.'),
('LAB-023','Construire un groupe de Koopman','PROMOTED_CONDITIONAL','Une bijection T_t qui préserve la mesure induit un opérateur unitaire ; la forte continuité est une condition additionnelle vérifiable.','Définition de mécanisme et trajectoires ; chapitre 10.'),
('LAB-024','Obtenir Schrödinger par Stone','PROMOTED_CONDITIONAL','Le générateur d’un groupe unitaire fortement continu J-linéaire est auto-adjoint, à calibration des unités près.','Théorème de Stone appliqué au groupe observé ; chapitre 10.'),
('LAB-025','Dériver CCR à partir d’une action de translation','PROMOTED_CONDITIONAL','La covariance U_a* X U_a=X+aI puis la dérivation donne [X,P]=hbar J sur un domaine commun.','Preuve du chapitre 11.'),
('LAB-026','Réprésenter CCR dans un espace fini','REJECTED_BY_TRACE','Trace([X,P])=0 alors que trace(hbar J) ne s’annule pas en représentation complexe finie non nulle ; la représentation canonique demande un cadre infini et des domaines.','Théorème d’obstruction du chapitre 11.'),
('LAB-027','Dériver l’incertitude','PROMOTED','Cauchy-Schwarz sur les vecteurs centrés donne la borne de Robertson, et CCR entraîne Delta X Delta P>=hbar/2.','Chapitre 12.'),
('LAB-028','Composer deux secteurs d’observation','PROMOTED_CONDITIONAL','Le produit tensoriel complexe équilibré est dérivé de la composition synchrone et d’une orientation J compatible.','Chapitre 13.'),
('LAB-029','Dériver absence de signalisation','PROMOTED','La somme des effets de Bob égale l’identité ; marginaliser Bob élimine son choix de réglage.','Preuve du chapitre 13.'),
('LAB-030','Dériver CHSH/Tsirelson','PROMOTED','La borne classique 2 suit des affectations ±1 ; l’identité opératorielle et les normes des commutateurs donnent 2sqrt(2).','Chapitre 13 et validation numérique.'),
('LAB-031','Dériver mise à jour de Lüders','PROMOTED_WITH_SCOPE','La projection normalisée minimise la distance au profil d’origine dans le sous-espace projeté ; c’est une règle de perturbation minimale, pas tout instrument possible.','Chapitre 14.'),
('LAB-032','Dériver la forme de Kraus','PROMOTED_CONDITIONAL','La positivité sous toute composition auxiliaire équivaut à la positivité de Choi ; la diagonalisation fournit les opérateurs de Kraus.','Chapitre 14.'),
('LAB-033','Faire comme si les probabilités synthétiques étaient expérimentales','REJECTED','La tomographie du script génère ses q à partir du rho voulu ; elle teste la reconstruction linéaire, non la théorie physique.','Validation/model_checks_1.json.'),
('LAB-034','Déclarer le recollement global acquis sur l’exemple','REJECTED','La permutation alternative des contextes change support et J ; la condition globale reste non satisfaite dans l’exemple.','model_checks_1.json : path_alternate_support_difference et path_alternate_J_difference.')
]
lab={
 'title':'Laboratoire exploratoire 1 — essais, pistes, contre-exemples et décisions',
 'iteration':1,'date':'2026-11-07','policy':'Ce fichier conserve les tentatives, y compris les voies rejetées. Aucun essai n’est transformé en résultat prouvé sans promotion explicite vers laboratoire_next_1.json et une entrée correspondante dans le registre de preuves.',
 'attempt_count':len(attempts),
 'attempts':[{'id':a,'idea':b,'status':c,'finding':d,'basis':e} for a,b,c,d,e in attempts],
 'outbox':[
   {'id':'OUT-01','idea':'Remplacer l’itinéraire par une somme sur toutes les permutations de contextes.','status':'REJECTED_FOR_PHASE_GENERATION','reason':'La symétrisation annule la partie antisymétrique ou efface l’information d’ordre ; elle ne choisit pas une orientation de phase.'},
   {'id':'OUT-02','idea':'Définir J à partir d’un seul commutateur P_cP_d-P_dP_c.','status':'RETAINED_AS_MINIMAL_TWO_CONTEXT_CASE','reason':'Suffit dans certains exemples, mais peut avoir un support trop petit ; la somme le long d’un itinéraire accroît le secteur observable.'},
   {'id':'OUT-03','idea':'Utiliser seulement la mesure scalaire mu_P pour reconstruire toutes les paires.','status':'REJECTED','reason':'La source indique explicitement que mu_P perd l’étiquette de la paire.'},
   {'id':'OUT-04','idea':'Identifier toute matrice rho reconstruite numériquement comme état physique.','status':'REJECTED','reason':'Les données du test sont synthétiques ; il manque un noyau Q_f mesuré sur un dispositif réel.'},
   {'id':'OUT-05','idea':'Présenter hbar comme une valeur dérivée des empreintes.','status':'REJECTED','reason':'La structure CCR fixe la forme du commutateur, mais pas l’échelle dimensionnelle énergie-temps ; celle-ci requiert une calibration.'}
 ],
 'summary':'34 pistes consignées : 20 voies promues sous conditions ou avec portée limitée, 14 rejetées ou conservées comme outbox/contre-exemples. Les statuts précis sont dans chaque entrée.'
}
dump('laboratoire_1.json',lab)

promoted=[
('RN-001','Espace réel des profils de paires','PROVED','Dérivé de l’ensemble des paires et de la mesure de dénombrement pré-poussée en avant qui normalise mu_P.','th_emp_quantique_dev_1.tex, chapitre 3.'),
('RN-002','Projection orthogonale par cellule d’empreinte de paire','PROVED','L’opérateur de moyenne conditionnelle est l’unique projection orthogonale sur les fonctions constantes par fibre.','chapitre 3.'),
('RN-003','Commutation des projections emboîtées','PROVED','Le raffinement des partitions induit une inclusion des sous-espaces et les projections emboîtées commutent.','chapitre 3.'),
('RN-004','Circulation d’un itinéraire de facettes','PROVED_AS_CONSTRUCTION','Somme des commutateurs adjacents ; elle est antisymétrique et encode une dépendance à l’ordre.','chapitre 4.'),
('RN-005','Structure complexe polaire locale J','PROVED','J=-C(-C²)^(-1/2) sur ran C satisfait J²=-I et les identités de polarisation.','chapitre 4.'),
('RN-006','Produit hermitien dérivé','PROVED','La métrique réelle et J définissent h=g+i g(J·,·), hermitien positif et linéaire dans le second argument.','chapitre 4.'),
('RN-007','Recollement global des phases','REQUIRED_GATE_NOT_PASSED','Nécessaire pour un secteur global ; le test de permutation montre qu’il ne peut être supposé.','chapitre 4 et contre-modèle.'),
('RN-008','Effets positifs par compression et twirl de phase','PROVED_CONDITIONALLY_ON_J','Compression des projecteurs de cellules et moyenne de conjugaison U_theta produisent une POVM J-linéaire.','chapitre 6.'),
('RN-009','Projecteurs de rang un par quadrature','PROVED','Le plan réel span(v,Jv) est une droite complexe et son projecteur est de rang complexe un.','chapitre 7.'),
('RN-010','Fermeture en POVM arbitraires','PROVED_IN_FINITE_DIMENSION','La complétion quadrature produit les projecteurs spectraux ; randomisation réalise les effets ; Naimark réalise toute POVM finie par composition avec mémoire.','chapitre 7.'),
('RN-011','Descente stochastique par effet','CONDITION_REQUIRED_AND_TESTABLE','Les lois Q doivent être identiques pour des implémentations d’un même effet ; sinon il faut enrichir les facettes et refuser l’identification par effet seul.','chapitre 8.'),
('RN-012','Affinité et additivité de la réponse probabiliste','DERIVED_FROM_STOCHASTIC_KERNEL_AND_PROTOCOL_MIXTURE','La normalisation, le regroupement et le mélange donnent l’homogénéité et l’additivité sur les effets.','chapitre 8.'),
('RN-013','Représentation de Born','PROVED_CONDITIONALLY','Le fonctionnel positif additif se représente par une matrice rho positive de trace un ; Born suit pour les projecteurs quadratures.','théorème du chapitre 8.'),
('RN-014','Interférence à deux branches','PROVED_FROM_BORN','Le terme croisé de |alpha a_L+beta a_R|² est la phase relative observable.','chapitre 9.'),
('RN-015','Décohérence par mémoire du détecteur','PROVED_WITH_PARTIAL_TRACE_MODEL','Le recouvrement des états mémoire multiplie la cohérence et détermine la visibilité.','chapitre 9.'),
('RN-016','Groupe unitaire observationnel','PROVED_UNDER_REVERSIBILITY_MEASURE_PRESERVATION','Le transport de Koopman d’une bijection préservant la mesure est unitaire.','chapitre 10.'),
('RN-017','Équation de Schrödinger','PROVED_UNDER_STRONG_CONTINUITY_AND_J_COVARIANCE','Stone produit un générateur auto-adjoint ; la conversion hbar demeure une calibration d’unités.','chapitre 10.'),
('RN-018','Relation canonique de translation','PROVED_ON_COMMON_DENSE_DOMAIN','Une translation observationnelle x(T_a z)=x(z)+a, représentée par groupe unitaire quasi-invariant fortement continu, entraîne [X,P]=hbar J.','chapitre 11.'),
('RN-019','Obstruction CCR en dimension finie','PROVED','La trace d’un commutateur matriciel est nulle ; CCR exact non nul impossible en dimension finie.','chapitre 11.'),
('RN-020','Inégalité de Robertson','PROVED','Cauchy-Schwarz sur les vecteurs centrés donne Delta A Delta B >= |<[A,B]>|/2.','chapitre 12.'),
('RN-021','Composition tensorielle et non-signalisation','PROVED_CONDITIONALLY_ON_COMPATIBLE_PHASE_GLUE','La composition synchrone induit le produit tensoriel complexe ; la normalisation des POVM garantit les marges indépendantes du réglage distant.','chapitre 13.'),
('RN-022','Borne CHSH/Tsirelson','PROVED_IN_OPERATOR_MODEL','Affectations déterministes donnent 2 ; identité de S² et bornes de commutateurs donnent 2sqrt(2), atteint par exemple Bell.','chapitre 13.'),
('RN-023','Mise à jour de Lüders minimale','PROVED_FOR_LEAST_DISTANCE_CRITERION','La projection normalisée est le profil conditionné le plus proche dans le sous-espace retenu ; les autres instruments restent possibles.','chapitre 14.'),
('RN-024','Forme de Kraus des canaux CP','PROVED_FINITE_DIMENSION','La positivité sous ancilla équivaut à Choi positif ; factorisation spectrale fournit Kraus.','chapitre 14.'),
('RN-025','Exemple exact à trois objets','EXACT_SYMBOLIC','Deux partitions croisées donnent rang 2, un plan complexe, J²=-Pi et |C|=sqrt(3)/4 Pi.','validation/algebraic_checks_1.json.'),
('RN-026','Exemple cinq objets / quatre dimensions complexes','EXACT_SPECTRUM_PLUS_NUMERICAL_RANK_VALIDATION','Polynôme exact de -C² donne rang 8 ; indicatrices projetées rang 8 ; 34 effets rang hermitien 16.','validation/algebraic_checks_1.json et model_checks_1.json.'),
('RN-027','Limite quadratique pairielle de l’itération 0','PROVED_WITH_SCOPE','La sélection uniforme de paires internes à une même fibre donne un poids proportionnel aux carrés des proportions dans une limite de croissance.','itération 0, laboratory_next_0 ; reprise dans laboratory_1 LAB-003.')
]
ln={
 'title':'Laboratoire_next_1 — résultats promus, développés et réaudités',
 'iteration':1,'date':'2026-11-07','promotion_policy':'Ne contient que des résultats démontrés, des constructions mathématiques avec hypothèses explicites, ou des conditions requises ; les conditions non satisfaites restent qualifiées comme telles.',
 'result_count':len(promoted),
 'results':[{'id':a,'name':b,'status':c,'statement':d,'location':e} for a,b,c,d,e in promoted],
 'global_assessment':{
   'born':'La représentation de Born est démontrée dans le secteur complexe local lorsque les profils sont complets, que tous les effets finis sont réalisables, que Q descend sur les effets et que les lois répondent à normalisation, regroupement et mélange. Les seules empreintes déterministes ne déterminent pas Q.',
   'phase':'J est mathématiquement construit sur le support de la circulation d’un itinéraire. Un unique J global n’est pas acquis ; le recollement des phases demeure une porte explicite.',
   'physical_status':'Aucune donnée Q_f acquise sur un dispositif physique quantique, ni test expérimental de recollement de phase, n’est fournie par les trois sources primaires conservées. Les résultats numériques sont synthétiques.'
 },
 'unresolved_gates':[
   {'id':'GATE-J-GLOBAL','required':'Démontrer ou mesurer le recollement des structures J sur tous les itinéraires admissibles et cycles de facettes.','status':'OPEN','reason':'La permutation alternative du modèle synthétique change le support et J.'},
   {'id':'GATE-Q-EMPIRICAL','required':'Acquérir les noyaux Q_f bruts pour plusieurs implémentations d’un même effet et tester leur égalité.','status':'OPEN_NO_PHYSICAL_Q_DATA_IN_SOURCE_SET'},
   {'id':'GATE-POVM-REALIZATION','required':'Montrer que la fermeture quadrature et les POVM sont réalisables par les mécanismes/sondes physiques étudiés.','status':'OPEN'},
   {'id':'GATE-CONTINUUM','required':'Construire une limite de résolution et une action continue quasi-invariante observées, avec domaines pour opérateurs non bornés.','status':'OPEN'},
   {'id':'GATE-HBAR','required':'Calibrer le générateur temporel contre l’énergie et les unités physiques.','status':'OPEN'},
   {'id':'GATE-PHYSICAL-TEST','required':'Préenregistrer puis comparer les prédictions interférence, décohérence, statistiques et corrélations à des données physiques.','status':'OPEN'}
 ]
}
dump('laboratoire_next_1.json',ln)

phases=[
 {'id':'F0','name':'Provenance et audit des sources','status':'COMPLETE','dependencies':[],'exit_gate':{'passed':True,'evidence':'Hachages SHA-256 enregistrés ; archive originale CRC ; trois sources primaires et huit duplicatas DDD_Base vérifiés dans l’itération précédente.'}},
 {'id':'F1','name':'Construire la géométrie réelle des paires et les projections d’observation','status':'COMPLETE','dependencies':['F0'],'exit_gate':{'passed':True,'evidence':'Définitions et preuves des chapitres 2-3 : mesure nu2, espace L2, empreinte de paire, projection conditionnelle, raffinement et commutation.'}},
 {'id':'F2','name':'Construire la phase locale à partir des facettes incompatibles','status':'COMPLETE_LOCAL_ONLY','dependencies':['F1'],'exit_gate':{'passed':True,'scope':'local à un itinéraire gamma','evidence':'Antisymétrie de C_gamma, polarisation, J²=-Pi et produit hermitien démontrés. Le statut ne signifie pas que J est global.'}},
 {'id':'F3','name':'Construire les effets et la complétion quadrature','status':'COMPLETE_CONDITIONAL','dependencies':['F2'],'exit_gate':{'passed':True,'conditions':['profils d’événements complets sur le secteur K','réalisation ou fermeture déclarée des quadratures','symétrisation de phase du protocole'],'evidence':'POVM et projecteurs complexes de rang un démontrés ; Naimark et réalisation finite dimension expliqués.'}},
 {'id':'F4','name':'Démontrer la représentation de Born','status':'COMPLETE_CONDITIONAL','dependencies':['F3'],'exit_gate':{'passed':True,'conditions':['descente stochastique Q_f par effet','noyaux probabilistes normalisés','additivité de regroupement','affinité sous randomisation/mélange','couverture de tous les effets finis'],'evidence':'Théorème de représentation du chapitre 8 avec démonstration complète de L_+ et rho.'}},
 {'id':'F5','name':'Dériver interférence, décohérence, dynamique, incertitude, composition et canaux','status':'COMPLETE_WITH_EXPLICIT_HYPOTHESES','dependencies':['F4'],'exit_gate':{'passed':True,'conditions':['J compatible avec les transformations temporelles et composites','forte continuité pour Stone','domaines communs pour CCR et observables non bornés','mécanismes CP pour Kraus'],'evidence':'Chapitres 9-14 ; identités et démonstrations dans le manuscrit ; exemples numériques vérifiés.'}},
 {'id':'F6','name':'Tester le recollement global de phase','status':'NOT_PASSED_OPEN','dependencies':['F2'],'exit_gate':{'passed':False,'evidence':'Le modèle synthétique montre qu’une permutation admissible peut changer le support et J. Aucun recollement global n’est donc présumé.'}},
 {'id':'F7','name':'Construire et valider une limite continue physique','status':'OPEN_DATA_AND_REGULARITY','dependencies':['F5','F6'],'exit_gate':{'passed':False,'missing':['dossiers Q_f physiques bruts','preuves expérimentales de quasi-invariance et forte continuité','calibration énergie-temps / hbar','tests sur une famille complète de mesures']}},
 {'id':'F8','name':'Cinq passes de vérification documentaire et mathématique','status':'COMPLETE','dependencies':['F0','F1','F2','F3','F4','F5'],'exit_gate':{'passed':True,'evidence':'Validation de provenance, algèbre symbolique, audit des hypothèses, tests numériques, compilation/rendu PDF et intégrité de livraison.'}}
]
checklist={
 'title':'Checklist de travail — développement quantique 1', 'iteration':1,'date':'2026-11-07',
 'governance':'Aucune phase n’est déclarée complète si sa preuve ou ses conditions de sortie ne sont pas présentes. Les constructions locales et conditionnelles sont distinguées des validations globales et physiques. Une phase ouverte n’autorise pas à déclarer sa propriété cible acquise.',
 'phase_count':len(phases),'phases':phases,
 'overall_result':'Reconstruction mathématique conditionnelle construite : Born et plusieurs mécanismes quantiques sont démontrés dans un secteur complexe observationnel complété. L’identification d’un secteur global et la validation physique restent ouvertes faute de données Q_f physiques et de preuve de recollement/continuité.'
}
dump('checklist_travail_1.json',checklist)

proofs=[
('PROOF-101','Le produit scalaire L2 sur les paires est positif défini et de dimension binom(|X|,2).','PROVED','SRC-EMP-001 ligne 919 ; le dénombrement pré-pushforward normalise mu_P.','Chapitre 3, théorème Construction réelle.',['X fini, |X|>=2','nu2 uniforme strictement positive sur Omega2(X)'],'Si f non nul, f(omega) non nul pour une paire omega, donc somme nu2 f²>0. Les indicatrices des singletons forment une base.'),
('PROOF-102','La moyenne conditionnelle sur les fibres est la projection orthogonale de L2 sur les profils constants.','PROVED','SRC-EMP-001 lignes 110-169 ; SRC-OBS-001 lignes 226-304.','Chapitre 3, théorème Projection d’observation.',['Partition finie des paires','Mesure finie strictement positive sur chaque fibre'],'La différence f-P_cf est orthogonale à toute fonction constante sur chaque fibre ; P_cf appartient à cet espace.'),
('PROOF-103','Des partitions emboîtées induisent des projections qui commutent.','PROVED','Raffinement monotone de SRC-EMP-001 et SRC-OBS-001.','Chapitre 3, lemme Raffinement des partitions.',['V_c inclus dans V_cprime'],'Propriété générale des projections orthogonales sur sous-espaces emboîtés.'),
('PROOF-104','La circulation C_gamma est antisymétrique.','PROVED','Facettes multi-vues de SRC-OBS-001 lignes 780-833.','Chapitre 4, lemme Antisymétrie.',['P_c autoadjoints','Itinéraire fini déclaré'],'Chaque commutateur de deux projections autoadjointes est skew-adjoint ; la somme l’est.'),
('PROOF-105','La polarisation de C_gamma donne J²=-Pi sur le support.','PROVED_FINITE_DIMENSION','Construction extension à partir de projections ; aucun J n’est posé en source.','Chapitre 4, théorème Structure complexe polaire.',['C réel skew-adjoint','Calcul spectral de -C² sur son support'],'C commute avec -C² et son inverse racine ; J²=C²(-C²)^-1=-Pi.'),
('PROOF-106','La forme h=g+i g(J.,.) est un produit hermitien positif.','PROVED','Conséquence de PROOF-105 et du produit pairiel réel.','Chapitre 4, proposition Produit hermitien construit.',['J orthogonal et J²=-I sur K'],'Vérification de symétrie hermitienne, linéarité en second argument et h(v,v)=g(v,v)>0.'),
('PROOF-107','La structure J dépend de l’itinéraire et nécessite un recollement global.','COUNTERMODEL_VERIFIED','SRC-OBS-001 reconnaît des vues multiples non indépendantes ; contre-modèle construit dans script.','Chapitre 4 ; validation/model_checks_1.json.',['Exemple fini donné'],'Renversement donne -J ; permutation différente donne un support et un opérateur J différents.'),
('PROOF-108','La compression puis la moyenne de phase d’une famille PVM donne une POVM positive J-linéaire.','PROVED','Projections des fibres issues des empreintes de la source.','Chapitre 6, théorème Effets issus d’une partition de paires.',['Structure complexe locale J','Partition finie et complément'],'Compression préserve positivité ; moyenne d’unitaires préserve positivité ; la somme des effets vaut identité.'),
('PROOF-109','Le plan réel span(v,Jv) est un projecteur complexe de rang un.','PROVED','Construction quadrature de sondes au chapitre 7.','Chapitre 7, lemme Projecteur quadrature.',['v unitaire dans K'],'v et Jv sont orthonormés ; J laisse leur plan invariant ; réel rang 2 équivaut à complexe rang 1.'),
('PROOF-110','La fermeture quadrature, spectrale et par mémoire réalise toute POVM finie en dimension finie.','PROVED_FINITE_DIMENSION','Composition synchrone source SRC-OBS-001 lignes 1261-1308 ; construction nouvelle.','Chapitre 7, section De projecteurs aux effets et aux POVM.',['Tous profils v accessibles','Randomisation/acceptation classique disponible','Mémoire de résultat composée'],'Décomposition spectrale réalise tout effet ; l’isométrie Vψ=sum_k sqrt(E_k)ψ tensor |k> donne Naimark et le calcul V*P_kV=E_k.'),
('PROOF-111','Sous les conditions opérationnelles explicites, la réponse probabiliste s’étend en fonctionnelle positive linéaire.','PROVED_CONDITIONAL','SRC-OBS-001 lignes 182-225 : Q_f est noyau stochastique ; composition/mélange explicités.','Chapitre 8, preuve du théorème Born.',['Descente Q par effet','Normalisation et positivité','Regroupement','Mélange affine','Tous les effets finis disponibles'],'L_+(A)=t m(A/t) est indépendant de t, homogène et additive sur le cône positif ; extension Jordan donne L linéaire réel sur les hermitiens.'),
('PROOF-112','Toute fonctionnelle positive normalisée sur les hermitiens finis est Tr(rho .) avec rho>=0, Tr rho=1.','PROVED','Dualité de l’espace fini des hermitiens ; preuve donnée sans postuler Born.','Chapitre 8, théorème de représentation.',['Dimension complexe finie','L réel-linéaire positif et L(I)=1'],'Riesz/trace pairing donne rho unique ; L(|v><v|)>=0 donne rho positif ; L(I)=1 donne trace un.'),
('PROOF-113','Pour un état pur, la représentation donne |<phi,psi>|².','PROVED_CONDITIONAL','Suit de PROOF-111/112 et projecteur quadrature PROOF-109.','Chapitre 8, fin de preuve du théorème Born.',['rho=|psi><psi|','E=|phi><phi|'],'Tr(rho E)=<phi,psi><psi,phi>=|<phi,psi>|².'),
('PROOF-114','Born produit le terme croisé d’interférence pour deux branches complexes.','PROVED_FROM_PROOF_113','Double résolution DDD_Base lignes 3308-3451 ; extension par J et recombinaison.','Chapitre 9, section Amplitudes de deux chemins.',['Deux branches orthogonales','Effet d’écran projetif'],'Développer le module carré de alpha a_L+beta a_R donne le terme croisé.'),
('PROOF-115','Le recouvrement des traces de mémoire contrôle la cohérence réduite.','PROVED_IN_FINITE_TENSOR_MODEL','Chat de Naszimger DDD_Base lignes 3021-3307 ; composition observationnelle SRC-OBS.','Chapitre 9, section Mémoire du détecteur.',['Etat conjoint pur donné','Trace partielle de la mémoire'],'Le calcul du produit extérieur puis la trace sur D donne gamma=<D_R,D_L> au terme hors diagonale.'),
('PROOF-116','Une bijection mesurable qui préserve nu induit un groupe de Koopman unitaire.','PROVED','Trajectoires et mécanismes observationnels SRC-OBS-001 lignes 1010-1048.','Chapitre 10, lemme Unitarité du transport.',['T_t bijectif et nu-invariant'],'Changement de variable conserve la norme L2 ; T_{-t} donne l’inverse.'),
('PROOF-117','Un groupe de Koopman fortement continu et J-compatible donne Schrödinger.','PROVED_CONDITIONAL','Mécanismes temporels et transitions du formalisme observationnel ; Stone est un théorème fonctionnel standard appliqué après construction.','Chapitre 10.',['Groupe unitaire fortement continu','Commutation avec J','Calibration hbar entre temps et énergie'],'Le générateur auto-adjoint de Stone donne U_t=exp(-JtH/hbar), donc i hbar dpsi/dt=H psi.'),
('PROOF-118','Une action de translation quasi-invariante et fortement continue donne CCR sur un domaine commun.','PROVED_CONDITIONAL','Sondes d’observation du coordinateur x ; transition mécaniste et temps.','Chapitre 11.',['x(T_a z)=x(z)+a','Mesure quasi-invariante','Groupe unitaire fortement continu','Domaine commun invariant'],'Covariance U_a*XU_a=X+aI différentiée en a=0 donne [X,P]=hbar J.'),
('PROOF-119','CCR exact est impossible en dimension finie.','PROVED','Pas de prémisse externe.','Chapitre 11, théorème Obstruction en dimension finie.',['Matrices finies'],'Trace([X,P])=0 tandis que trace(hbar J)=i hbar d non nul.'),
('PROOF-120','Robertson suit de Cauchy-Schwarz.','PROVED','Structure hermitienne dérivée PROOF-106.','Chapitre 12.',['A,B auto-adjoints et domaine commun','Variances finies'],'Appliquer Cauchy-Schwarz aux vecteurs centrés puis prendre la partie imaginaire.'),
('PROOF-121','La composition complexe tensorielle et la règle de Born donnent les marges sans signalisation.','PROVED_CONDITIONAL','Composition synchrone SRC-OBS-001 lignes 1261-1308.','Chapitre 13.',['J compatibles sur deux sous-systèmes','POVM locales complètes','Etat composite rho positif trace un'],'Sommer les effets distants donne l’identité, indépendance du réglage distant dans la marge.'),
('PROOF-122','CHSH classique <=2 et Tsirelson <=2sqrt2.','PROVED','Suit de l’algèbre d’opérateurs construite et composition.','Chapitre 13.',['Observables locales hermitiennes involutives'],'Le cas déterministe se réduit à ±2 ; identité S² et norme des commutateurs donnent 8 comme borne de S².'),
('PROOF-123','La projection normalisée est l’état post-mesure de distance minimale dans ran P.','PROVED_WITH_SCOPE','Noyau conjoint L reste le mécanisme d’état ; la règle est une sélection minimale.','Chapitre 14.',['Projecteur P','Issue de probabilité non nulle','Critère distance euclidienne annoncé'],'L’inégalité de Cauchy-Schwarz maximise le recouvrement avec psi ; le maximiseur normalisé est Ppsi/||Ppsi||.'),
('PROOF-124','Un canal fini est CP si et seulement si Choi positif, et possède une forme de Kraus.','PROVED_FINITE_DIMENSION','Composition synchrone et mécanismes stochastiques SRC-OBS.','Chapitre 14.',['Application linéaire sur matrices','Positivité sous toutes les extensions auxiliaires'],'Choi est image d’un projecteur maximally-entangled ; décomposition spectrale de Choi produit les matrices de Kraus.'),
('PROOF-125','L’exemple 3 objets produit exactement un plan de phase.','EXACT_SYMBOLIC','Partitions croisées définies dans validation/algebraic_checks_1.py.','Chapitre 5.',['Deux partitions croisées spécifiques'],'Calcul rationnel exact de C, -C², Pi et J.'),
('PROOF-126','L’exemple 5 objets produit exactement un secteur complexe de dimension 4.','EXACT_SYMBOLIC','Partitions synthétiques conservées dans quantum_observation_model_1.py.','Chapitre 5.',['Cinq contextes explicitement déclarés'],'Le polynôme caractéristique exact de -C² a huit valeurs propres strictement positives et deux zéros.'),
('PROOF-127','Les 34 effets de l’exemple cinq objets ont rang hermitien 16.','NUMERICALLY_VERIFIED','model_checks_1.json et script reproductible.','Chapitre 8.',['Tolérance numérique 1e-8','Effets générés par les cinq partitions'],'Calcul du rang des coordonnées hermitiennes ; ce test indique une tomographie complète de l’exemple, pas une donnée physique.'),
('PROOF-128','La tomographie synthétique reconstruit rho à erreur machine.','NUMERICALLY_VERIFIED_SYNTHETIC_ONLY','model_checks_1.json.','Chapitre 8.',['q_j générés par rho_true via Tr(rho E_j)'],'Résolution des équations linéaires de trace ; rho reconstruit avec erreur Frobenius approx. 1.94e-15.'),
('PROOF-129','48 contrôles numériques passent dans le modèle fini.','COMPUTATIONAL_TEST_ONLY','quantum_observation_model_1.py et validation/model_checks_1.json.','Chapitre 15.',['Implémentation Python et tolérances enregistrées'],'48 tests passent ; les preuves générales restent dans le texte et non dans le test numérique.'),
('PROOF-130','Les sources, le PDF et les fichiers de travail sont traçables ; aucune perte n’est signalée.','PROVENANCE_CHECK','source_manifest_1.json, rapport_incident_1.json, MANIFEST_SHA256SUMS.txt.','Dossier de livraison.',['Accès effectif aux fichiers recensés'],'Hachages recalculés, ZIP CRC, comparaison des copies et présence de tous les livrables.')
]
proofobj={
 'title':'Registre des preuves — th_emp_quantique_dev_1', 'version':'1.0','date':'2026-11-07','document':'th_emp_quantique_dev_1.tex','source_manifest':'source_manifest_1.json',
 'proof_policy':'Les résultats internes sont prouvés à partir des hypothèses listées. Les théorèmes de Hilbert, Stone, Radon–Nikodym, Naimark et Choi sont des outils mathématiques généraux explicitement nommés ; ils ne sont pas des postulats quantiques cachés. Toute condition non présente dans les sources est qualifiée d’extension construite ou de condition empirique. Born est démontrée pour la théorie complétée et ne doit pas être attribuée aux seules empreintes déterministes sans les portes opérationnelles.',
 'proof_count':len(proofs),
 'proofs':[{'id':a,'claim':b,'status':c,'source_or_basis':d,'proof_location':e,'assumptions':f,'proof_core':g} for a,b,c,d,e,f,g in proofs],
 'nonclaims':[
   'Aucune preuve que les seuls Phi déterministes imposent un noyau Q_f donné.',
   'Aucune preuve que tous les protocoles physiques ont un J global indépendant de l’itinéraire.',
   'Aucune donnée expérimentale physique utilisée pour la tomographie synthétique.',
   'Aucune valeur numérique de hbar dérivée des empreintes.',
   'Aucune résolution du problème de l’issue unique/collapse par la décohérence seule.'
 ]
}
dump('prouve_th_emp_quantique_dev_1.json',proofobj)

incident={
 'report_id':'INC-001','status':'NO_LOSS_DETECTED','date':'2026-11-07','scope':'Sources originales, copies des sources, itération 0, nouveaux laboratoires, manuscrit, scripts et rapports de validation.',
 'checks':[
   {'item':'Archive source originale Nouveau dossier.zip','result':'Accessible ; SHA-256 recalculé ; ZIP CRC PASS.'},
   {'item':'DDD_Base théorie','result':'Copie de recherche accessible ; huit occurrences d’origine recensées avec SHA-256 identique selon le manifeste de l’itération 0.'},
   {'item':'Formalisme observation full0','result':'Source TeX, bundle ZIP et audit documentaire accessibles ; hachages recalculés.'},
   {'item':'Itération 0','result':'Les six artefacts clés (checklist, laboratoires, registre de preuve, source TeX, PDF) sont présents et hachés ; aucune disparition détectée.'},
   {'item':'Itération 1','result':'Tous les fichiers listés dans le manifeste de livraison ont été créés ou copiés et leur empreinte est enregistrée.'},
   {'item':'Résultats numériques','result':'Script rejoué ; 48 tests sur 48 passent ; journal et JSON des tests conservés.'}
 ],
 'attestation':'Aucun fichier ou résultat connu comme ayant existé n’a été observé perdu pendant cette itération. Aucun témoignage fictif de perte n’est produit. Si une divergence de hachage ou un chemin manquant apparaît lors d’une utilisation ultérieure, elle devra faire l’objet d’un rapport daté et indépendant.',
 'known_nonloss_corrections':['L’itération 0 a d’abord annoncé trois copies de DDD_Base dans une mise à jour, puis a corrigé son manifeste à huit copies ; les huit copies ont le même SHA-256. Il s’agissait d’une correction de décompte, non d’une perte de fichier.','Le premier rendu LaTeX de l’itération 1 a échoué à cause d’une macro mathrsfs manquante et d’un retour de ligne de longtable ; les erreurs ont été corrigées, aucune source n’a été perdue.']
}
dump('rapport_incident_1.json',incident)
