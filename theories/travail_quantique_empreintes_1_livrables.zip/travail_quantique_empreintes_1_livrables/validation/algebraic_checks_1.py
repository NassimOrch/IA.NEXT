#!/usr/bin/env python3
"""Exact rational checks for the finite fingerprint-observation examples.

No floating-point arithmetic is used for the matrices, commutators, ranks,
characteristic polynomials, or polynomial identities in this script.
"""
from __future__ import annotations
import itertools, json
from pathlib import Path
import sympy as sp

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent / "algebraic_checks_1.json"


def pair_cells(objects, blocks):
    lab = {x: i for i, block in enumerate(blocks) for x in block}
    pairs = list(itertools.combinations(objects, 2))
    cells = {}
    for j, (x, y) in enumerate(pairs):
        key = tuple(sorted((lab[x], lab[y])))
        cells.setdefault(key, []).append(j)
    return list(cells.values())


def projection(cells, n):
    P = sp.zeros(n)
    for cell in cells:
        for i in cell:
            for j in cell:
                P[i, j] = sp.Rational(1, len(cell))
    return P


def exact_three_object_case():
    X = ["a", "b", "c"]
    A = projection(pair_cells(X, [["a", "b"], ["c"]]), 3)
    B = projection(pair_cells(X, [["a", "c"], ["b"]]), 3)
    C = A*B-B*A
    expected = sp.Matrix([[0, -sp.Rational(1,4), sp.Rational(1,4)],
                          [sp.Rational(1,4), 0, -sp.Rational(1,4)],
                          [-sp.Rational(1,4), sp.Rational(1,4), 0]])
    Pi = sp.eye(3)-sp.ones(3,3)/3
    return {
        "A": A, "B": B, "C": C, "Pi": Pi,
        "C_equals_expected": C == expected,
        "rank_C": C.rank(),
        "minus_C_squared_equals_3_over_16_Pi": -C*C == sp.Rational(3,16)*Pi,
        "charpoly_C": str(C.charpoly().as_expr().factor()),
    }


def five_object_case():
    X = [1,2,3,4,5]
    partitions = [
        [[1,5],[2],[3],[4]],
        [[1,3],[2],[4],[5]],
        [[1,5],[2,3],[4]],
        [[1],[2,4],[3,5]],
        [[1,4],[2],[3,5]],
    ]
    Ps = [projection(pair_cells(X,p),10) for p in partitions]
    C = sp.zeros(10)
    for a,b in zip(Ps,Ps[1:]):
        C += a*b-b*a
    edge_counts = {(i,i+1):1 for i in range(len(Ps)-1)}
    C_campaign = sum((count*(Ps[a]*Ps[b]-Ps[b]*Ps[a]) for (a,b),count in edge_counts.items()),sp.zeros(10))
    C_campaign_shuffled = sum((count*(Ps[a]*Ps[b]-Ps[b]*Ps[a]) for (a,b),count in list(edge_counts.items())[::-1]),sp.zeros(10))
    C_campaign_reversed = sum((count*(Ps[b]*Ps[a]-Ps[a]*Ps[b]) for (a,b),count in edge_counts.items()),sp.zeros(10))
    K = -C*C
    charpoly = sp.factor(K.charpoly().as_expr())
    expected = sp.Symbol('s')**2*(256*sp.Symbol('s')**2-144*sp.Symbol('s')+5)**2*(4096*sp.Symbol('s')**2-2160*sp.Symbol('s')+185)**2/sp.Integer(2**40)
    # Sympy's monic characteristic polynomial equals det(sI-K); compare after rational simplification.
    s = sp.Symbol('s')
    charpoly_expr = sp.factor(K.charpoly(s).as_expr())
    expected_expr = sp.factor(s**2*(256*s**2-144*s+5)**2*(4096*s**2-2160*s+185)**2/sp.Integer(2**40))
    eigen = K.eigenvals()
    eigen_records = []
    for val,mult in eigen.items():
        eigen_records.append({"eigenvalue":str(sp.simplify(val)),"multiplicity":int(mult)})
    return {
        "C": C, "K": K,
        "rank_C": C.rank(), "kernel_dimension_C": 10-C.rank(),
        "charpoly_K": str(charpoly_expr),
        "charpoly_matches_closed_form": sp.simplify(charpoly_expr-expected_expr)==0,
        "eigenvalues": eigen_records,
        "all_P_selfadjoint_idempotent": all(P==P.T and P*P==P for P in Ps),
        "all_P_preserve_uniform_mean": all((sp.ones(1,10)*P)==sp.ones(1,10) for P in Ps),
        "C_skew": C.T == -C,
        "campaign_C_equals_chain_C": C_campaign == C,
        "campaign_C_invariant_to_log_read_order": C_campaign_shuffled == C_campaign,
        "campaign_reversal_gives_minus_C": C_campaign_reversed == -C_campaign,
        "K_positive_semidefinite": all(ev.is_nonnegative is True for ev in K.eigenvals()),
    }


def main():
    t3=exact_three_object_case(); t5=five_object_case()
    results={
        "status":"PASS" if (t3["C_equals_expected"] and t3["rank_C"]==2 and t3["minus_C_squared_equals_3_over_16_Pi"] and t5["rank_C"]==8 and t5["charpoly_matches_closed_form"] and t5["all_P_selfadjoint_idempotent"] and t5["all_P_preserve_uniform_mean"] and t5["C_skew"] and t5["campaign_C_equals_chain_C"] and t5["campaign_C_invariant_to_log_read_order"] and t5["campaign_reversal_gives_minus_C"] and t5["K_positive_semidefinite"]) else "FAIL",
        "arithmetic":"exact rational / symbolic via SymPy",
        "three_object_case":{k:(str(v) if isinstance(v,sp.MatrixBase) else v) for k,v in t3.items() if k not in {"A","B","C","Pi"}},
        "three_object_matrices":{k:str(t3[k]) for k in ["A","B","C","Pi"]},
        "five_object_case":{k:v for k,v in t5.items() if k not in {"C","K"}},
        "five_object_commutator_matrix":str(t5["C"]),
        "five_object_minus_C_squared":str(t5["K"]),
    }
    OUT.write_text(json.dumps(results,indent=2,ensure_ascii=False)+"\n")
    print(json.dumps({"status":results["status"],"rank_C_3":t3["rank_C"],"rank_C_5":t5["rank_C"],"charpoly_exact":t5["charpoly_matches_closed_form"],"output":str(OUT)},indent=2))
    if results["status"]!="PASS": raise SystemExit(1)

if __name__=="__main__": main()
