#!/usr/bin/env python3
"""Structural scope audit: checks explicit assumptions and non-claims in the manuscript."""
import json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
tex=(ROOT/'th_emp_quantique_dev_1.tex').read_text()
checks={
 'campaign_circulation_section':'Circulation agrégée d\'une campagne complète' in tex and 'N_{cd}' in tex and 'ordre de lecture' in tex,
 'phase_atlas_criterion':'Critère de recollement global' in tex and 'holonomie' in tex and 'Réciproquement' in tex,
 'effect_realization_uses_joint_L':'De l\'effet candidat à une sonde effectivement réalisée' in tex and 'L_f' in tex and 'Q_f' in tex,
 'independent_calibration_and_holdout': "fixée **avant l'examen des fréquences**" in tex and 'Les préparations de validation sont distinctes' in tex,
 'born_requires_realized_instruments':'effectivement réalisé par un mécanisme conjoint $L_f$' in tex,
 'born_requires_descent':'noyaux $Q_f$ descendent sur les effets' in tex,
 'born_requires_normalization_and_positivity':'normalisées, positives' in tex,
 'born_requires_grouping_and_mixtures':'additives sous regroupement et affines sous mélange' in tex,
 'born_proof_extends_positive_functional':'L_+(A)' in tex and 'représentation euclidienne' in tex,
 'born_rank_one_formula':'|\\langle\\phi,\\psi\\rangle|^2' in tex,
 'physical_validation_not_claimed':'ne démontre pas que les seules signatures déterministes' in tex and 'Cette couverture est une condition testable' in tex,
 'phase_global_limits_are_stated':"Le test de l'itération présente n'établit pas encore ces données de transport" in tex,
 'finite_dimension_scope_explicit':'dimension finie' in tex,
 'hbar_calibration_not_derived':'valeur numérique et son identification expérimentale ne sont pas dérivées' in tex,
 'twisted_atlas_gram_transport':'Transport isométrique déterminé par les profils communs' in tex and 'matrices de Gram' in tex,
 'history_direct_sum':'Espace global des histoires observationnelles' in tex and '\\widehat{\\bigoplus}' in tex,
 'campaign_internal_unitary_group':'Groupe unitaire de circulation' in tex and 'e^{sC_\\gamma}' in tex,
 'infinite_dimensional_direct_limit':"Complétion directe d'une tour observationnelle" in tex and 'V_{m n}' in tex,
 'normal_born_uses_monotone_finite_rank_approximants':'F_n=E^{1/2}P_nE^{1/2}' in tex and 'F_n\\uparrow E' in tex,
 'normal_born_rejects_nonmonotone_compressions':'F_n=E^{1/2}P_nE^{1/2}' in tex and 'n’est pas croissante en général' in tex[tex.index('\\begin{theoreme}[Représentation de Born normale]'):tex.index('\\end{proof}', tex.index('\\begin{theoreme}[Représentation de Born normale]'))],
}
result={'status':'PASS' if all(checks.values()) else 'FAIL','check_count':len(checks),'passed':sum(checks.values()),'failed':[k for k,v in checks.items() if not v],'checks':checks,
        'interpretation':'Audit structurel de présence des hypothèses et réserves ; ne constitue pas à lui seul une certification formelle de validité mathématique.'}
(ROOT/'validation/theorem_scope_audit_1.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'status':result['status'],'passed':result['passed'],'check_count':result['check_count'],'failed':result['failed']},indent=2))
if result['status']!='PASS': raise SystemExit(1)
