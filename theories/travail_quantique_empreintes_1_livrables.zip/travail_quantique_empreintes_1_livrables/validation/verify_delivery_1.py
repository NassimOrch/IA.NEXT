#!/usr/bin/env python3
"""Reproducible integrity audit for iteration 1 delivery artifacts."""
from __future__ import annotations
import hashlib, json, subprocess, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT.parent
checks={}
def sha(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()
def check(k,v,detail=None):
    checks[k]={'pass':bool(v),'detail':detail}
# Required deliverables.
required=['README.md','th_emp_quantique_dev_1.tex','th_emp_quantique_dev_1.pdf',
          'checklist_travail_1.json','laboratoire_1.json','laboratoire_next_1.json',
          'prouve_th_emp_quantique_dev_1.json','source_manifest_1.json','rapport_incident_1.json',
          'quantum_observation_model_1.py','quantum_observation_extension_1.py']
missing=[x for x in required if not (ROOT/x).is_file()]
check('required_files_present',not missing,{'missing':missing,'required_count':len(required)})
# JSON syntax and schema-level counts.
json_files=list(ROOT.glob('*.json'))+list((ROOT/'validation').glob('*.json'))
json_errors=[]
for p in json_files:
    try: json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: json_errors.append({'file':str(p.relative_to(ROOT)),'error':str(e)})
check('all_json_parse',not json_errors,{'json_count':len(json_files),'errors':json_errors})
checklist=json.loads((ROOT/'checklist_travail_1.json').read_text())
lab=json.loads((ROOT/'laboratoire_1.json').read_text())
nextlab=json.loads((ROOT/'laboratoire_next_1.json').read_text())
proof=json.loads((ROOT/'prouve_th_emp_quantique_dev_1.json').read_text())
check('checklist_count_consistent',checklist['phase_count']==len(checklist['phases']) and len({x['id'] for x in checklist['phases']})==len(checklist['phases']),{'declared':checklist['phase_count'],'actual':len(checklist['phases'])})
check('laboratory_attempt_count_consistent',lab['attempt_count']==len(lab['attempts']) and len({x['id'] for x in lab['attempts']})==len(lab['attempts']),{'declared':lab['attempt_count'],'actual':len(lab['attempts']),'final_rerun_present':any(x['id']=='LAB-055' for x in lab['attempts'])})
check('promoted_result_count_consistent',nextlab['result_count']==len(nextlab['results']) and len({x['id'] for x in nextlab['results']})==len(nextlab['results']),{'declared':nextlab['result_count'],'actual':len(nextlab['results'])})
check('proof_register_count_consistent',proof['proof_count']==len(proof['proofs']) and len({x['id'] for x in proof['proofs']})==len(proof['proofs']),{'declared':proof['proof_count'],'actual':len(proof['proofs']),'unique_ids':len({x['id'] for x in proof['proofs']})})
# Source byte identity.
manifest=json.loads((ROOT/'source_manifest_1.json').read_text())
source_status=[]
for src in manifest['primary_sources']:
    p=ROOT/src['local_copy']
    ok=p.is_file() and sha(p)==src['sha256'] and p.stat().st_size==src['bytes']
    source_status.append({'id':src['id'],'exists':p.is_file(),'sha256_matches':ok,'bytes_actual':p.stat().st_size if p.exists() else None,'bytes_expected':src['bytes']})
check('primary_source_hashes',all(x['sha256_matches'] for x in source_status),source_status)
orig=Path(manifest['original_archive']['path_as_received'])
orig_hash_ok=orig.is_file() and sha(orig)==manifest['original_archive']['sha256']
orig_crc='MISSING'
orig_ddd_count=None
if orig.is_file():
    with zipfile.ZipFile(orig) as z:
        bad=z.testzip(); orig_crc='PASS' if bad is None else f'FAIL:{bad}'
        orig_ddd_count=sum(n.endswith('DDD_Base_theorie_des_empreintes_complete_order_5.tex') for n in z.namelist())
check('original_archive_integrity',orig_hash_ok and orig_crc=='PASS' and orig_ddd_count==8,{'exists':orig.is_file(),'sha256_matches':orig_hash_ok,'zip_crc':orig_crc,'ddd_base_occurrences':orig_ddd_count})
# Nested source archive CRC.
bundle=ROOT/'sources/observation_formalisme_full_0_bundle.zip'
try:
    with zipfile.ZipFile(bundle) as z: bad=z.testzip()
    bundle_crc='PASS' if bad is None else f'FAIL:{bad}'
except Exception as e: bundle_crc=f'ERROR:{e}'
check('observation_bundle_crc',bundle_crc=='PASS',bundle_crc)
# Executable validation records.
model=json.loads((ROOT/'validation/model_checks_1.json').read_text())
ext=json.loads((ROOT/'validation/extension_checks_1.json').read_text())
scope=json.loads((ROOT/'validation/theorem_scope_audit_1.json').read_text())
alg=json.loads((ROOT/'validation/algebraic_checks_1.json').read_text())
audit=json.loads((ROOT/'validation/audit_5_passes_1.json').read_text())
check('model_tests',model['status']=='PASS' and model['passed']==model['test_count']==51 and model['failed']==0,{'passed':model['passed'],'total':model['test_count'],'failed':model['failed']})
check('extension_tests',ext['status']=='PASS' and ext['passed']==ext['test_count']==18 and ext['failed']==0,{'passed':ext['passed'],'total':ext['test_count'],'failed':ext['failed']})
check('structural_scope_audit',scope['status']=='PASS' and scope['passed']==scope['check_count']==20 and not scope['failed'],{'passed':scope['passed'],'total':scope['check_count'],'failed':scope['failed']})
check('exact_symbolic_algebra',alg['status']=='PASS' and alg['three_object_case']['rank_C']==2 and alg['five_object_case']['rank_C']==8 and alg['five_object_case']['charpoly_matches_closed_form'],{'status':alg['status'],'rank3':alg['three_object_case']['rank_C'],'rank5':alg['five_object_case']['rank_C'],'charpoly_exact':alg['five_object_case']['charpoly_matches_closed_form']})
check('five_pass_audit',audit['status']=='PASS' and audit['pass_count']==audit['passed']==5 and all(x['status']=='PASS' for x in audit['passes']),{'status':audit['status'],'passed':audit['passed'],'pass_count':audit['pass_count']})
# PDF identity and rendered pages.
pdf=ROOT/'th_emp_quantique_dev_1.pdf'; buildpdf=ROOT/'validation/build_clean/th_emp_quantique_dev_1.pdf'
try:
    info=subprocess.run(['pdfinfo',str(pdf)],capture_output=True,text=True,check=True).stdout
    import re
    mm=re.search(r'^Pages:\s+(\d+)',info,re.M); pages=int(mm.group(1)) if mm else -1
except Exception as e: pages=-1
compare=json.loads((ROOT/'validation/pdf_compare_root_vs_build/summary.json').read_text())
pdf_info_build=subprocess.run(['pdfinfo',str(buildpdf)],capture_output=True,text=True,check=True).stdout if buildpdf.is_file() else ''
bm=re.search(r'^Pages:\s+(\d+)',pdf_info_build,re.M); build_pages=int(bm.group(1)) if bm else -1
pdf_text_same=(ROOT/'validation/root_pdf.txt').is_file() and (ROOT/'validation/build_pdf.txt').is_file() and (ROOT/'validation/root_pdf.txt').read_bytes()==(ROOT/'validation/build_pdf.txt').read_bytes()
raster_same=compare.get('pages_a')==54 and compare.get('pages_b')==54 and compare.get('changed_pages')==0
pdf_match=pdf.is_file() and buildpdf.is_file() and build_pages==54 and pdf_text_same and raster_same
rendered=list((ROOT/'validation/rendered_final').glob('page-*.png'))
contacts=[ROOT/f'validation/contact_sheet_current_{i}.png' for i in (1,2,3)]
check('final_pdf',pdf.is_file() and pages==54 and pdf_match,{'exists':pdf.is_file(),'pages':pages,'build_pages':build_pages,'bytes':pdf.stat().st_size if pdf.exists() else None,'sha256':sha(pdf) if pdf.exists() else None,'extracted_text_identical':pdf_text_same,'raster_changed_pages':compare.get('changed_pages')})
check('pdf_render',len(rendered)==54 and all(p.is_file() for p in contacts),{'rendered_pages':len(rendered),'contact_sheets_present':[p.name for p in contacts if p.is_file()]})
# Audit record points at current final hash and size.
pass5=next(x for x in audit['passes'] if x['id']=='PASS-5-LATEX-AND-VISUAL-RENDER')
check('audit_matches_current_pdf',pass5['checks']['pdf_bytes']==(pdf.stat().st_size if pdf.exists() else None) and pass5['checks']['pdf_sha256']==(sha(pdf) if pdf.exists() else None) and pass5['checks']['raster_comparison']['changed_pages']==0,{'audit_bytes':pass5['checks']['pdf_bytes'],'actual_bytes':pdf.stat().st_size if pdf.exists() else None,'audit_sha256':pass5['checks']['pdf_sha256'],'actual_sha256':sha(pdf) if pdf.exists() else None})
# Incident record: do not invent loss.
incident=json.loads((ROOT/'rapport_incident_1.json').read_text())
check('incident_report_consistent',incident['status']=='NO_LOSS_DETECTED' and 'aucun' in incident['attestation'].lower(),{'status':incident['status']})
failed=[k for k,v in checks.items() if not v['pass']]
result={'title':'Audit d’intégrité de la livraison — itération 1','date':'2026-11-07','status':'PASS' if not failed else 'FAIL','check_count':len(checks),'passed':len(checks)-len(failed),'failed':failed,'checks':checks,'scope':'Contrôles de fichiers, hachages, ZIP, cohérence des registres, scripts/tests finis et identité du PDF. Ne constitue pas une preuve expérimentale ou une certification formelle indépendante de tous les théorèmes.'}
(ROOT/'validation/delivery_integrity_1.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'passed':result['passed'],'check_count':result['check_count'],'failed':failed},ensure_ascii=False,indent=2))
if failed: raise SystemExit(1)
