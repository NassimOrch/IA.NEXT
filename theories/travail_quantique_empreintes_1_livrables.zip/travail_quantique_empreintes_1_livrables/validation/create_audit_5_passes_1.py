#!/usr/bin/env python3
"""Create the five-pass audit record from independently checked artifacts."""
from __future__ import annotations
import hashlib, json, re, zipfile
from pathlib import Path
from subprocess import run, PIPE
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT.parent

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()

# Pass 1: provenance, original archive and primary sources.
archive=DATA/'Nouveau dossier.zip'
manifest=json.loads((ROOT/'source_manifest_1.json').read_text())
source_results=[]
for src in manifest['primary_sources']:
 p=ROOT/src['local_copy']
 source_results.append({"id":src['id'],"exists":p.is_file(),"sha256_matches":p.is_file() and sha(p)==src['sha256'],"bytes":p.stat().st_size if p.is_file() else None})
with zipfile.ZipFile(archive) as z:
 bad=z.testzip(); ddd_count=sum(n.endswith('DDD_Base_theorie_des_empreintes_complete_order_5.tex') for n in z.namelist())
original_ok=(sha(archive)==manifest['original_archive']['sha256'] and bad is None and ddd_count==8)
pass1={"id":"PASS-1-PROVENANCE","status":"PASS" if original_ok and all(x['exists'] and x['sha256_matches'] for x in source_results) else "FAIL",
       "checks":{"original_archive_exists":archive.is_file(),"original_sha256":sha(archive),"expected_archive_sha256":manifest['original_archive']['sha256'],"original_zip_crc": "PASS" if bad is None else f"FAIL:{bad}","DDD_Base_occurrences_in_source_archive":ddd_count,"expected_DDD_Base_occurrences":8,"primary_sources":source_results},
       "scope":"Provenance and byte identity of source files; not a validation of physical claims."}

# Pass 2: exact symbolic arithmetic.
algebraic=json.loads((ROOT/'validation/algebraic_checks_1.json').read_text())
pass2={"id":"PASS-2-EXACT-SYMBOLIC-ALGEBRA","status":"PASS" if algebraic['status']=='PASS' and algebraic['five_object_case']['charpoly_matches_closed_form'] and algebraic['five_object_case']['campaign_C_invariant_to_log_read_order'] and algebraic['five_object_case']['campaign_reversal_gives_minus_C'] else "FAIL",
       "checks":{"three_object_phase_rank":algebraic['three_object_case']['rank_C'],"three_object_exact_identities":algebraic['three_object_case']['minus_C_squared_equals_3_over_16_Pi'],"five_object_phase_rank":algebraic['five_object_case']['rank_C'],"five_object_charpoly_exact":algebraic['five_object_case']['charpoly_matches_closed_form'],"campaign_count_order_invariance":algebraic['five_object_case']['campaign_C_invariant_to_log_read_order'],"campaign_reversal_sign":algebraic['five_object_case']['campaign_reversal_gives_minus_C']},
       "scope":"Exact rational/symbolic checks of the finite examples, not a computer-checked proof of every general theorem."}

# Pass 3: theorem scope and assumptions.
scope=json.loads((ROOT/'validation/theorem_scope_audit_1.json').read_text())
proofs=json.loads((ROOT/'prouve_th_emp_quantique_dev_1.json').read_text())
pass3={"id":"PASS-3-THEOREM-AND-HYPOTHESIS-AUDIT","status":"PASS" if scope['status']=='PASS' and scope['failed']==[] and proofs['proof_count']==len(proofs['proofs']) and any(x['id']=='PROOF-142' for x in proofs['proofs']) else "FAIL",
       "checks":{"explicit_scope_checks":f"{scope['passed']}/{scope['check_count']}","proof_register_count":proofs['proof_count'],"proof_register_consistent":proofs['proof_count']==len(proofs['proofs']) and any(x['id']=='PROOF-142' for x in proofs['proofs']),"nonclaims_retained":len(proofs['nonclaims']),"Born_conditions":"realized L_f, Q_f descent, positivity, normalization, regrouping, mixtures, finite-dimensional sector; normal infinite-dimensional Born uses increasing finite-rank F_n=E^(1/2)P_nE^(1/2)"},
       "scope":"Structural and logical audit. It does not replace independent expert review or a formal proof assistant."}

# Pass 4: numerical model.
model=json.loads((ROOT/'validation/model_checks_1.json').read_text())
ext=json.loads((ROOT/'validation/extension_checks_1.json').read_text())
combined_passed=model['passed']+ext['passed']; combined_total=model['test_count']+ext['test_count']
pass4={"id":"PASS-4-NUMERICAL-REPRODUCIBILITY","status":"PASS" if model['status']=='PASS' and model['passed']==model['test_count']==51 and model['failed']==0 and ext['status']=='PASS' and ext['passed']==ext['test_count']==18 and ext['failed']==0 else "FAIL",
       "checks":{"base_passed":model['passed'],"base_total":model['test_count'],"extension_passed":ext['passed'],"extension_total":ext['test_count'],"passed":combined_passed,"total":combined_total,"failed":model['failed']+ext['failed'],"phase_rank":model['details']['five_context_complex_structure']['rank_C'],"complex_dimension":model['details']['five_context_complex_structure']['phase_dimension_complex'],"tomographic_effect_span_rank":model['details']['tomographic_completeness']['hermitian_effect_span_rank'],"campaign_circulation":model['details']['campaign_circulation'],"extension_scope":ext['scope']},
       "scope":"69 calculs synthétiques reproductibles au total ; ils ne constituent pas des données physiques expérimentales."}

# Pass 5: build and render.
pdf=ROOT/'th_emp_quantique_dev_1.pdf'; build_pdf=ROOT/'validation/build_clean/th_emp_quantique_dev_1.pdf'; tex=ROOT/'th_emp_quantique_dev_1.tex'
info=run(['pdfinfo',str(pdf)],capture_output=True,text=True,check=True).stdout
m=re.search(r'^Pages:\s+(\d+)',info,re.M); pages=int(m.group(1)) if m else -1
log=(ROOT/'validation/build_clean/th_emp_quantique_dev_1.log').read_text(errors='replace')
forbidden=[x for x in ['LaTeX Error','Undefined control sequence','Overfull \\hbox','Emergency stop','Reference `'] if x in log]
rendered=list((ROOT/'validation/rendered_final').glob('page-*.png'))
contacts=[ROOT/f'validation/contact_sheet_current_{i}.png' for i in (1,2,3)]
compile_logs=[ROOT/f'validation/pdflatex_clean_pass{i}.log' for i in range(1,6)]
compile_summaries=[]
for p in compile_logs:
    t=p.read_text(errors='replace') if p.is_file() else ''
    mpass=re.search(r'\((\d+) pages?',t)
    compile_summaries.append({'log':p.name,'pages':int(mpass.group(1)) if mpass else None,'fatal':any(x in t for x in ['LaTeX Error','Undefined control sequence','Emergency stop','! '])})
build_info=run(['pdfinfo',str(build_pdf)],capture_output=True,text=True,check=True).stdout if build_pdf.is_file() else ''
bm=re.search(r'^Pages:\s+(\d+)',build_info,re.M); build_pages=int(bm.group(1)) if bm else -1
compare_path=ROOT/'validation/pdf_compare_root_vs_build/summary.json'
compare=json.loads(compare_path.read_text()) if compare_path.is_file() else {}
text_equal=False
root_text=ROOT/'validation/root_pdf.txt'; build_text=ROOT/'validation/build_pdf.txt'
if root_text.is_file() and build_text.is_file(): text_equal=root_text.read_bytes()==build_text.read_bytes()
raster_equal=compare.get('pages_a')==54 and compare.get('pages_b')==54 and compare.get('changed_pages')==0
pass5={"id":"PASS-5-LATEX-AND-VISUAL-RENDER","status":"PASS" if pdf.is_file() and pages==54 and build_pages==54 and len(rendered)==54 and all(p.is_file() for p in contacts) and all(p.is_file() for p in compile_logs) and all(x['pages']==54 and not x['fatal'] for x in compile_summaries) and raster_equal and text_equal and not forbidden else "FAIL",
       "checks":{"pdf_exists":pdf.is_file(),"pages":pages,"build_pdf_pages":build_pages,"rendered_pages":len(rendered),"contact_sheets":[p.name for p in contacts],"compile_pass_logs":[p.name for p in compile_logs],"compile_pass_summaries":compile_summaries,"latex_forbidden_diagnostics":forbidden,"pdf_bytes":pdf.stat().st_size if pdf.is_file() else None,"pdf_sha256":sha(pdf) if pdf.is_file() else None,"build_pdf_sha256":sha(build_pdf) if build_pdf.is_file() else None,"binary_identical":pdf.is_file() and build_pdf.is_file() and sha(pdf)==sha(build_pdf),"extracted_text_identical":text_equal,"raster_comparison":{"changed_pages":compare.get('changed_pages'),"pages_a":compare.get('pages_a'),"pages_b":compare.get('pages_b'),"dpi":compare.get('dpi')}},
       "scope":"Five fresh pdflatex builds; final and clean-build PDF copies have identical extracted text and pixel-identical 120-dpi renders on all 54 pages (binary SHA-256 may differ); three current contact sheets visually inspected."}

passes=[pass1,pass2,pass3,pass4,pass5]
out={"title":"Audit en cinq passes — itération 1","date":"2026-11-07","status":"PASS" if all(p['status']=='PASS' for p in passes) else "FAIL","pass_count":5,"passed":sum(p['status']=='PASS' for p in passes),"passes":passes,
     "global_reservation":"PASS signifie que les contrôles décrits ci-dessus ont été exécutés et satisfaits ; cela ne transforme pas les hypothèses physiques ouvertes en faits expérimentaux."}
(ROOT/'validation/audit_5_passes_1.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({"status":out['status'],"passed":out['passed'],"passes":[(p['id'],p['status']) for p in passes]},indent=2))
if out['status']!='PASS': raise SystemExit(1)
