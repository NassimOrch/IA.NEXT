#!/usr/bin/env python3
"""Finite source-compatible model for the fingerprint/observation quantum extension.

All finite matrices are generated from unordered object pairs, empirical pair measure,
source-style observation partitions, and their conditional-expectation operators.
The script tests algebraic consequences; it does not claim physical data validation.
"""
from __future__ import annotations
import itertools, json, math, hashlib
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
VAL = ROOT / "validation"
VAL.mkdir(exist_ok=True)

X = [1, 2, 3, 4, 5]
PAIR_LIST = list(itertools.combinations(X, 2))
CONTEXT_PARTITIONS = [
    [[1, 5], [2], [3], [4]],
    [[1, 3], [2], [4], [5]],
    [[1, 5], [2, 3], [4]],
    [[1], [2, 4], [3, 5]],
    [[1, 4], [2], [3, 5]],
]


def pair_partition(blocks):
    lab = {x: i for i, block in enumerate(blocks) for x in block}
    cells = {}
    for k, (x, y) in enumerate(PAIR_LIST):
        key = tuple(sorted((lab[x], lab[y])))
        cells.setdefault(key, []).append(k)
    return list(cells.values())


def conditional_expectation_projection(cells, n):
    """Orthogonal projection onto functions constant on cells, uniform pair measure."""
    P = np.zeros((n, n), dtype=float)
    for cell in cells:
        for i in cell:
            for j in cell:
                P[i, j] = 1.0 / len(cell)
    return P


def symmetric_inverse_sqrt_on_support(A, tol=1e-10):
    vals, vecs = np.linalg.eigh((A + A.T) / 2)
    keep = vals > tol
    invsqrt = np.zeros_like(A)
    if np.any(keep):
        invsqrt = (vecs[:, keep] * (1.0 / np.sqrt(vals[keep]))) @ vecs[:, keep].T
    projector = (vecs[:, keep] @ vecs[:, keep].T) if np.any(keep) else np.zeros_like(A)
    return invsqrt, projector, vals


def make_complex_structure(C, tol=1e-9):
    """J=-C(-C^2)^(-1/2) on ran(C), zero on ker(C)."""
    K = -C @ C
    invsqrt, projector, evals = symmetric_inverse_sqrt_on_support(K, tol)
    J = -C @ invsqrt
    H = (K + K.T) / 2
    Hvals, Hvecs = np.linalg.eigh(H)
    Hsqrt = (Hvecs * np.sqrt(np.maximum(Hvals, 0.0))) @ Hvecs.T
    return J, Hsqrt, projector, evals


def complex_basis(J, projector, tol=1e-8):
    """Choose e_j with {e_j,J e_j} a real orthonormal basis of ran(projector)."""
    n = J.shape[0]
    es = []
    target = int(round(np.trace(projector)))
    for k in range(n):
        v = projector @ np.eye(n)[:, k]
        for e in es:
            v -= np.dot(e, v) * e
            v -= np.dot(J @ e, v) * (J @ e)
        nv = np.linalg.norm(v)
        if nv < tol:
            continue
        v /= nv
        jv = J @ v
        if abs(np.dot(v, jv)) > 1e-7 or abs(np.linalg.norm(jv)-1) > 1e-7:
            raise AssertionError("J is not an orthogonal complex structure on its support")
        es.append(v)
        if 2 * len(es) >= target:
            break
    if 2 * len(es) != target:
        raise AssertionError("complex basis does not span phase support")
    return es


def to_complex_matrix(A, es, J):
    """Matrix of a J-linear real operator in the associated complex basis."""
    d = len(es)
    M = np.zeros((d, d), dtype=complex)
    for j, ej in enumerate(es):
        v = A @ ej
        for i, ei in enumerate(es):
            M[i, j] = np.dot(ei, v) + 1j * np.dot(J @ ei, v)
    return M


def hermitian_coordinates(M):
    """Real coordinates of a Hermitian dxd matrix (d^2 real coordinates)."""
    d = M.shape[0]
    out = [float(M[i, i].real) for i in range(d)]
    for i in range(d):
        for j in range(i + 1, d):
            out.extend([float(M[i, j].real), float(M[i, j].imag)])
    return np.asarray(out, dtype=float)


def run_checks():
    n = len(PAIR_LIST)
    nu = np.ones(n, dtype=float) / n  # uniform empirical measure on unordered pairs
    pair_cells = [pair_partition(p) for p in CONTEXT_PARTITIONS]
    Ps = [conditional_expectation_projection(cells, n) for cells in pair_cells]

    projection_checks = []
    for i, P in enumerate(Ps):
        projection_checks.append({
            "context": i + 1,
            "symmetric_error": float(np.linalg.norm(P - P.T)),
            "idempotence_error": float(np.linalg.norm(P @ P - P)),
            "constant_fixed_error": float(np.linalg.norm(P @ np.ones(n) - np.ones(n))),
            "measure_preservation_error": float(np.linalg.norm(nu @ P - nu)),
        })

    C_parts = [Ps[i] @ Ps[i+1] - Ps[i+1] @ Ps[i] for i in range(len(Ps)-1)]
    C = sum(C_parts, np.zeros((n, n)))
    # Canonical campaign circulation: count directed transitions in the complete
    # observation log. The result depends on multiplicities, not log read order.
    edge_counts = {(i, i+1): 1 for i in range(len(Ps)-1)}
    C_campaign = sum((count * (Ps[a] @ Ps[b] - Ps[b] @ Ps[a])
                      for (a,b),count in edge_counts.items()), np.zeros((n,n)))
    shuffled_edges = list(edge_counts.items())[::-1]
    C_campaign_shuffled = sum((count * (Ps[a] @ Ps[b] - Ps[b] @ Ps[a])
                               for (a,b),count in shuffled_edges), np.zeros((n,n)))
    C_campaign_reverse = sum((count * (Ps[b] @ Ps[a] - Ps[a] @ Ps[b])
                              for (a,b),count in edge_counts.items()), np.zeros((n,n)))
    campaign_matches_itinerary = float(np.linalg.norm(C_campaign-C))
    campaign_order_invariance = float(np.linalg.norm(C_campaign_shuffled-C_campaign))
    campaign_reverse_error = float(np.linalg.norm(C_campaign_reverse+C_campaign))
    J, H, Pi, evals = make_complex_structure(C)
    rank_C = int(np.linalg.matrix_rank(C, tol=1e-8))
    # The chronological reverse changes J to -J (complex conjugation), while
    # a genuinely different itinerary may change the polar complex structure.
    reverse_order = list(reversed(range(len(Ps))))
    C_reverse = sum([Ps[reverse_order[i]] @ Ps[reverse_order[i+1]]
                     - Ps[reverse_order[i+1]] @ Ps[reverse_order[i]]
                     for i in range(len(reverse_order)-1)], np.zeros((n,n)))
    J_reverse, _, Pi_reverse, _ = make_complex_structure(C_reverse)
    alternate_order = [0,2,1,3,4]
    C_alternate = sum([Ps[alternate_order[i]] @ Ps[alternate_order[i+1]]
                       - Ps[alternate_order[i+1]] @ Ps[alternate_order[i]]
                       for i in range(len(alternate_order)-1)], np.zeros((n,n)))
    J_alternate, _, Pi_alternate, _ = make_complex_structure(C_alternate)
    path_phase_reverse_error = float(np.linalg.norm(J_reverse + J))
    path_support_reverse_error = float(np.linalg.norm(Pi_reverse-Pi))
    path_alternate_support_difference = float(np.linalg.norm(Pi_alternate-Pi))
    path_alternate_J_difference = float(np.linalg.norm(J_alternate-J))
    osc_dim = int(round(np.trace(Pi)))
    es = complex_basis(J, Pi)
    J_errors = {
        "skew_error": float(np.linalg.norm(J.T + J)),
        "J2_plus_projector_error": float(np.linalg.norm(J @ J + Pi)),
        "orthogonality_on_support_error": float(np.linalg.norm(J.T @ J - Pi)),
        "commutes_with_C_error": float(np.linalg.norm(J @ C - C @ J)),
        "C_plus_JH_error": float(np.linalg.norm(C + J @ H)),
        "basis_orthonormal_error": float(max(
            np.linalg.norm(np.dot(es[i], es[j]) - (1.0 if i == j else 0.0))
            for i in range(len(es)) for j in range(len(es))
        )),
        "basis_J_orthogonality_error": float(max(
            abs(np.dot(es[i], J @ es[j])) for i in range(len(es)) for j in range(len(es))
        )),
    }

    # A nested resolution chain has commuting conditional-expectation projections.
    X3 = ["a", "b", "c"]
    p3 = list(itertools.combinations(X3, 2))
    def pair_part3(blocks):
        lab = {x: i for i, b in enumerate(blocks) for x in b}
        cells = {}
        for k, (x, y) in enumerate(p3):
            key = tuple(sorted((lab[x], lab[y])))
            cells.setdefault(key, []).append(k)
        return list(cells.values())
    nested = [
        conditional_expectation_projection(pair_part3([["a", "b", "c"]]), 3),
        conditional_expectation_projection(pair_part3([["a", "b"], ["c"]]), 3),
        conditional_expectation_projection(pair_part3([["a"], ["b"], ["c"]]), 3),
    ]
    nested_comm = [float(np.linalg.norm(nested[i] @ nested[i+1] - nested[i+1] @ nested[i])) for i in range(2)]
    crossed = [
        conditional_expectation_projection(pair_part3([["a", "b"], ["c"]]), 3),
        conditional_expectation_projection(pair_part3([["a", "c"], ["b"]]), 3),
    ]
    C3 = crossed[0] @ crossed[1] - crossed[1] @ crossed[0]
    J3, H3, Pi3, evals3 = make_complex_structure(C3)
    C3_exact = np.array([[0, -1/4, 1/4], [1/4, 0, -1/4], [-1/4, 1/4, 0]], dtype=float)
    exact_three_context_error = float(np.linalg.norm(C3-C3_exact))
    exact_H3_error = float(np.linalg.norm(H3 - math.sqrt(3)/4 * Pi3))

    # Event indicators from the five source-style contexts span the real pair space.
    event_profiles = []
    for cells in pair_cells:
        for cell in cells:
            v = np.zeros(n, dtype=float)
            v[cell] = 1.0
            event_profiles.append(v)
    event_profile_rank = int(np.linalg.matrix_rank(np.asarray(event_profiles).T, tol=1e-8))
    projected_event_rank = int(np.linalg.matrix_rank((Pi @ np.asarray(event_profiles).T).T, tol=1e-8))

    # Each context's outcomes plus its complement form a real PVM; phase averaging
    # turns the compressed projections into positive J-linear effects.
    context_effect_checks = []
    all_effect_matrices = []
    effects_by_context = []
    effects_real_by_context = []
    for i, cells in enumerate(pair_cells):
        Elist, Mlist = [], []
        P = Ps[i]
        for cell in cells:
            Q = conditional_expectation_projection([cell], n)
            A = Pi @ Q @ Pi
            E = (A + J @ A @ J.T) / 2
            E = (E + E.T) / 2
            Elist.append(E)
        Qres = np.eye(n) - P
        Ares = Pi @ Qres @ Pi
        Eres = (Ares + J @ Ares @ J.T) / 2
        Elist.append((Eres + Eres.T) / 2)
        for E in Elist:
            M = to_complex_matrix(E, es, J)
            Mlist.append(M)
            all_effect_matrices.append(M)
        effects_by_context.append(Mlist)
        effects_real_by_context.append(Elist)
        total = sum(Elist, np.zeros((n, n)))
        eigs = [float(np.linalg.eigvalsh(M).min()) for M in Mlist]
        context_effect_checks.append({
            "context": i + 1,
            "sum_to_identity_error": float(np.linalg.norm(total-Pi)),
            "minimum_effect_eigenvalue": min(eigs),
            "J_linearity_error": float(max(np.linalg.norm(E@J-J@E) for E in Elist)),
            "effect_count_including_complement": len(Elist),
        })

    effect_coordinate_rank = int(np.linalg.matrix_rank(
        np.asarray([hermitian_coordinates(M) for M in all_effect_matrices]), tol=1e-8
    ))
    d = len(es)

    # Tomographic reconstruction: synthesize a pure profile, generate its Q-values
    # by the trace pairing, then recover its density uniquely from the IC effects.
    raw_state = np.array([1.0, 1.0j, 2.0-0.5j, -0.2+1.1j], dtype=complex)
    psi = raw_state / np.linalg.norm(raw_state)
    rho_true = np.outer(psi, psi.conj())
    q_values = np.asarray([float(np.real(np.vdot(psi, E @ psi))) for E in all_effect_matrices])
    design = np.asarray([hermitian_coordinates(E) for E in all_effect_matrices])
    column = d
    for i in range(d):
        for j in range(i+1, d):
            design[:, column] *= 2.0
            design[:, column+1] *= 2.0
            column += 2
    rho_coordinates, residuals, tomography_rank, singular_values = np.linalg.lstsq(design, q_values, rcond=None)
    rho_recovered = np.zeros((d,d), dtype=complex)
    for i in range(d):
        rho_recovered[i,i] = rho_coordinates[i]
    column = d
    for i in range(d):
        for j in range(i+1, d):
            rho_recovered[i,j] = rho_coordinates[column] + 1j*rho_coordinates[column+1]
            rho_recovered[j,i] = rho_coordinates[column] - 1j*rho_coordinates[column+1]
            column += 2
    tomography_error = float(np.linalg.norm(rho_recovered-rho_true))
    tomography_trace_error = float(abs(np.trace(rho_recovered)-1))
    tomography_min_eigenvalue = float(np.linalg.eigvalsh((rho_recovered+rho_recovered.conj().T)/2).min())

    # Phase rotations preserve all J-linear effects: e^{theta J} is an unobservable global phase.
    theta = 0.731
    Uphase = math.cos(theta)*Pi + math.sin(theta)*J + (np.eye(n)-Pi)
    phase_covariance_error = float(max(
        np.linalg.norm(Uphase.T @ E @ Uphase - E)
        for Elist in effects_real_by_context for E in Elist
    ))

    # Interference identity in one complex plane.
    phi_grid = [0.0, math.pi/2, math.pi, 3*math.pi/2]
    interference = []
    for phi in phi_grid:
        amp = (1 + np.exp(1j*phi)) / 2
        p = float(abs(amp)**2)
        expected = (1 + math.cos(phi)) / 2
        interference.append({"phase_rad":phi,"probability":p,"identity_value":expected,"abs_error":abs(p-expected)})

    # A source-compatible reversible observation generator C gives a unitary group.
    t = 0.37
    evalsC, vecsC = np.linalg.eigh(1j*C)  # C is real skew; iC is Hermitian up to sign
    U = vecsC @ np.diag(np.exp(-1j*evalsC*t)) @ vecsC.conj().T
    unitary_error = float(np.linalg.norm(U.conj().T @ U - np.eye(n)))
    commutation_U_J_error = float(np.linalg.norm(U.real @ J - J @ U.real))

    # CHSH: a complex 4D phase sector is identified with C^2 tensor C^2.
    sx=np.array([[0,1],[1,0]],dtype=complex)
    sz=np.array([[1,0],[0,-1]],dtype=complex)
    I2=np.eye(2,dtype=complex)
    bell=np.array([1,0,0,1],dtype=complex)/math.sqrt(2)
    B0bare=(sz+sx)/math.sqrt(2)
    B1bare=(sz-sx)/math.sqrt(2)
    S=np.kron(sz,B0bare+B1bare)+np.kron(sx,B0bare-B1bare)
    chsh=float(np.real(np.vdot(bell,S@bell)))
    tsirelson_norm=float(np.linalg.norm(S,2))
    # General Tsirelson bound test for these self-adjoint involutions.
    A0, A1 = sz, sx
    B0, B1 = B0bare, B1bare
    commA=A0@A1-A1@A0
    commB=B0@B1-B1@B0
    S2=S@S
    identity4=np.eye(4,dtype=complex)
    tsirelson_identity_error=float(np.linalg.norm(S2-(4*identity4-np.kron(commA,commB))))

    # Detector memory overlap controls the residual path coherence.
    memory_overlaps = []
    for gamma_d in [1.0, 0.5, 0.0]:
        rho_path = 0.5*np.array([[1.0, gamma_d],[gamma_d,1.0]],dtype=complex)
        memory_overlaps.append({
            "detector_overlap":gamma_d,
            "offdiagonal_coherence":float(abs(rho_path[0,1])),
            "minimum_eigenvalue":float(np.linalg.eigvalsh(rho_path).min()),
            "fringe_visibility":float(abs(gamma_d)),
        })

    # Robertson uncertainty equality for Pauli X and Z in a sigma_y eigenstate.
    psi_y=np.array([1,1j],dtype=complex)/math.sqrt(2)
    mean_x=float(np.real(np.vdot(psi_y,sx@psi_y)))
    mean_z=float(np.real(np.vdot(psi_y,sz@psi_y)))
    var_x=float(np.real(np.vdot(psi_y,(sx@ sx)@psi_y))-mean_x**2)
    var_z=float(np.real(np.vdot(psi_y,(sz@ sz)@psi_y))-mean_z**2)
    comm_xz=sx@sz-sz@sx
    comm_expect=complex(np.vdot(psi_y,comm_xz@psi_y))
    robertson_lhs=math.sqrt(max(0,var_x*var_z))
    robertson_rhs=0.5*abs(comm_expect)

    # Finite-dimensional CCR obstruction: trace([X,P])=0 but trace(i hbar I)!=0.
    Xtest=np.diag([0.0,1.0,2.0,3.0])
    Ptest=np.array([[0,1,0,0],[1,0,1,0],[0,1,0,1],[0,0,1,0]],dtype=complex)
    comm_trace=complex(np.trace(Xtest@Ptest-Ptest@Xtest))
    ccr_rhs_trace=4j*1.0

    # Lüders minimal-disturbance projective update and CP/Kraus checks.
    Pz=np.diag([1,0]).astype(complex); Qz=np.diag([0,1]).astype(complex)
    Ksum=Pz.conj().T@Pz+Qz.conj().T@Qz
    rho=np.array([[0.5,0.5],[0.5,0.5]],dtype=complex)
    deph=Pz@rho@Pz+Qz@rho@Qz
    trace_pres=float(np.trace(deph).real)
    positivity=float(np.linalg.eigvalsh(deph).min())
    # Amplitude damping: explicit Kraus operators and Choi positivity.
    gamma=0.27
    K0=np.array([[1,0],[0,math.sqrt(1-gamma)]],dtype=complex)
    K1=np.array([[0,math.sqrt(gamma)],[0,0]],dtype=complex)
    kraus_completeness=float(np.linalg.norm(K0.conj().T@K0+K1.conj().T@K1-I2))
    # Choi J = sum_ab |a><b| tensor T(|a><b|), equivalent to |K><K| sum.
    choi=sum(np.outer(K.reshape(-1),K.reshape(-1).conj()) for K in [K0,K1])
    choi_min_eig=float(np.linalg.eigvalsh((choi+choi.conj().T)/2).min())
    # Apply I tensor T to half of maximally entangled state.
    bell_dm=np.outer(bell,bell.conj())
    entangled_out=sum((np.kron(I2,K)@bell_dm@np.kron(I2,K).conj().T) for K in [K0,K1])
    ancilla_min_eig=float(np.linalg.eigvalsh((entangled_out+entangled_out.conj().T)/2).min())
    ancilla_trace=float(np.trace(entangled_out).real)

    # Pair-conditioned quadratic asymptotic: finite sequence sizes (m,2m).
    pair_quadratic=[]
    for m0 in [5, 10, 20, 50, 100, 500, 1000]:
        sizes=[m0,2*m0]
        q=[s*(s-1)/2 for s in sizes]
        q=[v/sum(q) for v in q]
        pair_quadratic.append({"m":m0,"q1":q[0],"q2":q[1],"limit_q1":0.2,"limit_q2":0.8})

    sources={}
    for name in [
        "DDD_Base_theorie_des_empreintes_complete_order_5.tex",
        "NGeGenBrain_observation_formalisme_full_0.tex",
        "observation_formalisme_full_0_bundle.zip",
    ]:
        p=ROOT/"sources"/name
        sources[name]=hashlib.sha256(p.read_bytes()).hexdigest()

    checks={
        "source_hashes":sources,
        "objects":X,
        "pair_list":[list(x) for x in PAIR_LIST],
        "pair_measure":"uniform on unordered distinct pairs",
        "context_partitions":CONTEXT_PARTITIONS,
        "pair_partition_cells":pair_cells,
        "projection_checks":projection_checks,
        "nested_chain_commutator_norms":nested_comm,
        "crossed_three_object_example":{
            "exact_commutator":C3_exact.tolist(),
            "commutator_matrix_error":exact_three_context_error,
            "rank":int(np.linalg.matrix_rank(C3,tol=1e-8)),
            "minus_C_squared_sqrt_error":exact_H3_error,
            "phase_dimension":int(round(np.trace(Pi3))),
            "J2_plus_projector_error":float(np.linalg.norm(J3@J3+Pi3)),
        },
        "campaign_circulation":{
            "directed_transition_counts":{f"{a}->{b}":count for (a,b),count in edge_counts.items()},
            "matches_single_itinerary_error":campaign_matches_itinerary,
            "log_order_invariance_error":campaign_order_invariance,
            "full_reversal_error":campaign_reverse_error,
            "scope":"canonical for the complete declared campaign log; cross-campaign comparison still needs observation-induced transports"
        },
        "itinerary_phase_compatibility":{
            "reverse_J_plus_J_error":path_phase_reverse_error,
            "reverse_support_error":path_support_reverse_error,
            "alternate_support_difference":path_alternate_support_difference,
            "alternate_J_difference":path_alternate_J_difference,
            "interpretation":"reversal is global conjugation; other reorderings need a phase-gluing check"
        },
        "five_context_complex_structure":{
            "rank_C":rank_C,"kernel_dimension":n-rank_C,
            "phase_dimension_real":osc_dim,"phase_dimension_complex":d,
            "J_errors":J_errors,
            "nonzero_frequencies":sorted([float(x) for x in np.sqrt(np.maximum(evals,0)) if x>1e-6]),
        },
        "tomographic_completeness":{
            "event_indicator_span_rank_in_R10":event_profile_rank,
            "projected_event_indicator_span_rank_in_phase_sector":projected_event_rank,
            "hermitian_effect_span_rank":effect_coordinate_rank,
            "hermitian_operator_space_dimension":d*d,
            "effect_count":len(all_effect_matrices),
            "tomography_rank":int(tomography_rank),
            "tomography_density_reconstruction_error":tomography_error,
            "tomography_trace_error":tomography_trace_error,
            "tomography_minimum_density_eigenvalue":tomography_min_eigenvalue,
        },
        "effect_povm_checks":context_effect_checks,
        "phase_invariance_error":phase_covariance_error,
        "interference_identity":interference,
        "detector_memory_decoherence":memory_overlaps,
        "robertson_uncertainty":{
            "variance_product_sqrt":robertson_lhs,"commutator_lower_bound":robertson_rhs,
            "commutator_expectation":str(comm_expect)
        },
        "finite_CCR_obstruction":{
            "trace_commutator":str(comm_trace),"trace_iI":str(ccr_rhs_trace),
            "dimension":4
        },
        "unitary_observation_flow":{
            "time":t,"U_adjoint_U_error":unitary_error,
            "U_commutes_with_J_error":commutation_U_J_error,
        },
        "bell_chsh":{
            "expectation":chsh,"operator_norm":tsirelson_norm,
            "classical_bound":2.0,"tsirelson_bound":2*math.sqrt(2),
            "tsirelson_identity_error":tsirelson_identity_error,
        },
        "luders_channel":{
            "kraus_completeness_error":float(np.linalg.norm(Ksum-np.eye(2))),
            "trace_after_dephasing":trace_pres,"minimum_eigenvalue_after_dephasing":positivity,
        },
        "amplitude_damping_cp":{
            "gamma":gamma,"kraus_completeness_error":kraus_completeness,
            "choi_min_eigenvalue":choi_min_eig,"ancilla_output_min_eigenvalue":ancilla_min_eig,
            "ancilla_output_trace":ancilla_trace,
        },
        "pair_quadratic_limit":pair_quadratic,
    }

    tests=[]
    def add(name, ok, metric=None):
        tests.append({"name":name,"pass":bool(ok),"metric":metric})
    for x in projection_checks:
        add(f"context {x['context']} projection properties",max(x['symmetric_error'],x['idempotence_error'],x['constant_fixed_error'],x['measure_preservation_error'])<1e-10,x)
    add("nested projections commute",max(nested_comm)<1e-10,nested_comm)
    add("crossed three-object commutator exact matrix",exact_three_context_error<1e-12,exact_three_context_error)
    add("crossed context creates rank-2 phase plane",int(np.linalg.matrix_rank(C3,tol=1e-8))==2,int(np.linalg.matrix_rank(C3,tol=1e-8)))
    add("crossed context polar magnitude sqrt(3)/4",exact_H3_error<1e-10,exact_H3_error)
    add("five-context commutator rank 8",rank_C==8,rank_C)
    add("complex phase sector has dimension four",d==4,d)
    add("reversing itinerary conjugates phase only",path_phase_reverse_error<1e-8 and path_support_reverse_error<1e-8,{"Jrev_plus_J":path_phase_reverse_error,"support_error":path_support_reverse_error})
    add("alternate itinerary phase dependence is detected",path_alternate_support_difference>1e-3 and path_alternate_J_difference>1e-3,{"support_difference":path_alternate_support_difference,"J_difference":path_alternate_J_difference})
    add("campaign circulation is invariant under log read order",campaign_order_invariance<1e-12,campaign_order_invariance)
    add("campaign circulation equals the recorded single-chain itinerary",campaign_matches_itinerary<1e-12,campaign_matches_itinerary)
    add("reversing all campaign transitions conjugates the global phase",campaign_reverse_error<1e-12,campaign_reverse_error)
    for k,v in J_errors.items(): add(k,v<1e-7,v)
    add("event indicators span all pair profiles",event_profile_rank==n,event_profile_rank)
    add("projected event indicators span phase sector",projected_event_rank==osc_dim,projected_event_rank)
    add("context effects span all Hermitian 4x4 matrices",effect_coordinate_rank==d*d,{"rank":effect_coordinate_rank,"target":d*d})
    add("tomography reconstructs a pure density matrix",tomography_rank==d*d and tomography_error<1e-10 and tomography_trace_error<1e-10 and tomography_min_eigenvalue>-1e-10,{"rank":int(tomography_rank),"error":tomography_error,"trace_error":tomography_trace_error,"min_eigenvalue":tomography_min_eigenvalue})
    for x in context_effect_checks:
        add(f"context {x['context']} effect family is positive and complete",x['sum_to_identity_error']<1e-7 and x['minimum_effect_eigenvalue']>-1e-8 and x['J_linearity_error']<1e-7,x)
    add("global phase invariance",phase_covariance_error<1e-7,phase_covariance_error)
    add("detector memory overlap gives nonnegative decoherence states",min(x["minimum_eigenvalue"] for x in memory_overlaps)>=-1e-12 and memory_overlaps[0]["fringe_visibility"]==1 and memory_overlaps[-1]["fringe_visibility"]==0,memory_overlaps)
    add("Robertson uncertainty equality example",robertson_lhs+1e-12>=robertson_rhs and abs(robertson_lhs-robertson_rhs)<1e-12,{"lhs":robertson_lhs,"rhs":robertson_rhs})
    add("finite-dimensional canonical commutator obstruction",abs(comm_trace)<1e-12 and abs(ccr_rhs_trace)>0,{"trace_commutator":str(comm_trace),"trace_iI":str(ccr_rhs_trace)})
    for x in interference: add(f"interference identity at phase {x['phase_rad']}",x['abs_error']<1e-12,x)
    add("observation flow is unitary",unitary_error<1e-10,unitary_error)
    add("observation flow preserves phase structure",commutation_U_J_error<1e-8,commutation_U_J_error)
    add("Bell state reaches Tsirelson value",abs(chsh-2*math.sqrt(2))<1e-12,chsh)
    add("Tsirelson operator norm",abs(tsirelson_norm-2*math.sqrt(2))<1e-12,tsirelson_norm)
    add("Tsirelson algebraic identity",tsirelson_identity_error<1e-12,tsirelson_identity_error)
    add("Luders channel Kraus completeness",np.linalg.norm(Ksum-np.eye(2))<1e-12,float(np.linalg.norm(Ksum-np.eye(2))))
    add("Luders channel positivity and trace",abs(trace_pres-1)<1e-12 and positivity>=-1e-12,{"trace":trace_pres,"min_eigenvalue":positivity})
    add("amplitude damping Kraus completeness",kraus_completeness<1e-12,kraus_completeness)
    add("amplitude damping Choi positivity",choi_min_eig>=-1e-12,choi_min_eig)
    add("amplitude damping complete positivity under tested ancilla",ancilla_min_eig>=-1e-12 and abs(ancilla_trace-1)<1e-12,{"min_eig":ancilla_min_eig,"trace":ancilla_trace})
    add("pair-conditioned quadratic converges toward 1/5,4/5",abs(pair_quadratic[-1]['q1']-.2)<1e-4 and abs(pair_quadratic[-1]['q2']-.8)<1e-4,pair_quadratic[-1])

    failed=[t for t in tests if not t['pass']]
    out={"status":"PASS" if not failed else "FAIL","test_count":len(tests),"passed":len(tests)-len(failed),"failed":len(failed),"details":checks,"tests":tests}
    (VAL/"model_checks_1.json").write_text(json.dumps(out,indent=2,ensure_ascii=False)+"\n")
    (VAL/"model_checks_1.log").write_text("\n".join(("PASS" if t['pass'] else "FAIL")+" | "+t['name']+" | "+json.dumps(t['metric'],ensure_ascii=False) for t in tests)+f"\nSUMMARY {out['passed']}/{out['test_count']} PASS\n")
    print(json.dumps({"status":out['status'],"passed":out['passed'],"test_count":out['test_count'],"rank_C":rank_C,"complex_dimension":d,"effect_span_rank":effect_coordinate_rank,"chsh":chsh,"hashes":sources},indent=2))
    if failed:
        raise AssertionError(f"{len(failed)} numerical checks failed")
    return out

if __name__ == "__main__":
    run_checks()
