#!/usr/bin/env python3
from pathlib import Path
import re, hashlib, json, shutil, subprocess
root=Path(__file__).resolve().parent
tex=root/'NGeGenBrain_observation_formalisme_full_0.tex'
pdf=root/'NGeGenBrain_observation_formalisme_full_0.pdf'
trace=root/'traceabilite_NGeGenBrain_observation_formalisme_full_0.csv'
log=root/'compile_final.log'
s=tex.read_text(encoding='utf-8')
results={
 'tex_exists': tex.exists(),
 'pdf_exists': pdf.exists(),
 'document_begin_end_balanced': s.count(r'\begin{document}')==1 and s.count(r'\end{document}')==1,
 'chapters': len(re.findall(r'^\\chapter\*?\{',s,re.M)),
 'parts': len(re.findall(r'^\\part\{',s,re.M)),
 'theorem_like_environments': sum(len(re.findall(r'\\begin\{'+x+r'\}',s)) for x in ['theoreme','proposition','lemme','corollaire']),
 'proof_environments': len(re.findall(r'\\begin\{proof\}',s)),
 'definitions': len(re.findall(r'\\begin\{definition\}',s)),
 'hypotheses': len(re.findall(r'\\begin\{hypothese\}',s)),
 'source_trace_rows': sum(1 for _ in trace.open(encoding='utf-8-sig'))-1 if trace.exists() else -1,
 'legacy_dossier_mislabel_removed': not bool(re.search(r'Empreinte empirique|\$I_D\$', s, re.I)),
 'control_characters_absent': not any(ord(c)<32 and c not in '\n\r\t' for c in s),
 'critical_terms': {k:(k.casefold() in s.casefold()) for k in ['invariant','variant','multi-échelle','trajectoire',"dossier d'évidence",'non-identifiabilité','reconstruction','contre-exemple']},
}
results['theorem_proof_count_matches'] = results['theorem_like_environments']==results['proof_environments']
results['sources_all_accounted'] = results['source_trace_rows']==58
results['sha256_tex']=hashlib.sha256(tex.read_bytes()).hexdigest()
results['sha256_pdf']=hashlib.sha256(pdf.read_bytes()).hexdigest() if pdf.exists() else None
if pdf.exists() and shutil.which('pdfinfo'):
    pi=subprocess.run(['pdfinfo',str(pdf)],capture_output=True,text=True,check=False).stdout
    m=re.search(r'^Pages:\s+(\d+)',pi,re.M)
    results['pdf_pages']=int(m.group(1)) if m else None
else:
    results['pdf_pages']=None
if log.exists():
    lt=log.read_text(encoding='utf-8',errors='replace')
    results['log_no_undefined_control_sequence']='Undefined control sequence' not in lt
    results['log_no_overfull_boxes']='Overfull \x5chbox' not in lt
    results['log_no_unresolved_references']=not bool(re.search(r'Reference .* undefined|There were undefined references|Label\(s\) may have changed',lt))
    results['log_underfull_hbox_count']=len(re.findall(r'Underfull \x5chbox',lt))
else:
    results['log_no_undefined_control_sequence']=None
    results['log_no_overfull_boxes']=None
    results['log_no_unresolved_references']=None
    results['log_underfull_hbox_count']=None
(root/'verification_NGeGenBrain_observation_formalisme_full_0.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(results,ensure_ascii=False,indent=2))
required=['tex_exists','pdf_exists','document_begin_end_balanced','theorem_proof_count_matches','sources_all_accounted','legacy_dossier_mislabel_removed','control_characters_absent','log_no_undefined_control_sequence','log_no_overfull_boxes','log_no_unresolved_references']
if not all(results.get(k) for k in required) or not all(results['critical_terms'].values()) or not (results.get('pdf_pages') and results['pdf_pages'] > 0): raise SystemExit(1)
