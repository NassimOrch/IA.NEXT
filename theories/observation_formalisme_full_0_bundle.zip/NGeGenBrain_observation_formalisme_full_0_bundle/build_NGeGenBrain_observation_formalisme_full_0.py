from pathlib import Path
import re, json, hashlib, subprocess, shutil, zipfile, csv, os, textwrap

ROOT = Path(__file__).resolve().parent
OUT = ROOT
def source_path(filename):
    direct = ROOT / filename
    bundled = ROOT / 'sources' / filename
    return direct if direct.exists() else bundled
SOURCES = {
    'base': source_path('NGeGenBrain_observation_formalisme.tex'),
    'inverse': source_path('NGeGenBrain_observation_formalisme_next_0.tex'),
    'invariant': source_path('NGeGenBrain_observation_formalisme_next_1.tex'),
}
TARGET_TEX = OUT / 'NGeGenBrain_observation_formalisme_full_0.tex'
WORK = ROOT / 'ng_observation_full_0'
WORK.mkdir(exist_ok=True)

# Extract complete chapters. Original structural \part and \appendix commands are removed;
# the master document owns its one coherent part structure.
def extract_chapters(path, source_id):
    s = path.read_text(encoding='utf-8')
    matches = list(re.finditer(r'^\\chapter(\*)?\{([^}\n]*)\}', s, re.M))
    out = {}
    ordered = []
    for i, m in enumerate(matches):
        end = matches[i+1].start() if i+1 < len(matches) else s.find('\\end{document}', m.start())
        if end < 0: end = len(s)
        chunk = s[m.start():end].strip()
        title = m.group(2).strip()
        chunk = re.sub(r'^\\part\{[^\n]*\}\s*', '', chunk, flags=re.M)
        chunk = re.sub(r'^\\appendix\s*$', '', chunk, flags=re.M)
        chunk = re.sub(r'^\\end\{document\}\s*$', '', chunk, flags=re.M)
        # Prevent an old source from silently controlling appendix mode.
        # Chapter body begins at its title; retain all sections, statements and proofs.
        out[title] = {'title': title, 'chunk': chunk, 'source': source_id, 'star': bool(m.group(1))}
        ordered.append(title)
    return out, ordered

chapters = {}
source_orders = {}
for sid, path in SOURCES.items():
    ch, order = extract_chapters(path, sid)
    chapters[sid] = ch
    source_orders[sid] = order

# Normalize punctuation differences between curly and straight apostrophes in manually curated chapter names.
def norm_title(x):
    return x.replace('’', "'").replace('‘', "'").replace('–', '--').replace('—', '--').strip()
def resolve_title(sid, title):
    if title in chapters[sid]: return title
    target = norm_title(title)
    hits = [k for k in chapters[sid] if norm_title(k) == target]
    if len(hits) == 1: return hits[0]
    raise KeyError(f"Cannot resolve title {sid}:{title}; candidates={hits}")

# All chapters are accounted for below either in the integrated argument or in the documentary appendices.
main_parts = [
    ('I. Fondations, types d’objets et sémantique des empreintes', [
        ('base','Objet, portée et statuts épistémiques'),
        ('base','Objets, contextes, sondes et mesures'),
        ('base','Empreinte informationnelle et identité observationnelle'),
        ('invariant','Pourquoi l’empreinte ne doit pas être confondue avec l’observation entière'),
        ('invariant','Quotient invariant et information résiduelle'),
        ('invariant','Quand une décomposition additive est-elle définie de façon unique ?'),
        ('base','Redondance et fermeture observationnelle'),
        ('inverse','De l’empreinte à la reconstruction : objets et statuts'),
    ]),
    ('II. Échelles, facettes, temps et observation en direct', [
        ('base','Échelles de sondes et capacité observationnelle'),
        ('base','Fonction de seuil et géométrie des fibres'),
        ('invariant','Un ordre produit des échelles observationnelles'),
        ('base','Trajectoires et signatures temporelles'),
        ('invariant','Traces live, histoire et reconstruction temporelle'),
        ('base','Stabilité, non-stationnarité et estimation en ligne'),
        ('inverse','Empreinte de trajectoire et prédiction continue'),
        ('inverse','Mise à jour en ligne de l’ensemble inverse'),
    ]),
    ('III. Sondes, vues multiples et interventions', [
        ('base','Facettes observationnelles complémentaires'),
        ('base','Sélection active de sondes et recherche discriminante'),
        ('base','Interventions, contrôles et effets mesurés'),
        ('invariant','Conditions d’identifiabilité des composants invariant et variant'),
        ('inverse','Interventions et reconstruction causale'),
    ]),
    ('IV. Du problème inverse aux mécanismes exécutables', [
        ('base','Définition d’un mécanisme exécutable'),
        ('inverse','Sémantique exécutable d’un mécanisme'),
        ('inverse','Équivalence observationnelle, équivalence mécaniste et non-identifiabilité'),
        ('inverse','Quand l’empreinte identifie-t-elle le mécanisme ?'),
        ('invariant','Reconstruction comme génération conditionnelle d’une observation'),
        ('inverse','Synthèse de mécanismes et représentation des dépendances'),
        ('base','Doubles parcours top-down et bottom-up'),
        ('inverse','Abstraction mécaniste et quotient des états'),
        ('inverse','Composition exécutable des mécanismes'),
        ('inverse','Hiérarchie récursive et raffinement des mécanismes'),
    ]),
    ('V. Incertitude, provenance, validation et niveaux de preuve', [
        ('base','Incertitude et données manquantes'),
        ('base','Provenance et intégrité de la preuve'),
        ('inverse','Validation indépendante du modèle reconstruit'),
        ('inverse','Niveaux de réussite pour un modèle de langage reconstruit'),
        ('inverse','Garanties possibles et hypothèses qu’il est interdit de cacher'),
        ('invariant','Ce que cette théorie autorise et n’autorise pas à conclure'),
    ]),
    ('VI. Procédure complète, architecture et critères d’arrêt', [
        ('base','Protocole d’observation profonde'),
        ('base','Spécification d’architecture d’un observateur continu'),
        ('invariant','Procédure minimale invariant--variant--dynamique'),
        ('inverse','Procédure inverse complète'),
        ('inverse','Comment NGeGenBrain doit convertir une empreinte en mécanisme'),
        ('inverse','Critères d’arrêt honnêtes et continuation de recherche'),
    ]),
    ('VII. Audit logiciel, limites présentes et obligations de réalisation', [
        ('base','Audit du pipeline d’observation de NGeGenBrain v3.1'),
        ('base','Matrice d’audit v3.1 par rapport au formalisme'),
        ('base','Questions ouvertes et obligations d’implémentation'),
    ]),
]

# Chapters preserved in documentary appendices because their role is registry, summary, checklist,
# notation, or historical conclusion rather than a new argumentative step.
appendix_chapters = [
    ('base','Résumé des résultats établis'),
    ('base','Checklist de conformité d’une étude d’observation'),
    ('base','Notation'),
    ('base','Contrôles de cohérence mathématique'),
    ('base','Conclusion'),
    ('inverse','Théorèmes centraux de la théorie inverse'),
    ('inverse','Checklist finale de rigueur'),
    ('inverse','Notation'),
    ('inverse','Conclusion formelle'),
    ('invariant','Registre des résultats démontrés'),
    ('invariant','Checklist d’application'),
    ('invariant','Conclusion'),
]
# The chapter which states the permitted/non-permitted conclusions is already integrated in Part V.
# No source chapter is silently dropped. The invariant source has a separate general conclusion and registry.

# Correct terminology in the inverse chapter: a dossier is not automatically a fingerprint.
def normalized_chunk(sid, title, chunk):
    # Source chapter title adjustments for a single coherent master.
    if sid == 'inverse' and norm_title(title) == norm_title("De l'empreinte à la reconstruction : objets et statuts"):
        # Keep the chapter's subject, but correct the embedded overloaded definition below.
        old = r'''\\begin{definition}[Empreinte empirique]
L'empreinte empirique dérivée de $D$ est la représentation
\\[
I_D=\\bigl(\\pi,\\{e:e\\in D\\},\\text{règles de comparaison},\\text{incertitudes déclarées}\\bigr).
\\]
Elle n'est pas seulement un vecteur de statistiques : elle inclut les conditions d'acquisition, les essais négatifs, les interventions et la provenance. Si des données brutes sont abandonnées au profit de résumés, cette réduction est déclarée comme une transformation potentiellement irréversible.
\\end{definition}'''
        new = r'''\\begin{definition}[Dossier empirique structuré]
Le dossier empirique structuré dérivé de $D$ est la représentation
\\[
\\mathfrak D_D=\\bigl(\\pi, D, \\text{règles de comparaison}, \\text{incertitudes déclarées}\\bigr).
\\]
Il conserve, selon le contrat de stockage déclaré, les conditions d'acquisition, les essais négatifs, les interventions et la provenance. Il n'est pas appelé « empreinte » au sens strict : une empreinte est une application (ou une famille d'applications) calculée à partir d'un objet d'observation selon un protocole. Si des données brutes sont abandonnées au profit de résumés, cette réduction est déclarée comme potentiellement irréversible et le dossier doit conserver le lien vers les données disponibles, leurs transformations et leurs limites.
\\end{definition}'''
        # raw strings have escaped backslashes as two chars by design; replace only if exact source block match exists.
        if old in chunk:
            chunk = chunk.replace(old, new, 1)
        else:
            # Robust fallback bounded by theorem-like environment, preserving all original details.
            pat = re.compile(r'\\begin\{definition\}\[Empreinte empirique\].*?\\end\{definition\}', re.S)
            repl = (r'\\begin{definition}[Dossier empirique structuré]' '\n'
                    r'Le dossier empirique structuré dérivé de $D$ est la représentation' '\n'
                    r'\\[' '\n'
                    r'\\mathfrak D_D=\\bigl(\\pi,D,\\text{règles de comparaison},\\text{incertitudes déclarées}\\bigr).' '\n'
                    r'\\]' '\n'
                    r'Il conserve, selon le contrat de stockage déclaré, les conditions d’acquisition, les essais négatifs, les interventions et la provenance. Il ne doit pas être confondu avec une empreinte au sens strict, qui est une application (ou famille d’applications) calculée à partir d’un objet d’observation. Toute réduction des données brutes en résumés est déclarée comme potentiellement irréversible.' '\n'
                    r'\\end{definition}')
            chunk, n = pat.subn(repl, chunk, count=1)
            if n != 1:
                raise RuntimeError('Could not harmonize the empirical fingerprint definition')
    # Fix a proof whose stated example used a trivial family while claiming nontrivial transformations.
    if sid == 'invariant' and norm_title(title) == norm_title('Quand une décomposition additive est-elle définie de façon unique ?'):
        marker = r'Prenons \(S_t=t\)'
        left = chunk.find(marker)
        if left >= 0:
            end_phrase = 'constance temporelle.'
            right = chunk.find(end_phrase, left)
            if right < 0:
                raise RuntimeError('Could not locate end of the legacy invariance/time proof')
            right += len(end_phrase)
            replacement = r"Considérons $E=\mathbb R^2$, l'action non triviale $g_a(x,z)=(ax,z)$ pour $a>0$, et l'observable $Q(x,z)=z$. Alors $Q(g_a(x,z))=Q(x,z)$ pour tout $a>0$, donc $Q$ est invariante sous cette famille. La trajectoire $y_t=(0,t)$ vérifie cependant $Q(y_t)=t$, qui varie avec $t$. L'invariance sous une action déclarée ne signifie donc pas constance temporelle."
            chunk = chunk[:left] + replacement + chunk[right:]
        elif 'L’invariance de $q$ sous $\\mathcal G$ n’implique donc pas la constance temporelle' in chunk or 'L\'invariance de $q$ sous $\\mathcal G$ n\'implique donc pas la constance temporelle' in chunk:
            # Already corrected upstream; preserve the reviewed proof.
            pass
        elif "L'invariance de $q$ sous" in chunk and "x(t)=(0,t)" in chunk:
            pass
        else:
            raise RuntimeError('Could not locate a known version of the invariance/time proof')
    if sid == 'base' and norm_title(title) in [norm_title("Audit du pipeline d'observation de NGeGenBrain v3.1"), norm_title('Matrice d’audit v3.1 par rapport au formalisme')]:
        note = r'\begin{remarque}[Portée historique]Ce chapitre reprend un audit consigné dans la source initiale. Il ne vaut pas nouvelle exécution du code v3.1 dans le cadre de la présente refonte ; ses constats restent attachés au périmètre et aux preuves cités dans cette source.\end{remarque}'
        chunk = re.sub(r'^(\\chapter\*?\{[^}]*\}\s*)', lambda m: m.group(1) + '\n' + note + '\n\n', chunk, count=1)
    # Strip legacy part commands and appendix transitions; master defines them.
    chunk = re.sub(r'^\\part\{[^\n]*\}\s*', '', chunk, flags=re.M)
    chunk = re.sub(r'^\\appendix\s*$', '', chunk, flags=re.M)
    chunk = re.sub(r'^\\end\{document\}\s*$', '', chunk, flags=re.M)
    return chunk.strip()

# Custom master preamble and new harmonization chapters. This is the theory's common contract layer.
preamble = r'''\documentclass[11pt,oneside]{book}
\usepackage[utf8]{inputenc}
\usepackage[T1]{fontenc}
\usepackage[french]{babel}
\usepackage{lmodern}
\usepackage[a4paper,margin=2.45cm,headheight=28pt]{geometry}
\usepackage{amsmath,amssymb,amsthm,mathtools,bm,stmaryrd}
\usepackage{booktabs,longtable,tabularx,array,enumitem}
\usepackage{xcolor,microtype,url,hyperref,listings,fancyhdr}
\hypersetup{colorlinks=true,linkcolor=blue!50!black,citecolor=blue!50!black,urlcolor=blue!50!black,pdftitle={NGeGenBrain : formalisme unifié de l'observation et de la reconstruction},pdfsubject={Empreintes informationnelles, invariants, variations, observation multi-échelle et reconstruction mécaniste}}
\setlist{itemsep=2pt,topsep=4pt}
\setlength{\emergencystretch}{3em}
\setlength{\headheight}{28pt}
\setlength{\tabcolsep}{4pt}
\setcounter{tocdepth}{2}
\setcounter{secnumdepth}{3}
\pagestyle{fancy}\fancyhf{}
\fancyhead[L]{\small NGeGenBrain -- théorie unifiée}
\fancyhead[R]{\small Observation, empreintes et mécanismes}
\fancyfoot[C]{\thepage}
\newtheorem{theoreme}{Théorème}[chapter]
\newtheorem{proposition}[theoreme]{Proposition}
\newtheorem{lemme}[theoreme]{Lemme}
\newtheorem{corollaire}[theoreme]{Corollaire}
\newtheorem{hypothese}[theoreme]{Hypothèse explicite}
\theoremstyle{definition}
\newtheorem{definition}[theoreme]{Définition}
\newtheorem{convention}[theoreme]{Convention}
\newtheorem{critere}[theoreme]{Critère}
\newtheorem{algorithme}[theoreme]{Algorithme}
\theoremstyle{remark}
\newtheorem{remarque}[theoreme]{Remarque}
\newtheorem{contreexemple}[theoreme]{Contre-exemple}
\newcommand{\X}{\mathcal X}
\newcommand{\Y}{\mathcal Y}
\newcommand{\Z}{\mathcal Z}
\newcommand{\Pcal}{\mathcal P}
\newcommand{\Fcal}{\mathcal F}
\newcommand{\Gcal}{\mathcal G}
\newcommand{\Lcal}{\mathcal L}
\newcommand{\Zcal}{\mathcal Z}
\newcommand{\Ycal}{\mathcal Y}
\newcommand{\Tcal}{\mathcal T}
\newcommand{\Ecal}{\mathcal E}
\newcommand{\Hcal}{\mathcal H}
\newcommand{\Rcal}{\mathcal R}
\newcommand{\Ical}{\mathcal I}
\newcommand{\Bcal}{\mathcal B}
\newcommand{\Mcal}{\mathcal M}
\newcommand{\Acal}{\mathcal A}
\newcommand{\Ucal}{\mathcal U}
\newcommand{\Vcal}{\mathcal V}
\newcommand{\Scal}{\mathcal S}
\newcommand{\Dcal}{\mathcal D}
\newcommand{\U}{\mathcal U}
\newcommand{\W}{\mathcal W}
\newcommand{\N}{\mathbb N}
\newcommand{\R}{\mathbb R}
\newcommand{\Prob}{\mathbb P}
\newcommand{\Exp}{\mathbb E}
\newcommand{\1}{\mathbf 1}
\newcommand{\dd}{\mathrm d}
\newcommand{\cl}{\operatorname{cl}}
\newcommand{\Id}{\operatorname{Id}}
\newcommand{\TV}{\operatorname{TV}}
\newcommand{\KL}{\operatorname{KL}}
\newcommand{\argmin}{\operatorname*{arg\,min}}
\newcommand{\argmax}{\operatorname*{arg\,max}}
\newcommand{\supp}{\operatorname{supp}}
\newcommand{\suppo}{\operatorname{supp}}
\newcommand{\diam}{\operatorname{diam}}
\newcommand{\rank}{\operatorname{rank}}
\newcommand{\Var}{\operatorname{Var}}
\newcommand{\Cov}{\operatorname{Cov}}
\newcommand{\norm}[1]{\left\lVert #1\right\rVert}
\newcommand{\abs}[1]{\left\lvert #1\right\rvert}
\newcommand{\set}[1]{\left\{#1\right\}}
\newcommand{\paren}[1]{\left(#1\right)}
\newcommand{\bracks}[1]{\left[#1\right]}
\newcommand{\eps}{\varepsilon}
\newcommand{\calO}{\mathcal O}
\newcommand{\given}{\,\middle|\,}
\newcommand{\doop}{\operatorname{do}}
\newcommand{\sem}[1]{\llbracket #1 \rrbracket}
\newcommand{\Inv}{\operatorname{Inv}}
\newcommand{\Pred}{\operatorname{Pred}}
\newcommand{\MechEq}{\equiv_{\mathrm m}}
\newcommand{\ObsEq}{\equiv_{\mathrm{obs}}}
\newcommand{\Trace}{\operatorname{Trace}}
\title{\Huge\bfseries NGeGenBrain : formalisme unifié de l'observation et de la reconstruction\\[0.6em]
\Large Empreintes informationnelles, invariants, variations, multi-échelle, temps et mécanismes exécutables}
\author{Théorie consolidée et audit mathématique}
\date{Version full\_0 -- 28 octobre 2026}
\begin{document}
\hypersetup{pageanchor=false}
\frontmatter
\maketitle
\thispagestyle{empty}
\begin{center}\begin{minipage}{0.92\textwidth}
\textbf{Objet du document.} Ce traité refond en une seule chaîne logique les fondations de l'observation par sondes, les empreintes informationnelles, la théorie inverse des mécanismes et la décomposition invariant--variant--dynamique. Il ne prétend pas qu'une observation finie détermine universellement l'intérieur d'un modèle : il donne les conditions exactes sous lesquelles une reconstruction est possible, unique, approchée ou non identifiable.

\medskip
\textbf{Règle de lecture scientifique.} Une définition fixe un vocabulaire ; un axiome ou une hypothèse ajoute une condition ; une proposition ou un théorème n'est déclaré démontré que sous ses hypothèses ; un résultat expérimental reste relatif au protocole exécuté. L'absence d'identifiabilité est un résultat et doit être conservée comme telle.

\medskip
\textbf{Principe central.} Une empreinte n'est pas nécessairement un invariant, n'est pas automatiquement suffisante pour reconstruire une observation, et n'identifie pas automatiquement un mécanisme. L'invariance, la suffisance et l'identification sont des propriétés à définir et à démontrer séparément.
\end{minipage}\end{center}
\clearpage
\tableofcontents
\hypersetup{pageanchor=true}
\mainmatter
'''

intro_chapter = r'''\chapter{Contrat mathématique commun et décisions d'harmonisation}
\section{Les objets qu'il est interdit de confondre}
La théorie unifiée distingue au minimum les objets suivants. Une exécution source est une trajectoire dans un espace d'exécutions. Une observation est le résultat d'un protocole appliqué à cette exécution. Un enregistrement est la représentation conservée du résultat, avec ses horodatages, statuts de mesure, provenance et incertitudes. Une empreinte est une application déterminée sur un espace d'observations ou d'objets. Un invariant est une propriété d'une application relativement à une famille de transformations déclarée. Un dossier d'évidence conserve les enregistrements et leur provenance. Un mécanisme est un objet exécutable avec une sémantique et des interfaces.

\begin{definition}[Observation induite par un protocole]
Soient $\Omega$ un espace d'exécutions et $\Ycal$ un espace d'enregistrements. Un protocole déterministe $\pi$ induit une application $O_\pi:\Omega\to\Ycal$. Si l'acquisition ou l'exécution est stochastique, elle est décrite au niveau approprié par un noyau probabiliste $K_\pi(\dd y\mid\omega)$ ; une valeur observée est alors une réalisation, et non le noyau lui-même.
\end{definition}
\begin{definition}[Empreinte relative à un protocole]
Pour un espace d'observations $\Ycal$, une empreinte est une application $I_\pi:\Ycal\to\Zcal$. L'empreinte composée d'une exécution est $F_\pi=I_\pi\circ O_\pi$ dans le cas déterministe. Le qualificatif « invariant » n'est ajouté que si une invariance sous une famille de transformations est explicitement définie et vérifiée.
\end{definition}
\begin{definition}[Dossier d'évidence]
Un dossier d'évidence $\mathfrak D$ est une collection versionnée d'enregistrements, de protocoles, de transformations, d'incertitudes, de résultats négatifs et de liens de provenance. Un dossier peut contenir plusieurs empreintes et les données qui les ont produites ; il ne se réduit pas, par définition, à une empreinte.
\end{definition}
\begin{definition}[Invariance déclarée]
Soit $G$ une famille de transformations agissant sur $\Ycal$. Une application $I:\Ycal\to\Zcal$ est invariante sous $G$ si, chaque fois que $g\cdot y$ est défini, $I(g\cdot y)=I(y)$ pour tout $g\in G$ et $y$ de son domaine déclaré. Toute affirmation d'invariance doit nommer la famille $G$, le domaine et la relation d'égalité considérée.
\end{definition}
\section{Propriétés distinctes}
Les affirmations suivantes sont indépendantes en général : (i) une signature est bien définie ; (ii) elle est invariante ; (iii) elle est injective ; (iv) elle est suffisante pour une propriété cible ; (v) elle identifie une classe de mécanismes ; (vi) elle est estimée avec précision à partir d'un échantillon ; (vii) elle est calculable dans un budget fini. Aucune de ces propriétés ne découle des autres sans hypothèse supplémentaire.

\begin{proposition}[Invariance et reconstruction sont des propriétés distinctes]
Une application invariante non constante peut être non injective ; une application injective n'est pas nécessairement invariante sous une famille de transformations non triviale.
\end{proposition}
\begin{proof}
Pour la première assertion, prenons $\Ycal=\mathbb R^2$, l'action $g_a(x,z)=(ax,z)$ pour $a>0$ et $I(x,z)=z$. Alors $I$ est invariant sous cette action mais n'est pas injectif. Pour la seconde, sur $\Ycal=\mathbb R$, considérons une transformation $g(y)=y+1$ et $I(y)=y$ : $I$ est injectif, mais $I(g(y))=y+1\ne y=I(y)$.\end{proof}
\section{Règles d'harmonisation appliquées dans le traité}
\begin{enumerate}[label=\arabic*.]
\item Le mot \emph{empreinte} désigne une application ou une famille indexée d'applications. Le mot \emph{invariant} désigne une propriété prouvée relativement à une famille de transformations, et non une essence supposée.
\item Une trace temporelle, un enregistrement, une empreinte et un dossier d'évidence sont des types d'objets distincts. Une réduction d'un dossier à une empreinte est une opération dont la perte d'information doit être évaluée.
\item Un seuil, une distance ou une hiérarchie n'est défini qu'après avoir précisé domaine, codomaine, ordre, convention de bord et cas infinis.
\item Une égalité exacte, une égalité presque sûre, une borne d'erreur et une non-différence statistiquement détectée ne sont jamais interchangeables.
\item Une intervention identifie d'abord un effet sous un protocole précis. Une interprétation causale plus large exige des hypothèses d'assignation, de contrôle, de mesure et de transport déclarées.
\item Une composition syntaxique de modules ne garantit ni la compatibilité de leurs interfaces, ni l'autonomie d'exécution, ni la fidélité au système source.
\item Les résultats établis sur une classe finie de tests ne sont pas des garanties universelles sur un domaine infini.
\item Un hash vérifie une intégrité relative à une référence fiable ; il ne prouve ni la vérité d'une donnée ni la validité d'une interprétation.
\item Les fonctions de perte, les scores agrégés et les résumés n'effacent pas les résultats par facette, les contre-exemples, ni les candidats compatibles alternatifs.
\item Une affirmation de réussite de NGeGenBrain doit mentionner le domaine, le protocole, les conditions d'exécution et les niveaux non établis.
\end{enumerate}
\section{Décision sur les sources}
Les trois documents sources ne sont pas traités comme des autorités infaillibles. Leurs définitions et démonstrations sont réintégrées dans l'argument commun ; les répétitions documentaires sont déplacées en annexes ; les divergences terminologiques sont signalées ; les corrections locales identifiées lors de la consolidation sont consignées dans l'audit. La traceabilité en fin de volume indique, pour chaque chapitre source, son emplacement ou sa conservation documentaire.
'''

conclusion_chapter = r'''\chapter{Synthèse générale et chaîne logique complète}
La théorie entière forme la chaîne logique suivante :
\[
\begin{aligned}
&\text{exécution source et environnement}\\
&\quad\downarrow\;\text{protocole d'acquisition déclaré}\\
&\text{événements et enregistrements observationnels}\\
&\quad\downarrow\;\text{application de signature}\\
&\text{empreintes multi-facettes, multi-échelles et temporelles}\\
&\quad\downarrow\;\text{quotients, invariants déclarés et résidus}\\
&\text{contraintes empiriques et ensemble de mécanismes compatibles}\\
&\quad\downarrow\;\text{expériences discriminantes/interventions}\\
&\text{candidats identifiables relativement à une classe et un protocole}\\
&\quad\downarrow\;\text{synthèse, abstraction et composition exécutables}\\
&\text{mécanisme composé autonome}\\
&\quad\downarrow\;\text{tests indépendants et ré-observation}\\
&\text{validation, réfutation, révision ou incertitude résiduelle}.
\end{aligned}
\]
Chaque flèche constitue une obligation de preuve ou de mesure, non une transformation garantie automatiquement. Le passage à l'étape suivante n'autorise pas à déclarer l'étape précédente réussie sans ses critères. En particulier, une empreinte stable ne reconstitue pas ses variations si celles-ci ne sont pas déterminées par l'empreinte ; un mécanisme compatible n'est pas nécessairement identifié ; un mécanisme comportementalement fidèle n'est pas nécessairement mécanistiquement équivalent.

La contribution de la décomposition invariant--variant--dynamique est de rendre explicite l'information que la signature quotientée conserve et celle que le dossier doit encore porter. La paire $(I,V)$ reconstruit un enregistrement exactement si elle est injective. Une décomposition additive n'est unique qu'avec des conditions de séparation appropriées. En temps continu, les échantillons finis ne déterminent pas une trajectoire arbitraire ; toute garantie d'approximation dépend de la régularité, du maillage et du modèle d'erreur déclarés.

Pour NGeGenBrain, le résultat pratique n'est donc pas « calculer l'empreinte puis connaître le LLM », mais construire, maintenir et tester un ensemble traçable de contraintes qui sépare progressivement les mécanismes candidats sans masquer l'ambiguïté. La reconstruction est un programme expérimental récursif : observer, formaliser, intervenir, composer, re-observer, chercher les contre-exemples et réviser.
'''

# Verify source inventory and build chapter map.
all_used = set()
parts_text = []
trace_rows = []
for part_title, items in main_parts:
    parts_text.append('\\part{' + part_title + '}\n')
    for sid, title in items:
        title = resolve_title(sid, title)
        item = chapters[sid][title]
        all_used.add((sid,title))
        chunk = normalized_chunk(sid, title, item['chunk'])
        # Duplicate original chapter headings are unique except intentional cross-document concepts.
        parts_text.append(chunk + '\n')
        trace_rows.append({'source': sid, 'chapter': title, 'destination_part': part_title,
                           'decision': 'Intégration dans le corps argumentatif; contenu et preuves conservés, avec harmonisation locale documentée.'})

# Add the source audit and implementation matrix as historical evidence, clearly scoped.
# Source inventory uses file version and date; this is not represented as a new code audit.
# Place in Part VII, after audit chapter.
# Chapter bodies with summaries/checklists/notational material are retained in documentary appendices.
parts_text.insert(0, '')

master_parts = '\n'.join(parts_text)
# Insert the harmonization chapter immediately after the first foundation chapter to set vocabulary before definitions.
anchor = chapters['base']['Objet, portée et statuts épistémiques']['chunk']
# The chapter is inserted after the first source chapter in the part, not in the preamble.
first_chunk_norm = normalized_chunk('base','Objet, portée et statuts épistémiques', anchor)
needle = first_chunk_norm + '\n'
if needle not in master_parts:
    raise RuntimeError('Could not locate first chapter insertion point')
master_parts = master_parts.replace(needle, needle + '\n' + normalized_chunk('base','Objet, portée et statuts épistémiques', intro_chapter.replace('\\chapter{Contrat mathématique commun et décisions d’harmonisation}', '\\chapter{Contrat mathématique commun et décisions d’harmonisation}')) + '\n', 1)

# Appendices retain the source summaries, checklists and notation registers instead of discarding them.
appendix_text = ['\\appendix\n\\part{Registres, notations et traçabilité documentaire}\n']
appendix_text.append(r'''\chapter{Notation unifiée}
\begin{longtable}{>{\raggedright\arraybackslash}p{0.25\textwidth} >{\raggedright\arraybackslash}p{0.65\textwidth}}
\toprule
Symbole & Sens retenu dans le document unifié \\
\midrule\endhead
$\Omega$ & Espace des exécutions ou trajectoires source. \\
$\Ycal$ & Espace des observations ou enregistrements admissibles. \\
$\pi$ & Protocole : contexte, entrées, sondes, interventions, ordonnanceur, budgets, versions et règles de mesure. \\
$O_\pi$ & Application d'observation déterministe ; pour le cas stochastique, noyau d'observation déclaré. \\
$I_\pi$ & Empreinte ou application de signature relative au protocole. \\
$G$ & Famille déclarée de transformations relativement à laquelle une invariance peut être affirmée. \\
$S$ & Composante structurelle/invariante, seulement si son invariance est démontrée sous $G$. \\
$V$ & Composante variante ou résiduelle visant à distinguer des observations appartenant à une même fibre de $S$. \\
$\tau$ & Trace ordonnée d'événements/états et de métadonnées temporelles. \\
$\mathfrak D$ & Dossier d'évidence avec provenance, incertitudes, données et résultats négatifs. \\
$\Mcal$ & Classe déclarée de mécanismes candidats. \\
$\Inv_{\pi,C}(\mathfrak D)$ & Ensemble de mécanismes compatibles avec le dossier selon le protocole et le critère $C$. \\
$\sim_I$ & Équivalence observationnelle induite par l'égalité des empreintes. \\
$\MechEq$ & Équivalence mécaniste, toujours relative à une définition de mécanisme et de morphisme déclarée. \\
$\Lambda,\mathfrak F,\Delta$ & Ordres d'échelle de résolution, de famille de sondes et de résolution temporelle. \\
$\Sigma$ & Produit d'indexation multi-échelle ; l'ordre produit ne vaut que si chaque axe possède un sens de raffinement explicite. \\
\bottomrule
\end{longtable}
\paragraph{Conventions.} Les sources emploient parfois $I$ pour des objets de nature différente. Le présent document réserve $I_\pi$ à une empreinte (application de signature) et $\mathfrak D$ à un dossier d'évidence. Une classe d'équivalence d'états n'est jamais identifiée à l'état brut. Une quantité « stable » au sens empirique ne devient pas un invariant exact sans quantificateurs et hypothèses supplémentaires.
''')

# Include all source appendix chapters, except the reusable title/summary chapters integrated in new synthesis,
# while recording the exact content and source identity.
appendix_heading = r'''\chapter{Registres de résultats, checklists et conclusions des documents sources}
Les sous-sections suivantes conservent les registres synthétiques et les checklists portés par les sources. Elles sont documentaires : en cas de différence de vocabulaire, les définitions et règles d'harmonisation de ce volume prévalent. Ces registres ne remplacent pas les démonstrations dans le corps du traité.
'''
appendix_text.append(appendix_heading)
appendix_titles = {
    ('base','Résumé des résultats établis'), ('base','Checklist de conformité d’une étude d’observation'),
    ('base','Notation'), ('base','Contrôles de cohérence mathématique'), ('base','Conclusion'),
    ('inverse','Théorèmes centraux de la théorie inverse'), ('inverse','Checklist finale de rigueur'),
    ('inverse','Notation'), ('inverse','Conclusion formelle'),
    ('invariant','Registre des résultats démontrés'), ('invariant','Checklist d’application'), ('invariant','Conclusion'),
}
for sid, title in appendix_chapters:
    title = resolve_title(sid, title)
    item = chapters[sid][title]
    chunk = normalized_chunk(sid, title, item['chunk'])
    if sid == 'inverse' and title == 'Notation':
        chunk = chunk.replace(r'$I_D$ & Empreinte empirique dérivée du dossier', r'$\mathfrak D_D$ & Dossier empirique structuré dérivé du dossier')
    # Replace top-level chapter headings with sections inside the register appendix, preserving their contents.
    chunk = re.sub(r'^\\chapter\*?\{[^}\n]*\}', lambda m: '\\section*{' + m.group(0).split('{',1)[1].rsplit('}',1)[0] + '}', chunk, count=1)
    # Avoid a duplicate "Conclusion" heading collision by prefixing source.
    if title.startswith('Conclusion'):
        chunk = chunk.replace('\\section*{' + title + '}', '\\section*{Conclusion -- source ' + sid + '}')
    appendix_text.append(chunk + '\n')
    all_used.add((sid,title))
    trace_rows.append({'source': sid, 'chapter': title, 'destination_part': 'Annexe - registres',
                       'decision': 'Conservé en annexe documentaire; vocabulaire harmonisé par la convention commune.'})

# Put the original audit chapter in its historically accurate scope by adding a heading note before it.
# (Its chapter itself is integrated in Part VII; note makes clear its claims are a dated snapshot.)
# This note is part of the prose immediately before the chapter, inserted by locating its chapter block.
for sid,title in [('base','Audit du pipeline d’observation de NGeGenBrain v3.1'),('base','Matrice d’audit v3.1 par rapport au formalisme')]:
    pass

# Add provenance/source chapter traceability in a human-readable longtable.
appendix_text.append(r'''\chapter{Matrice de traçabilité des sources}
Le tableau indique l'emplacement de chaque chapitre des trois sources exploitées. « Intégration » signifie que le chapitre complet est repris dans le corps théorique, sous réserve des corrections terminologiques explicites décrites dans le présent volume. « Annexe » signifie que le contenu sert surtout de registre, checklist, notation ou conclusion récapitulative et a été conservé en section documentaire.
\begin{longtable}{>{\raggedright\arraybackslash}p{0.14\textwidth} >{\raggedright\arraybackslash}p{0.39\textwidth} >{\raggedright\arraybackslash}p{0.14\textwidth} >{\raggedright\arraybackslash}p{0.25\textwidth}}
\toprule Source & Chapitre source & Destination & Décision \\
\midrule\endhead
''')
for row in trace_rows:
    label = {'base':'Formalisme initial','inverse':'Next 0 - théorie inverse','invariant':'Next 1 - invariant/variant'}[row['source']]
    title = row['chapter'].replace('&','\\&')
    dest = 'Corps' if row['destination_part'] != 'Annexe - registres' else 'Annexe'
    dec = 'Contenu et preuves repris' if dest == 'Corps' else 'Registre source conservé'
    appendix_text.append(f'{label} & {title} & {dest} & {dec} \\\\\n')
appendix_text.append(r'''\bottomrule
\end{longtable}
\section{Fichiers sources et limite de provenance}
Les sources utilisées pour cette refonte sont les trois fichiers locaux suivants : \url{NGeGenBrain_observation_formalisme.tex}, \url{NGeGenBrain_observation_formalisme_next_0.tex} et \url{NGeGenBrain_observation_formalisme_next_1.tex}. Le nom \url{NGeGenBrain_observation_formalisme_0.tex} ne correspondait pas à un fichier distinct dans l'environnement de travail ; il n'a donc pas été inventé ni traité comme une source indépendante. La suite \texttt{next\_1} est incluse afin de préserver la formalisation de l'idée invariant--variant--dynamique déjà produite.

\section{Correction de portée d'audit}
Les chapitres relatifs à l'audit de NGeGenBrain v3.1 décrivent le constat logiciel rapporté dans la source initiale et son périmètre d'observation à cette date. Ils ne prétendent pas constituer une ré-exécution d'un audit du logiciel actuel. Une affirmation logicielle doit rester liée à la version, au code et aux preuves effectivement examinés.
''')
appendix_text.append(conclusion_chapter)

# Keep all non-appendix source chapters accounted for. The custom new chapters are not source chapters.
expected = {(sid,t) for sid,order in source_orders.items() for t in order}
missing = expected - all_used
if missing:
    raise RuntimeError('Unaccounted source chapters: ' + repr(sorted(missing)))

master = preamble + '\n' + master_parts + '\n' + '\n'.join(appendix_text) + '\n' + r'\backmatter' + '\n' + r'\end{document}' + '\n'
# Integrate the methodological language rule into the preceding non-identifiability
# proof. This preserves the content while avoiding a separate, nearly empty page.
cor_start = master.find(r'\begin{corollaire}[Règle de langage scientifique]')
if cor_start >= 0:
    cor_end = master.find(r'\end{proof}', cor_start)
    if cor_end >= 0:
        cor_end += len(r'\end{proof}')
        previous_proof_end = master.rfind(r'\end{proof}', 0, cor_start)
        if previous_proof_end < 0:
            raise RuntimeError('Cannot locate preceding proof for language-rule integration')
        sentence = ' Une différence mesurée ne prouve pas, à elle seule, un mécanisme identifié.'
        master = master[:previous_proof_end] + sentence + '\n' + master[previous_proof_end:cor_start] + master[cor_end:]
# Write the single-file master. Existing target is intentionally overwritten.
TARGET_TEX.write_text(master, encoding='utf-8')

# Traceability CSV and a detailed report are generated now; counts are filled after compilation too.
with (OUT/'traceabilite_NGeGenBrain_observation_formalisme_full_0.csv').open('w', encoding='utf-8-sig', newline='') as f:
    w = csv.DictWriter(f, fieldnames=['source','chapter','destination_part','decision'])
    w.writeheader(); w.writerows(trace_rows)

# Initial audit report: no blanket statement of mathematical certification; record the review scope.
audit = f'''# Audit de consolidation - NGeGenBrain_observation_formalisme_full_0

## Périmètre

Trois fichiers sources ont été lus et intégrés :
- `NGeGenBrain_observation_formalisme.tex` ({SOURCES['base'].stat().st_size} octets; {len(source_orders['base'])} chapitres)
- `NGeGenBrain_observation_formalisme_next_0.tex` ({SOURCES['inverse'].stat().st_size} octets; {len(source_orders['inverse'])} chapitres)
- `NGeGenBrain_observation_formalisme_next_1.tex` ({SOURCES['invariant'].stat().st_size} octets; {len(source_orders['invariant'])} chapitres)

Le fichier distinct `NGeGenBrain_observation_formalisme_0.tex` n'existait pas dans le dossier; aucune source manquante n'a été inventée. `next_1` a été inclus parce qu'il formalise déjà la distinction invariant/variant demandée.

## Refondation et harmonisation

- Les chapitres théoriques sont ordonnés en six parties thématiques, une partie consacrée à l’audit historique du logiciel et une partie d’annexes documentaires.
- Les objets `observation`, `enregistrement`, `empreinte`, `invariant`, `trace`, `dossier d'évidence` et `mécanisme` sont distingués explicitement.
- Le document unifié réserve « empreinte » à une application de signature et « dossier d'évidence » à une collection de données, protocoles et provenances. La définition source qui appelait le dossier complet « empreinte empirique » a été harmonisée pour éviter la collision de types.
- L'invariance est relative à une famille de transformations déclarée; elle ne découle pas du nom « empreinte ».
- Les résultats sur les échelles supposent que les composantes anciennes sont conservées quand une nouvelle vue est ajoutée.
- La reconstruction exacte est distinguée de la génération conditionnelle, de la compatibilité d'un candidat, de l'identification d'une classe et de la validation empirique.
- Les preuves conditionnelles conservent leurs hypothèses; aucune propriété universelle de reconstruction n'est affirmée pour un domaine infini à partir d'un nombre fini d'observations sans hypothèses supplémentaires.
- Le chapitre d'audit logiciel v3.1 est étiqueté comme audit historique hérité de la source, et non comme nouvelle exécution du logiciel.

## Conservation des sources

Toutes les unités de chapitre des trois sources sont affectées soit au corps théorique soit aux annexes documentaires. La matrice CSV donne le détail. Le but est de réduire les répétitions dans le corps sans supprimer les résultats, hypothèses, contrôles ou checklists historiques.

## Limite importante

La compilation, l'inspection des structures mathématiques et les tests symboliques/structurels ne constituent pas une revue indépendante de mathématiciens experts. Le rapport ne prétend pas garantir que chaque résultat source est universellement correct dans toutes les interprétations possibles. Les points dépendant d'une hypothèse sont explicitement conditionnels; les affirmations expérimentales restent relatives au protocole.
'''
(OUT/'audit_NGeGenBrain_observation_formalisme_full_0.md').write_text(audit, encoding='utf-8')

# Write verification script with source and output integrity, structure and proof counts.
verify_script = r'''#!/usr/bin/env python3
from pathlib import Path
import re, hashlib, json, shutil, subprocess
root=Path(__file__).resolve().parent
tex=root/'NGeGenBrain_observation_formalisme_full_0.tex'
pdf=root/'NGeGenBrain_observation_formalisme_full_0.pdf'
trace=root/'traceabilite_NGeGenBrain_observation_formalisme_full_0.csv'
log=root/'compile_final.log'
s=tex.read_text(encoding='utf-8')
results={
 'tex_exists': tex.exists(),
 'pdf_exists': pdf.exists(),
 'document_begin_end_balanced': s.count(r'\begin{document}')==1 and s.count(r'\end{document}')==1,
 'chapters': len(re.findall(r'^\\chapter\*?\{',s,re.M)),
 'parts': len(re.findall(r'^\\part\{',s,re.M)),
 'theorem_like_environments': sum(len(re.findall(r'\\begin\{'+x+r'\}',s)) for x in ['theoreme','proposition','lemme','corollaire']),
 'proof_environments': len(re.findall(r'\\begin\{proof\}',s)),
 'definitions': len(re.findall(r'\\begin\{definition\}',s)),
 'hypotheses': len(re.findall(r'\\begin\{hypothese\}',s)),
 'source_trace_rows': sum(1 for _ in trace.open(encoding='utf-8-sig'))-1 if trace.exists() else -1,
 'legacy_dossier_mislabel_removed': not bool(re.search(r'Empreinte empirique|\$I_D\$', s, re.I)),
 'control_characters_absent': not any(ord(c)<32 and c not in '\n\r\t' for c in s),
 'critical_terms': {k:(k.casefold() in s.casefold()) for k in ['invariant','variant','multi-échelle','trajectoire',"dossier d'évidence",'non-identifiabilité','reconstruction','contre-exemple']},
}
results['theorem_proof_count_matches'] = results['theorem_like_environments']==results['proof_environments']
results['sources_all_accounted'] = results['source_trace_rows']==58
results['sha256_tex']=hashlib.sha256(tex.read_bytes()).hexdigest()
results['sha256_pdf']=hashlib.sha256(pdf.read_bytes()).hexdigest() if pdf.exists() else None
if pdf.exists() and shutil.which('pdfinfo'):
    pi=subprocess.run(['pdfinfo',str(pdf)],capture_output=True,text=True,check=False).stdout
    m=re.search(r'^Pages:\s+(\d+)',pi,re.M)
    results['pdf_pages']=int(m.group(1)) if m else None
else:
    results['pdf_pages']=None
if log.exists():
    lt=log.read_text(encoding='utf-8',errors='replace')
    results['log_no_undefined_control_sequence']='Undefined control sequence' not in lt
    results['log_no_overfull_boxes']='Overfull \x5chbox' not in lt
    results['log_no_unresolved_references']=not bool(re.search(r'Reference .* undefined|There were undefined references|Label\(s\) may have changed',lt))
    results['log_underfull_hbox_count']=len(re.findall(r'Underfull \x5chbox',lt))
else:
    results['log_no_undefined_control_sequence']=None
    results['log_no_overfull_boxes']=None
    results['log_no_unresolved_references']=None
    results['log_underfull_hbox_count']=None
(root/'verification_NGeGenBrain_observation_formalisme_full_0.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(results,ensure_ascii=False,indent=2))
required=['tex_exists','pdf_exists','document_begin_end_balanced','theorem_proof_count_matches','sources_all_accounted','legacy_dossier_mislabel_removed','control_characters_absent','log_no_undefined_control_sequence','log_no_overfull_boxes','log_no_unresolved_references']
if not all(results.get(k) for k in required) or not all(results['critical_terms'].values()) or not (results.get('pdf_pages') and results['pdf_pages'] > 0): raise SystemExit(1)
'''
(OUT/'verify_NGeGenBrain_observation_formalisme_full_0.py').write_text(verify_script, encoding='utf-8')

print('Generated', TARGET_TEX, 'bytes=', TARGET_TEX.stat().st_size)
print('Source chapter counts', {k:len(v) for k,v in chapters.items()}, 'trace rows', len(trace_rows))
