# P5 multilingual corpus

This evaluation corpus is project-authored and does not copy user source archives. It covers English, French, Arabic and Spanish with mixed domains. Documents are assigned to train/validation/test before training. Validation is reserved for COORD calibration; test is held out for final metrics only.

The corpus is deliberately small and is suitable for an exploratory engineering evaluation, not for a claim of market-level generalist language performance. Per-document language and domain metadata are in `../p5_dataset_manifest.json`.
