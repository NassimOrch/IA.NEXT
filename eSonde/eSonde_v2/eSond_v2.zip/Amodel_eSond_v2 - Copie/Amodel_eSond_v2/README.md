# eSonde v2 — modèle de langage à sondes explicites

**Version du runtime :** 0.2.0  
**Projet :** `eSond_v2`  
**Architecture cible :** sondes explicites et creuses ; aucun neurone, aucune couche dense, aucun MLP, aucun embedding appris dense, aucun Q/K/V neuronal.  
**Interfaces :** CLI Python et interface graphique Tkinter.

## 1. Présentation

eSonde v2 est un prototype expérimental de modèle de langage généraliste construit autour de familles de sondes explicites. Le runtime assemble les réponses des familles SEQ, SKIP_REL, MORPH, SEM, DISC et RETR au moyen d'un coordonnateur COORD. Il expose entraînement, mise à jour, calibration, retrait exact de lot, prédiction, génération de continuation, score, récupération attribuée, extraction de relations composées A–relation–B, candidats de coréférence/alias, inspection et audit.

L'état du modèle est sérialisé en JSON canonique avec empreinte SHA-256 du payload, empreinte exacte du fichier et sidecar `.sha256`. Aucun `pickle` n'est utilisé. La génération et le scoring réutilisent le même runtime que l'interface graphique.

Ce dépôt contient le formalisme mathématique, l'implémentation, les schémas, les tests, des corpus de démonstration, un checkpoint d'exemple, des rapports et les journaux de validation. Les archives sources utilisateur originales sont conservées hors des packages de livraison et ne sont pas recopiées dans le runtime.

## 2. Statut scientifique — lecture impérative

Le fait que les tests logiciels passent n'établit pas la qualité linguistique générale, une supériorité sur MLP/LLM, ni l'équivalence à un modèle commercial. À l'inverse, un résultat faible sur un petit corpus ne permet pas de conclure sur tout le potentiel de l'approche. Les résultats mesurés sont conservés sans correction artificielle et doivent être réévalués avec des protocoles P5 plus larges.

Deux checkpoints sont distingués. `models/esonde_v2_demo_checkpoint.json` est l'état historique de P3 (ancien format d'historique, pas de registre texte complet ; il ne permet pas le retrait exact d'un lot). `models/esonde_v2_p6_demo_checkpoint.json` est le checkpoint v0.2.0 livré : entraîné sur les exemples de ce projet, puis mis à jour avec le lot `p6-demo-update`. Il conserve les textes train/validation/lot pour démontrer le retrait exact. Aucun des deux n'est un poids importé des archives historiques ni un pré-entraînement généraliste. Les jeux `demo_train`, `demo_validation` et `demo_test` sont des exemples de workflow, pas des benchmarks de recherche représentatifs.

## 3. Prérequis et installation

- **Python 3.10+**.
- CLI : bibliothèque standard Python uniquement ; aucune dépendance pip d'exécution.
- GUI : Tkinter/Tcl-Tk doit être disponible dans l'installation Python. Sur certaines distributions Linux, le composant `python3-tk` est optionnel.
- Aucun réseau n'est requis pour le runtime.

Lancement direct depuis le dossier extrait :

```bash
python run_esonde.py --help
python run_esonde_gui.py
```

Raccourcis : `run_esonde_cli.sh` / `run_esonde_gui.sh` (Linux/macOS) et `run_esonde_cli.bat` / `run_esonde_gui.bat` (Windows).

Installation optionnelle en environnement Python :

```bash
python -m pip install .
esonde --help
esonde-gui
```

L'installation optionnelle nécessite un environnement de construction Python approprié ; elle n'est pas nécessaire à l'exécution directe. Cette livraison est un dossier applicatif autonome sans bibliothèques Python tierces, mais n'embarque pas un interpréteur Python multi-OS. Un exécutable natif autonome doit être construit et testé séparément pour chaque OS/architecture.

## 4. Démarrage rapide — CLI

```bash
# Démo rapide avec le corpus fourni
python run_esonde.py demo --output models/quick_demo.json

# Entraînement contrôlé avec config versionnée et splits distincts
python run_esonde.py train \
  --corpus examples/demo_train \
  --validation examples/demo_validation \
  --config examples/training_config.json \
  --output models/my_model.json

# Génération
python run_esonde.py generate --model models/my_model.json \
  --prompt "La science" --max-tokens 24 --strategy greedy

# Évaluation sur un jeu test séparé
python run_esonde.py score --model models/my_model.json \
  --corpus examples/demo_test --top-k 5 --output results/my_score.json

# Récupération, inspection, audit
python run_esonde.py retrieve --model models/my_model.json --query "énergie et mémoire" --top-k 5
python run_esonde.py inspect --model models/my_model.json --family SEM --output results/sem_inspection.json
python run_esonde.py audit --model models/my_model.json --output results/model_audit.json
python run_esonde.py info --model models/my_model.json
```

Les sous-commandes sont : `train`, `update`, `remove-batch`, `calibrate`, `generate`, `score`, `retrieve`, `relations`, `coref`, `inspect`, `audit`, `info`, `demo`.

## 5. Démarrage rapide — interface graphique

```bash
python run_esonde_gui.py
```

Le checkpoint `models/esonde_v2_p6_demo_checkpoint.json`, qui conserve un registre de lots retirable, est renseigné par défaut. Les quatre onglets couvrent :

1. **Entraînement / mise à jour** : entraînement, démo, ajout/retrait de lots, recalibration.
2. **Génération** : prompt, nombre de tokens, stratégie greedy/sample.
3. **Évaluation / récupération** : score de test et recherche de contextes.
4. **Inspection / audit** : familles, COORD, relations A–relation–B, alias/coréférence candidats et audit.

Les opérations longues tournent dans un thread de travail et ne bloquent pas le thread GUI. Les résultats et erreurs apparaissent dans le journal en bas de la fenêtre. Les détails sont dans `docs/GUI_GUIDE.md`.

## 6. Formats, séparation des données et intégrité

Le runtime lit les textes UTF-8 (`.txt`, `.text`, `.md`, `.rst`, `.csv`, `.tsv`, `.jsonl` lors de l'énumération d'un dossier). Les chemins explicitement indiqués sont lus comme texte UTF-8. Les fichiers vides sont ignorés.

Les corpus train, validation et test doivent être disjoints au niveau des identifiants ET des empreintes SHA-256. Renommer un document ne rend pas son contenu indépendant. L'entraînement n'utilise que train ; validation sert à la calibration COORD ; `score` est read-only.

Après chaque sauvegarde, conserver ensemble le JSON et son `.sha256`. Ne pas modifier les poids JSON à la main et ne pas recréer le sidecar d'un fichier d'intégrité inconnue. Conserver les anciens checkpoints avant `update`.

## 7. Documentation complète

- `formalism/formalisme_eSond_v2.tex` : formalisme mathématique de bout en bout.
- `docs/IMPLEMENTATION_SPEC_V2.md` : spécification d'implémentation.
- `docs/API_CONTRACT.md` : API et invariants.
- `docs/CLI_GUIDE.md` : référence des commandes CLI et des erreurs.
- `docs/GUI_GUIDE.md` : guide complet de l'interface graphique.
- `docs/GUIDE_UTILISATION_CLI_GUI.md` : parcours utilisateurs combinés.
- `docs/PROTOCOL_EXPERIMENTAL_VALIDATION.md` : protocole de validation scientifique.
- `docs/P3_GATE_REPORT.md` et `docs/P4_GATE_REPORT.md` : rapports CLI et GUI.
- `docs/P5_GATE_REPORT.md` et `docs/P6_GATE_REPORT.md` : résultats expérimentaux et audit P5/P6.
- `docs/REPORT_TEMPLATE.md` : template uniforme des rapports.
- `schemas/` : schémas JSON versionnés.
- `tests/` : tests unitaires et workflows CLI/GUI.

## 8. Tests locaux

Depuis le dossier extrait :

```bash
python -m compileall -q src/esonde tests
PYTHONPATH=src python -m unittest discover -s tests -p 'test_core_p2.py' -v
PYTHONPATH=src python -m unittest discover -s tests -p 'test_cli_p3.py' -v
```

Pour les tests GUI dans un environnement sans écran, Xvfb est nécessaire si aucun serveur graphique n'est disponible :

```bash
xvfb-run -a env PYTHONPATH=src python -m unittest discover -s tests -p 'test_gui_p4.py' -v
PYTHONPATH=src python -m unittest discover -s tests -p 'test_p6_advanced.py' -v

# Suite entière (Xvfb seulement si aucune session graphique n'est disponible)
xvfb-run -a env PYTHONPATH=src python -m unittest discover -s tests -v
```

## 9. Codes de retour CLI

- `0` : commande terminée.
- `2` : arguments, chemins, données, configuration ou état invalide.
- `3` : audit statique signalant une violation de pureté.

Les erreurs sont émises sur `stderr` ; elles ne sont pas converties en résultats positifs.

## 10. Structure du projet

```text
formalism/       formalisme LaTeX
src/esonde/      runtime pur-sonde, API, sérialisation, CLI et GUI
schemas/         schémas d'états et de familles
examples/        corpus neutres de démonstration et config
models/          checkpoint d'exemple et empreinte
scripts/         outils de validation/audit
results/         résultats et journaux versionnés
logs/            sorties des tests et compilations
checks*          checklists projet et erreurs
```

## 11. Limites opérationnelles explicites

La distribution contient le code et un checkpoint d'exemple, mais pas d'interpréteur Python embarqué pour tous les systèmes. La GUI dépend de la disponibilité de Tkinter. Le moteur ne télécharge pas de corpus ni de tokenizer externe et n'embarque pas de modèle pré-entraîné tiers. Les limitations de qualité observées sont reportées dans les rapports et ne sont pas masquées ; elles doivent être examinées dans un protocole plus large avant toute revendication de performance.

## 12. Licence et usage

Voir `LICENSE.txt`. Les exemples sont inclus à des fins d'essais techniques. Avant tout usage réel, vérifier les droits sur les corpus et sauvegarder les modèles et métadonnées.

## 13. Validation P5 — résultats et statut

La phase P5 est clôturée avec limitations documentées. Le benchmark couvre 36 documents (20 train, 8 validation, 8 test) en anglais, français, arabe et espagnol. Sur 286 cibles test, eSonde obtient log-loss 17,8791, perplexité 58,18 M, top-1 8,39 % et top-5 20,98 %. La comparaison globale de perplexité n'est pas équitable à ce stade : 58,39 % des cibles sont OOV et les politiques OOV des baselines diffèrent. Le diagnostic post-hoc limité aux 119 cibles connues est reporté sans le substituer au benchmark d'origine.

La suite complète passe deux fois (22/22 tests à chaque exécution). Les tests par bloc passent à 14/14 (cœur), 5/5 (CLI) et 3/3 (GUI). La génération à graine fixe est reproductible ; l'exemple testé mélange toutefois plusieurs langues, et la génération lexicale ouverte n'est pas démontrée. Le rapport complet au format projet est `docs/P5_GATE_REPORT.md`, avec données, ablations, interprétation, ressources et réserves de chronologie. Le résumé machine-readable est `results/p5_validation_summary.json`.

Le réentraînement instrumenté séparé, dont l'état canonique correspond exactement au checkpoint de référence hors `model_id`, `created_at` et enveloppe d'intégrité, a mesuré 21,83 s et 249 240 KiB de RSS maximale. Ce chiffre est spécifique à l'environnement courant.

## 14. Extensions P6 : sémantique relationnelle, mentions et réversibilité

Le runtime v0.2.0 ajoute à SEM l'induction de motifs relationnels composés A–relation–B à partir de partitions de clauses observées (A : 1–2 tokens, relation : 1–3, B : 1–2). Ces structures restent des candidats empiriques, avec provenance ; elles ne sont pas une analyse syntaxique certifiée ni une preuve de compréhension humaine.

DISC conserve des mentions de surface à initiale majuscule (1–4 tokens) et classe des alias/candidats d'antécédents par recouvrement pondéré. La sortie indique `resolved=false` : aucune résolution automatique arbitraire n'est imposée. La couverture pronominale n'est pas revendiquée.

Les nouvelles commandes sont :

```bash
python run_esonde.py relations --model models/esonde_v2_p6_demo_checkpoint.json --left "cats" --relation "eat"
python run_esonde.py coref --model models/esonde_v2_p6_demo_checkpoint.json --text "Alice returned."
python run_esonde.py remove-batch --model models/esonde_v2_p6_demo_checkpoint.json --batch-id p6-demo-update
```

Les checkpoints créés avec v0.2.0 stockent les textes UTF-8 d'entraînement et de validation pour pouvoir reconstruire exactement les compteurs, graphes, mentions et le réservoir RETR après suppression d'un lot. Cela signifie que le JSON de modèle contient le corpus : protégez-le et ne le partagez pas sans vérifier les droits/confidentialité. Les modèles historiques sans registre complet refusent le retrait exact plutôt que de simuler une opération approximative.

`max_context: 0` désactive le plafond global additionnel ; les fenêtres locales propres à chaque famille restent configurables et leurs coûts effectifs doivent être mesurés. La valeur par défaut reste 512.

## 15. Statut P6 du runtime

P6 ajoute les relations composées candidates SEM, les mentions/alias DISC, le retrait exact par rejeu des lots pour les checkpoints récents, l'option `max_context: 0` et des diagnostics explicites de troncature. La version courante passe 33 tests intégrés sous Xvfb ; l'audit AST couvre 20 fichiers Python du runtime sans finding et le formalisme a passé deux compilations récentes. Ces contrôles logiciels ne valident pas une coréférence pronominale complète, un parseur syntaxique, la génération open-vocabulary, ni une sémantique généraliste comparable à un LLM. Le benchmark P5 garde ses réserves (286 cibles, 58,39 % OOV, comparabilité globale OOV non équivalente et registre JSON formel écrit après les premières mesures). Voir `docs/P6_GATE_REPORT.md` pour le rapport complet.

## 13. Livrables eSond v2

La distribution du projet est organisée en trois archives :

- `Dmodel_eSond_v2.zip` : application, sources du runtime, modèles/checkpoints, exemples, schémas, documentation CLI/GUI et tests.
- `Amodel_eSond_v2.zip` : audit des sources et expériences, rapports P0–P6, résultats, journaux, scripts de validation, tests et attestations.
- `suivi_model_eSond_v2.zip` (éventuellement en volumes) : checklists, chemins, ledger de preuves, historique, incidents et sauvegarde `sav_eSond_v2`.

Les sources utilisateur originales et leurs extractions brutes ne sont incluses dans aucune archive. Les SHA-256 des fichiers membres sont consignés dans `PACKAGE_SHA256SUMS.txt` à l'intérieur de chaque package ; les checksums des archives et volumes sont fournis à côté des ZIP. Consulter `docs/P7_GATE_REPORT.md` dans l'audit et `P7_RELEASE_VERIFICATION.json` dans le paquet de suivi.
