from __future__ import annotations
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from esonde.audit import purity_audit
from esonde.corpus import Document
from esonde.model import ProbeModel
from esonde.probes.base import ProbeResponse
from esonde.probes.coord import CoordinatorProbe, FAMILIES
from esonde.probes.disc import DiscProbe
from esonde.probes.morph import MorphProbe, char_features
from esonde.probes.retr import RetrievalProbe
from esonde.probes.sem import SemProbe
from esonde.probes.seq import SeqProbe
from esonde.probes.skip_rel import SkipRelProbe
from esonde.tokenizer import UnicodeTokenizer


def doc(doc_id: str, text: str, split: str = "train") -> Document:
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    return Document(doc_id, text, digest, doc_id, split)


class TestTokenizer(unittest.TestCase):
    def test_unicode_normalization_offsets_and_punctuation(self):
        text = "Cafe\u0301 naïve!"
        tokens = UnicodeTokenizer().tokenize(text, "d1")
        self.assertEqual(tokens[0].surface, "Cafe\u0301")
        self.assertEqual(tokens[0].normalized, "Café")
        self.assertEqual(text[tokens[0].start:tokens[0].end], tokens[0].surface)
        self.assertEqual(tokens[1].normalized, "naïve")
        self.assertEqual(tokens[-1].kind, "punctuation")
        self.assertEqual(tokens[-1].surface, "!")


class TestProbeFamilies(unittest.TestCase):
    def test_seq_exact_suffix_support_and_provenance(self):
        probe = SeqProbe(max_order=3, decay=0.5)
        probe.train_one(["<BOS>", "a", "b"], "c", {"document_id": "d1", "position": 2})
        probe.train_one(["<BOS>", "a", "b"], "d", {"document_id": "d2", "position": 2})
        result = probe.respond(["<BOS>", "a", "b"])
        self.assertEqual(result.counts, {"c": 1.75, "d": 1.75})
        self.assertTrue(result.active)
        self.assertEqual(result.diagnostics, ["EXACT_SUPPORT"])
        self.assertTrue(result.provenance)

    def test_skip_relative_positions_and_sentence_boundary(self):
        probe = SkipRelProbe(patterns=[(1, 3)])
        context = ["a", "x", "b"]
        probe.train_one(context, "target")
        self.assertTrue(probe.respond(context).active)
        blocked = ["a", ".", "b"]
        self.assertFalse(probe.respond(blocked).active)

    def test_morph_unicode_features_and_oov_surface(self):
        features = char_features("café", 0)
        self.assertIn("r0:pre:c", features)
        self.assertIn("r0:suf:fé", features)
        self.assertTrue(any("é" in item for item in features))
        probe = MorphProbe(recent_words=2)
        probe.train_one(["<BOS>", "running"], "fast")
        self.assertTrue(probe.respond(["<BOS>", "runningly"]).active)
        # A truly unseen spelling remains intact: morphology may activate by shape/length.
        oov_features = probe._features(["<BOS>", "qzxwv"])
        self.assertIn("r0:pre:q", oov_features)
        self.assertNotIn("<UNK>", oov_features)
        self.assertTrue(probe.respond(["<BOS>", "qzxwv"]).active)

    def test_sem_sparse_graph_and_provenance(self):
        probe = SemProbe(window=10)
        source = {"document_id": "sem-doc", "position": 4, "document_sha256": "a" * 64}
        probe.train_one(["<BOS>", "river", "bank"], "flood", source)
        result = probe.respond(["<BOS>", "river", "bank"])
        self.assertTrue(result.active)
        self.assertIn("flood", result.counts)
        self.assertTrue(probe.neighbors("river"))
        self.assertIn("sem-doc", str(probe.neighbors("river")))

    def test_discourse_probe_uses_only_older_prefix_terms(self):
        probe = DiscProbe(window=32, recent_cutoff=2)
        probe.train_one(["<BOS>", "orion", "saw", "comet"], "returned")
        base = probe.respond(["<BOS>", "orion", "noiseA", "noiseB"])
        changed_suffix = probe.respond(["<BOS>", "orion", "noiseX", "noiseY"])
        self.assertEqual(base.counts, changed_suffix.counts)
        self.assertIn("returned", base.counts)
        self.assertFalse(probe.respond(["<BOS>", "lyra", "noiseA", "noiseB"]).active)

    def test_retrieval_deterministic_bounded_reservoir_and_exact_context(self):
        def train_probe():
            probe = RetrievalProbe(context_window=4, budget=3, top_k=3)
            for i in range(30):
                context = ["<BOS>", "topic", f"item{i}", "ending"]
                probe.train_one(context, f"target{i}", {"document_id": f"d{i}", "position": i, "document_sha256": f"{i:064x}"}, ordinal=i)
            return probe
        left, right = train_probe(), train_probe()
        self.assertEqual(len(left.records), 3)
        self.assertEqual(left.records, right.records)
        self.assertEqual(left.total_seen, 30)
        self.assertTrue(all(isinstance(v, set) for v in left.postings.values()))
        self.assertIn("target_start", left.records[0])
        self.assertEqual(left.retrieve(left.records[0]["context"])[0]["exact"], True)
        # A reordered query may share exactly the same feature set, but it is not an exact context copy.
        record = left.records[0]
        reordered = list(reversed(record["context"]))
        matches = left.retrieve(reordered)
        same_record = next((item for item in matches if item["document_id"] == record["document_id"]), None)
        self.assertIsNotNone(same_record)
        self.assertFalse(same_record["exact"])

    def test_coordinator_simplex_and_unigram_fallback(self):
        coord = CoordinatorProbe()
        weights = coord.normalized_weights(set(FAMILIES[:2]))
        self.assertAlmostEqual(sum(weights.values()), 1.0)
        response = ProbeResponse("SEQ", {"x": 2.0}, 2)
        probs, diag, used, _ = coord.predict({"SEQ": response}, {"x": 2, "y": 1}, 3, top_k=2)
        self.assertIn("x", probs)
        self.assertAlmostEqual(sum(used.values()), 1.0)
        fallback, diagnostics, _, _ = coord.predict({}, {"x": 2, "y": 1}, 3, top_k=2)
        self.assertIn("COORD_FALLBACK", diagnostics)
        self.assertAlmostEqual(fallback["x"], 2 / 3)


class TestModelCore(unittest.TestCase):
    def setUp(self):
        self.train_docs = [
            doc("train-1", "The cat sat on the mat. The cat slept."),
            doc("train-2", "A dog ran near the river. A dog rested."),
        ]
        self.validation_docs = [
            doc("validation-1", "The cat rested beside the river.", "validation"),
        ]

    def test_train_predict_generate_score_and_disjoint_hashes(self):
        model = ProbeModel({"calibration_sample_limit": 64, "retrieval_budget": 16})
        report = model.train(self.train_docs, validation_documents=self.validation_docs)
        self.assertGreater(report["tokens"], 0)
        self.assertEqual(model.coordinator.calibration_status, "CALIBRATED")
        self.assertAlmostEqual(sum(model.coordinator.weights.values()), 1.0)
        prediction = model.predict_next("The cat", top_k=5)
        self.assertTrue(prediction["top_tokens"])
        self.assertIn("SEQ", prediction["family_responses"])
        one = model.generate("The cat", max_tokens=8, strategy="sample", seed=27)
        two = model.generate("The cat", max_tokens=8, strategy="sample", seed=27)
        self.assertEqual(one, two)
        scored = model.score([doc("test-1", "A cat ran near a mat.", "test")])
        self.assertEqual(scored["status"], "MEASURED")
        self.assertGreater(scored["tokens"], 0)
        with self.assertRaisesRegex(ValueError, "SHA-256 overlap"):
            model.score([doc("renamed-copy", self.train_docs[0].text, "test")])
        with self.assertRaisesRegex(ValueError, "SHA-256 overlap"):
            ProbeModel().train([doc("a", "same")], validation_documents=[doc("b", "same", "validation")])

    def test_invalid_split_is_rejected_before_mutating_existing_model(self):
        model = ProbeModel()
        before = model.to_state()
        with self.assertRaisesRegex(ValueError, "SHA-256 overlap"):
            model.train([doc("a", "same")], validation_documents=[doc("b", "same", "validation")])
        self.assertEqual(before, model.to_state())

    def test_config_validation_rejects_invalid_or_ignored_settings(self):
        with self.assertRaisesRegex(ValueError, "unknown training configuration"):
            ProbeModel({"this_key_does_not_exist": 1})
        with self.assertRaisesRegex(ValueError, "seq_decay"):
            ProbeModel({"seq_decay": float("nan")})
        with self.assertRaisesRegex(ValueError, "skip pattern offsets"):
            ProbeModel({"skip_patterns": [[0, 2]]})

    def test_update_rejects_duplicate_content(self):
        model = ProbeModel()
        model.train(self.train_docs)
        with self.assertRaisesRegex(ValueError, "SHA-256"):
            model.update([doc("other-id", self.train_docs[0].text)], "batch-2")
        report = model.update([doc("new-id", "An owl watches the night.")], "batch-2")
        self.assertEqual(report["training_batches"], 2)

    def test_save_load_roundtrip_and_tamper_rejection(self):
        model = ProbeModel({"retrieval_budget": 12})
        model.train(self.train_docs)
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "model.json"
            result = model.save(path)
            self.assertTrue(path.is_file())
            self.assertTrue(Path(result["sidecar"]).is_file())
            loaded = ProbeModel.load(path)
            self.assertEqual(model.to_state(), loaded.to_state())
            self.assertEqual(model.predict_next("The cat"), loaded.predict_next("The cat"))
            try:
                from jsonschema import Draft202012Validator
            except ImportError:
                self.skipTest("optional development dependency jsonschema is unavailable")
            schema_path = Path(__file__).resolve().parents[1] / "schemas" / "model_state.schema.json"
            schema = json.loads(schema_path.read_text(encoding="utf-8"))
            Draft202012Validator(schema).validate(model.to_state())
            raw = path.read_bytes()
            path.write_bytes(raw + b" ")
            with self.assertRaisesRegex(ValueError, "SHA-256"):
                ProbeModel.load(path)

    def test_static_purity_audit(self):
        result = purity_audit()
        self.assertEqual(result["status"], "PASS", result["findings"])
        self.assertGreater(result["files_scanned"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
