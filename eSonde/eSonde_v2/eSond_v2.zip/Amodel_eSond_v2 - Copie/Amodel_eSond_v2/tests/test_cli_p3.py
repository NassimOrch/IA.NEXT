from __future__ import annotations
import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path

from esonde.cli import main


class TestCLIWorkflows(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.train = self.root / "train"
        self.validation = self.root / "validation"
        self.test = self.root / "test"
        for path in (self.train, self.validation, self.test):
            path.mkdir()
        (self.train / "a.txt").write_text("The blue bird rests near the green tree. The bird sings in the morning.", encoding="utf-8")
        (self.train / "b.txt").write_text("A small boat crosses the calm river. The river reaches the open sea.", encoding="utf-8")
        (self.train / "relations.txt").write_text("Cats eat fish. Birds build nests. Alice studies biology.", encoding="utf-8")
        (self.validation / "v.txt").write_text("A red bird flies above the quiet river.", encoding="utf-8")
        (self.test / "t.txt").write_text("A boat moves beside the green shore.", encoding="utf-8")
        self.model = self.root / "model.json"

    def tearDown(self):
        self.temp.cleanup()

    def invoke(self, args):
        stdout, stderr = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            code = main(args)
        return code, stdout.getvalue(), stderr.getvalue()

    def test_complete_cli_train_update_generate_score_retrieve_inspect_audit_info(self):
        code, output, error = self.invoke([
            "train", "--corpus", str(self.train), "--validation", str(self.validation), "--output", str(self.model)
        ])
        self.assertEqual(code, 0, error)
        self.assertTrue(self.model.is_file())
        self.assertTrue(Path(str(self.model) + ".sha256").is_file())
        self.assertEqual(json.loads(output)["status"], "TRAINED")

        code, output, error = self.invoke([
            "generate", "--model", str(self.model), "--prompt", "The blue bird", "--max-tokens", "5", "--strategy", "sample", "--seed", "12"
        ])
        self.assertEqual(code, 0, error)
        self.assertEqual(json.loads(output)["status"], "GENERATED")

        code, output, error = self.invoke(["score", "--model", str(self.model), "--corpus", str(self.test), "--top-k", "3"])
        self.assertEqual(code, 0, error)
        self.assertEqual(json.loads(output)["status"], "MEASURED")

        code, output, error = self.invoke(["retrieve", "--model", str(self.model), "--query", "blue bird", "--top-k", "3"])
        self.assertEqual(code, 0, error)
        self.assertIn("results", json.loads(output))

        code, output, error = self.invoke(["inspect", "--model", str(self.model), "--family", "SEM"])
        self.assertEqual(code, 0, error)
        self.assertEqual(json.loads(output)["family"], "SEM")

        code, output, error = self.invoke(["audit", "--model", str(self.model)])
        self.assertEqual(code, 0, error)
        self.assertEqual(json.loads(output)["status"], "PASS")

        code, output, error = self.invoke(["info", "--model", str(self.model)])
        self.assertEqual(code, 0, error)
        self.assertIn("model", json.loads(output))

        addition = self.root / "new.txt"
        addition.write_text("A sparrow sings beside the river bank.", encoding="utf-8")
        code, output, error = self.invoke([
            "update", "--model", str(self.model), "--corpus", str(addition), "--batch-id", "cli-test-update"
        ])
        self.assertEqual(code, 0, error)
        self.assertEqual(json.loads(output)["status"], "UPDATED")
        self.assertEqual(json.loads(self.model.read_text(encoding="utf-8"))["coordinator"]["calibration_status"], "STALE")

        code, output, error = self.invoke([
            "calibrate", "--model", str(self.model), "--validation", str(self.validation)
        ])
        self.assertEqual(code, 0, error)
        self.assertEqual(json.loads(output)["status"], "CALIBRATED")
        self.assertEqual(json.loads(self.model.read_text(encoding="utf-8"))["coordinator"]["calibration_status"], "CALIBRATED")

    def test_cli_relations_coreference_and_exact_batch_removal(self):
        code, output, error = self.invoke([
            "train", "--corpus", str(self.train), "--validation", str(self.validation), "--output", str(self.model)
        ])
        self.assertEqual(code, 0, error)

        code, output, error = self.invoke(["relations", "--model", str(self.model), "--left", "cats", "--relation", "eat"])
        self.assertEqual(code, 0, error)
        self.assertTrue(any(x["right_text"] == "fish" for x in json.loads(output)["results"]))

        code, output, error = self.invoke(["coref", "--model", str(self.model), "--text", "Alice returned."])
        self.assertEqual(code, 0, error)
        self.assertTrue(json.loads(output)["candidates"])

        addition = self.root / "batch_to_remove.txt"
        addition.write_text("Unicorns orbit quasars.", encoding="utf-8")
        code, output, error = self.invoke(["update", "--model", str(self.model), "--corpus", str(addition), "--batch-id", "retract-me"])
        self.assertEqual(code, 0, error)
        code, output, error = self.invoke(["remove-batch", "--model", str(self.model), "--batch-id", "retract-me"])
        self.assertEqual(code, 0, error)
        result = json.loads(output)
        self.assertEqual(result["status"], "BATCH_REMOVED_AND_REBUILT")
        self.assertNotIn("Unicorns", __import__("esonde.model", fromlist=["ProbeModel"]).ProbeModel.load(self.model).vocabulary)

    def test_demo_command_creates_real_loadable_model(self):
        output = self.root / "demo_model.json"
        code, stdout, stderr = self.invoke(["demo", "--output", str(output)])
        self.assertEqual(code, 0, stderr)
        result = json.loads(stdout)
        self.assertEqual(result["status"], "DEMO_MODEL_SAVED")
        self.assertTrue(output.is_file())
        from esonde.model import ProbeModel
        loaded = ProbeModel.load(output)
        self.assertGreater(loaded.token_count, 0)
        self.assertGreater(len(loaded.vocabulary), 0)

    def test_invalid_path_has_nonzero_exit_and_visible_error(self):
        code, stdout, stderr = self.invoke(["train", "--corpus", str(self.root / "missing"), "--output", str(self.model)])
        self.assertEqual(code, 2)
        self.assertEqual(stdout, "")
        self.assertIn("error", stderr.lower())
        self.assertFalse(self.model.exists())

    def test_calibration_rejects_training_document_leakage(self):
        code, _, error = self.invoke(["train", "--corpus", str(self.train), "--output", str(self.model)])
        self.assertEqual(code, 0, error)
        code, stdout, stderr = self.invoke(["calibrate", "--model", str(self.model), "--validation", str(self.train)])
        self.assertEqual(code, 2)
        self.assertEqual(stdout, "")
        self.assertIn("overlaps trained corpus", stderr)

    def test_score_rejects_invalid_top_k(self):
        code, _, error = self.invoke(["train", "--corpus", str(self.train), "--output", str(self.model)])
        self.assertEqual(code, 0, error)
        code, _, error = self.invoke(["score", "--model", str(self.model), "--corpus", str(self.test), "--top-k", "0"])
        self.assertEqual(code, 2)
        self.assertIn("top_k", error)


if __name__ == "__main__":
    unittest.main(verbosity=2)
