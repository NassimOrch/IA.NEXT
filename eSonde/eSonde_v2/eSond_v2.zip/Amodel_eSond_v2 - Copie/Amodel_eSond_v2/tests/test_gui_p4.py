from __future__ import annotations
import hashlib
import tempfile
import time
import tkinter as tk
import unittest
from pathlib import Path

from esonde.gui import EsondeGUI


class TestGUIWorkflow(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root_dir = Path(self.temp.name)
        self.root = tk.Tk()
        self.root.withdraw()
        self.app = EsondeGUI(self.root)
        project = Path(__file__).resolve().parents[1]
        self.app.train_corpus.set(str(project / "examples" / "demo_train"))
        self.app.validation_corpus.set(str(project / "examples" / "demo_validation"))
        self.app.test_corpus.set(str(project / "examples" / "demo_test"))
        self.model = self.root_dir / "gui_model.json"
        self.app.output_model.set(str(self.model))

    def tearDown(self):
        try: self.root.destroy()
        except tk.TclError: pass
        self.temp.cleanup()

    def click(self, label: str):
        button = next(b for b in self.app._buttons if b.cget("text") == label)
        button.invoke()
        self.wait_idle()

    def wait_idle(self, timeout: float = 60.0):
        deadline = time.monotonic() + timeout
        while self.app._busy and time.monotonic() < deadline:
            self.root.update()
            time.sleep(0.01)
        self.root.update()
        self.assertFalse(self.app._busy, "GUI task did not complete before timeout")

    def output_text(self):
        return self.app.output.get("1.0", "end")

    def test_train_generate_score_retrieve_inspect_audit_update_calibrate(self):
        self.root.update()
        self.click("Entraîner")
        self.assertTrue(self.model.is_file())
        self.assertTrue(Path(str(self.model) + ".sha256").is_file())
        sidecar_hash = Path(str(self.model) + ".sha256").read_text().split()[0]
        self.assertEqual(hashlib.sha256(self.model.read_bytes()).hexdigest(), sidecar_hash)
        self.assertEqual(self.app.model_path.get(), str(self.model))

        self.app.prompt.insert("1.0", "La science")
        self.app.prompt_tokens.set("6")
        self.click("Générer")

        self.click("Évaluer (score)")
        self.app.query.set("science énergie")
        self.click("Récupérer des contextes")
        self.app.family.set("SEM")
        self.click("Inspecter")
        self.click("Audit de pureté / état")

        new_doc = self.root_dir / "new.txt"
        new_doc.write_text("Une nouvelle observation décrit un habitat lié à la rivière.", encoding="utf-8")
        self.app.update_corpus.set(str(new_doc))
        self.app.batch_id.set("gui-test-batch")
        self.click("Mettre à jour le modèle courant")
        self.click("Recalibrer COORD")
        self.app.relation_left.set("science")
        self.click("Rechercher les relations")
        self.app.coref_text.set("Science returns.")
        self.click("Trouver les candidats")
        self.click("Supprimer un lot (reconstruction exacte)")

        text = self.output_text()
        for marker in ("TRAINED", "GENERATED", "MEASURED", "results", "family", "purity", "UPDATED", "CALIBRATED", "candidates", "BATCH_REMOVED_AND_REBUILT"):
            self.assertIn(marker, text)
        self.assertIn("Terminé : Suppression exacte de lot", self.app.status.get())

    def test_invalid_form_input_is_visible_and_does_not_start_worker(self):
        self.app.train_corpus.set("")
        self.click("Entraîner")
        self.assertFalse(self.app._busy)
        self.assertIn("Entrée invalide", self.app.status.get())
        self.assertIn("Indiquez au moins un fichier", self.output_text())

    def test_worker_is_off_ui_thread_and_updates_status(self):
        self.app._start_job("test-worker", lambda: (time.sleep(0.15), {"ok": True})[1])
        self.assertTrue(self.app._busy)
        deadline = time.monotonic() + 5
        while self.app._busy and time.monotonic() < deadline:
            self.root.update(); time.sleep(0.01)
        self.root.update()
        self.assertFalse(self.app._busy)
        self.assertIn('"ok": true', self.output_text())


if __name__ == "__main__":
    unittest.main(verbosity=2)
