from __future__ import annotations
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from esonde.corpus import Document
from esonde.model import ProbeModel
from esonde.probes.disc import DiscProbe
from esonde.probes.sem import SemProbe


def doc(doc_id, text, split="train"):
    return Document(doc_id,text,hashlib.sha256(text.encode("utf-8")).hexdigest(),doc_id,split)


class TestComposedSemantics(unittest.TestCase):
    def test_sem_induces_a_relation_and_predicts_right_argument(self):
        probe=SemProbe(window=32)
        words=["Cats","eat","fish"]
        probe.train_one(["<BOS>",words[0],words[1]],words[2],{"document_id":"d1","position":2,"document_sha256":"a"*64})
        records=probe.find_propositions("cats","eat",None)
        self.assertTrue(any(r["right_text"]=="fish" for r in records),records)
        response=probe.respond(["<BOS>","Cats","eat"])
        self.assertIn("fish",response.counts)
        self.assertIn("COMPOSED_RELATION_MATCH",response.diagnostics)

    def test_sem_relations_do_not_cross_sentence_boundary(self):
        probe=SemProbe(window=32)
        probe.train_one(["<BOS>","Cats","."],"eat",{"document_id":"d1","position":2})
        self.assertEqual(probe.find_propositions("cats",".","eat"),[])

    def test_sem_roundtrip_preserves_relation_state(self):
        p=SemProbe(); p.train_one(["<BOS>","Birds","build"],"nests",{"document_id":"d1","position":2})
        q=SemProbe.from_state(p.to_state())
        self.assertEqual(p.find_propositions(),q.find_propositions())
        self.assertEqual(p.respond(["<BOS>","Birds","build"]).counts,q.respond(["<BOS>","Birds","build"]).counts)


class TestCoreferenceCandidates(unittest.TestCase):
    def test_disc_surfaces_candidates_with_evidence_without_forced_resolution(self):
        probe=DiscProbe(window=128,recent_cutoff=1)
        probe.train_one(["<BOS>"],"Alice",{"document_id":"d1","position":0,"document_sha256":"b"*64})
        candidates=probe.coreference_candidates(["Later","Alice","returned"])
        self.assertTrue(candidates)
        self.assertEqual(candidates[0]["candidate_antecedent"],"alice")
        self.assertFalse(candidates[0]["resolved"])
        self.assertEqual(candidates[0]["relation_type"],"SURFACE_ALIAS_CANDIDATE")

    def test_disc_mention_state_roundtrip(self):
        p=DiscProbe(); p.train_one(["<BOS>"],"New",{"document_id":"d1","position":0})
        p.train_one(["<BOS>","New"],"York",{"document_id":"d1","position":1})
        q=DiscProbe.from_state(p.to_state())
        self.assertEqual(p.to_state(),q.to_state())


class TestReversibleBatchesAndContext(unittest.TestCase):
    def setUp(self):
        self.base=[doc("d1","The cat rests near Alice.")]
        self.validation=[doc("v1","The cat rests.","validation")]

    def test_batch_removal_exactly_rebuilds_model_after_save_load(self):
        config={"retrieval_budget":32}
        model=ProbeModel(config)
        model.train(self.base,validation_documents=self.validation)
        model.update([doc("d2","Zebra watches comet.")],"batch-z")
        retained=[doc("d3","Comets orbit stars.")]
        model.update(retained,"batch-y")
        self.assertIn("Zebra",model.vocabulary)
        expected=ProbeModel(config)
        expected.train(self.base,validation_documents=self.validation)
        expected.update(retained,"batch-y")
        expected_state=expected.to_state()
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/"model.json"; model.save(path)
            loaded=ProbeModel.load(path)
            result=loaded.remove_batch("batch-z")
            self.assertEqual(result["status"],"BATCH_REMOVED_AND_REBUILT")
            self.assertNotIn("Zebra",loaded.vocabulary)
            actual_state=loaded.to_state()
            # Model identity/time are expected to change on rebuild; all learned and
            # serialized state (including RETR, COORD, provenance and retained batches)
            # must otherwise equal a clean train+update without the removed batch.
            for state in (actual_state,expected_state):
                state["model_id"]="IDENTITY"
                state["created_at"]="TIME"
            self.assertEqual(actual_state,expected_state)
            self.assertEqual([x["batch_id"] for x in loaded.training_batches],["initial-train","batch-y"])
            self.assertEqual(loaded.coordinator.calibration_status,"STALE")

    def test_remove_unknown_batch_is_non_mutating(self):
        model=ProbeModel(); model.train(self.base); before=model.to_state()
        with self.assertRaisesRegex(ValueError,"unknown batch_id"):
            model.remove_batch("does-not-exist")
        self.assertEqual(before,model.to_state())

    def test_long_context_mode_has_no_global_truncation_and_is_bounded_by_probe_scales(self):
        model=ProbeModel({"max_context":0,"disc_window":1200,"sem_window":256,"retrieval_context_window":128})
        text=" ".join(f"word{i}" for i in range(1000))
        context=model._context_from_text(text)
        self.assertEqual(len(context),1001)
        # Training passes only the maximum family observation span, not repeated O(n²) copies.
        self.assertEqual(model._context_span(),1200)


    def test_bounded_context_reports_truncation_in_prediction_and_score(self):
        config={"max_context":3,"seq_max_order":2,"skip_patterns":[[1,2]],
                "morph_recent_words":1,"sem_window":2,"disc_window":4,
                "disc_recent_cutoff":1,"retrieval_context_window":2}
        model=ProbeModel(config)
        model.train([doc("train-small","training corpus")])
        prediction=model.predict_next("one two three four five six")
        self.assertIn("TRUNCATED_CONTEXT",prediction["diagnostics"])
        self.assertEqual(prediction["context_scope"]["discarded_items"],4)
        measured=model.score([doc("test-small","alpha beta gamma delta","test")])
        self.assertEqual(measured["context_window"]["truncated_context_targets"],1)
        self.assertEqual(measured["context_window"]["discarded_context_items"],1)

    def test_legacy_checkpoint_cannot_claim_exact_batch_retraction(self):
        model=ProbeModel(); model.train(self.base)
        state=model.to_state(); state["memory"].pop("training_batches",None); state["memory"].pop("training_history_complete",None)
        model.training_history_complete=False; model.training_batches=[]
        with self.assertRaisesRegex(ValueError,"no complete retained training history"):
            model.remove_batch("initial-train")


if __name__=="__main__":
    unittest.main(verbosity=2)
