# Plan de tests contractuel P1 — familles de sondes

Les tests suivants seront codés dans P2 et rejoués avec `unittest`. P1 fixe les micro-corpus et les critères avant implémentation afin d'empêcher le modèle d'être modifié après observation des sorties pour satisfaire une réponse particulière. Les micro-corpus sont des fixtures exclusivement de test, séparées des corpus de release.

| Famille | Test à implémenter | Fixture d'entrée | Critère mesurable | Diagnostic requis |
|---|---|---|---|---|
| SEQ | `test_seq_exact_suffix_support` | `a b c` et `a b d` | clé `(a,b)` compte `c:1`, `d:1`; suffixe plus long prioritaire | `EXACT_SUPPORT` |
| SKIP/REL | `test_skip_relative_positions_and_boundaries` | deux phrases avec tokens relais ; motifs offsets 1/3 et 1/5 | seuls motifs entièrement présents dans la même frontière sont actifs | `SPARSE_MATCH`, `INCOMPLETE_PATTERN` |
| MORPH | `test_morph_unicode_features_and_oov_context` | tokens `running`, `runningly`, `café`, `naïve`, puis une forme inconnue | pré/suffixes et n-grammes Unicode exacts ; la forme inconnue n'est pas remplacée par UNK | `OOV_INPUT`, `MORPH_MATCH` |
| SEM | `test_sem_sparse_jaccard_and_provenance` | mini-corpus avec contextes récurrents partagés | similarité sparse et comptes de conséquences reproductibles ; toute arête garde source et offsets | `SEMANTIC_NEIGHBOR_MATCH` |
| DISC | `test_discourse_memory_has_no_future_leak` | document de plusieurs phrases avec répétition d'une entité | seules mentions antérieures activent la mémoire ; modifier un suffixe futur ne change pas la réponse d'un préfixe antérieur | `LONG_RANGE_MATCH`, `ENTITY_CANDIDATE`, `NO_FUTURE_LEAK` |
| RETR | `test_retrieval_attribution_and_copy_flag` | fenêtres contextualisées avec document_id/offset distincts | résultat top-k stable, provenance réversible, copie exacte identifiée | `RETRIEVAL_MATCH`, `NEAR_COPY` |
| COORD | `test_simplex_normalization_and_fallback` | réponses factices issues des 6 familles, puis aucune sonde active | poids non négatifs de somme 1 ; mélange normalisé ; fallback unigramme uniquement si support nul | `NO_ACTIVE_PROBE`, `COORD_FALLBACK` |

## Tests transversaux

- `test_unicode_offsets_and_boundaries` : décomposition Unicode normalisée, offsets de surface, ponctuation et séparateurs.
- `test_future_suffix_cannot_change_prefix_counts` : causalité stricte de toutes les familles.
- `test_train_validation_test_document_disjointness` : aucune fuite de documents entre splits.
- `test_atomic_save_load_and_checksum_reject` : round-trip exact, checksum altéré rejeté, fichier antérieur conservé.
- `test_public_api_contract` : toutes les méthodes publiques et types de retour.
- `test_generation_deterministic_for_seed` : même seed/options ⇒ même sortie.
- `test_no_neural_imports_or_layers` : aucun import ou appel de framework neuronal, aucune matrice dense entraînable.
- `test_model_state_size_and_budget_diagnostics` : dépassement explicite, compteur d'éviction, absence de troncature silencieuse.

Les tests de qualité (log-loss, perplexité, exactitude, rappel de relation, MRR, copie, cohérence) sont distincts des tests de correction logicielle et ne sont pas remplacés par des fixtures.


## Exécution P2 — résultats actuels

Les tests P2 exécutés sont regroupés dans `test_core_p2.py`. Après correction de deux défauts d'implémentation (marques Unicode combinantes et réduction flottante non déterministe) et correction de deux attentes de test qui ne correspondaient pas au contrat, l'ensemble courant comporte 14 tests ciblés couvrant le tokenizer, les six familles de sondes, COORD, la causalité DISC, le réservoir RETR, l'anti-fuite par ID/hash, la validation de configuration, la non-mutation en cas de partitions invalides, le round-trip exact et le schéma JSON de l'état réel. Le dernier résultat est enregistré dans `results/p2_unit_tests_attempt5.json` après exécution ; les essais antérieurs restent conservés séparément.

Les tests ne jugent pas à eux seuls la généralisation linguistique. Les critères sémantiques, les ablations, la robustesse multi-domaines/langues et le rapport coût/performance sont réservés à P5/P6.
