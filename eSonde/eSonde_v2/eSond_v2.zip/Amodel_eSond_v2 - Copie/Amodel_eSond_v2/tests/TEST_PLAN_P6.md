# Test plan P6 — audit scientifique et fonctions avancées

## Périmètre

Ce plan vérifie les ajouts P6 sans prétendre démontrer la compréhension générale ou la performance relative du modèle. Les corpus des tests sont artificiels, séparés des archives historiques.

| Contrat | Test | Critère |
|---|---|---|
| SEM : partition A–relation–B | `test_sem_induces_a_relation_and_predicts_right_argument` | relation récupérable et réponse candidate issue du suffixe exact |
| SEM : frontières de phrase | `test_sem_relations_do_not_cross_sentence_boundary` | aucune proposition construite à travers un séparateur |
| SEM : persistance | `test_sem_roundtrip_preserves_relation_state` | mêmes propositions et distributions après round-trip |
| DISC : mention/surface | `test_disc_surfaces_candidates_with_evidence_without_forced_resolution` | candidats avec provenance/support et `resolved=false` |
| DISC : persistance | `test_disc_mention_state_roundtrip` | état des mentions identique après round-trip |
| Lots : reconstruction | `test_batch_removal_exactly_rebuilds_model_after_save_load` | état appris complet égal à un entraînement de référence hors identité/horodatage |
| Lots : identifiant inconnu | `test_remove_unknown_batch_is_non_mutating` | rejet sans mutation |
| Lots : ancien checkpoint | `test_legacy_checkpoint_cannot_claim_exact_batch_retraction` | refus explicite sans ledger |
| Contexte non plafonné | `test_long_context_mode_has_no_global_truncation_and_is_bounded_by_probe_scales` | l'entrée 1 000 items est conservée dans le mode `max_context=0` |
| Contexte borné | `test_bounded_context_reports_truncation_in_prediction_and_score` | diagnostic et compte de tokens écartés concordants |

## Commandes de validation

```bash
python scripts/preflight.py --phase P6
PYTHONPATH=src python -m unittest discover -s tests -p 'test_p6_advanced.py' -v
xvfb-run -a env PYTHONPATH=src python -m unittest discover -s tests -p 'test_gui_p4.py' -v
xvfb-run -a env PYTHONPATH=src python -m unittest discover -s tests -v
python -m compileall -q src/esonde tests
python scripts/validate_spec.py
```

Les critères sont des contrats logiciels. Ils ne sont pas des preuves de sémantique de niveau humain, de coréférence pronominale, de génération ouverte ou de généralisation inter-domaines.
