# Amodel_eSond_v2 — archive d'audit

Cette archive regroupe les rapports P0–P6, l'analyse des sources et expériences, les index d'inventaire et manifestes de hachage, les résultats expérimentaux, les journaux, les scripts de validation, les tests, le formalisme, la matrice de traçabilité et les attestations signées d'incident.

## Sources utilisateur et exclusion

Les deux archives utilisateur d'origine et leurs extractions brutes ne sont **pas incluses**. Le répertoire `source_audit/` contient des rapports, index, chemins, tailles et empreintes dérivés de l'audit ; il ne contient pas `experience_extracts/`. Le ledger `preuves_eSond_v2.json` et les SHA-256 des archives sont livrés dans l'archive de suivi.

## Réserve d'exhaustivité

37 056 occurrences de membres ZIP ont été indexées et contrôlées CRC/SHA ; 22 792 fichiers texte/code/configuration ont été indexés. Le parsing structurel global a expiré deux fois et la revue sémantique manuelle a couvert les documents primaires, expériences, formalismes, rapports et scripts retenus, pas chaque fichier indexé individuellement. Cette limite est expressément conservée dans le rapport P0.

## Lecture

Commencer par `docs/P0_GATE_REPORT.md`, `source_audit/ANALYSE_SOURCES_EXPERIENCES_eSond_v2.md`, puis les rapports P1–P6. `docs/P6_GATE_REPORT.md` distingue fonctions réalisées, observations et limitations. Les incidents et signatures se trouvent dans `docs/incidents/`.
