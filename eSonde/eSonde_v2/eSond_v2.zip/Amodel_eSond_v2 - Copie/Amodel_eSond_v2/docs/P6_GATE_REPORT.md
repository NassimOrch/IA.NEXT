# Rapport de clôture P6 — audit scientifique et runtime avancé eSonde v2

**Date de version initiale :** 2026-11-09T11:49:09+01:00  
**Addendum de clôture :** 2026-11-09T12:04:46+01:00  
**Phase :** P6 — audit scientifique, conformité, observabilité et rapport final  
**Runtime :** eSonde 0.2.0 / eSond_v2  
**Statut :** PASS_WITH_DOCUMENTED_LIMITATIONS  
**Références de sauvegarde :** S33_P6_ADVANCED_FEATURES_PREEXEC (historique), S37_P6_DEMO_BATCH_REMOVAL_PRECHECK, S38_P6_FINAL_AUDIT_PREVALIDATION (prévalidation finale).  

## 1. Description

P6 reprend l'audit du runtime après les écarts détectés dans SEM, DISC, la suppression des lots et la portée du contexte. L'objectif était de transformer ces constats en contrats testables, d'implémenter les fonctions manquantes identifiées à ce stade, de vérifier leur persistance et leur interaction via CLI/GUI, puis de formaliser les limites résiduelles.

Les archives sources originales sont restées en lecture seule et ne sont pas importées comme poids ou données d'entraînement du checkpoint de démonstration. La phase P0 demeure `PASS_WITH_DOCUMENTED_SCOPE_LIMITATION` : les 37 056 occurrences de membres ZIP ont été inventoriées et CRC/SHA audités, 22 792 fichiers texte/code/config indexés ; la revue sémantique a porté sur les documents et expériences primaires, et le parsing structurel global des 22 792 entrées a expiré deux fois. Aucun audit de contenu manuel de chaque fichier individuel n'est revendiqué.

## 2. Architecture

Le graphe d'exécution reste composé des familles explicites `SEQ`, `SKIP_REL`, `MORPH`, `SEM`, `DISC`, `RETR` et `COORD`. Les structures apprises sont des compteurs, tables, graphes et index sparse inspectables. Aucune couche neuronale, MLP, embedding dense appris, projection affine dense ou attention Q/K/V n'est introduit dans le runtime.

### 2.1 SEM — propositions candidates

SEM conserve les postings lexicaux et le graphe sparse, puis induit sur chaque clause achevée des partitions contiguës bornées : argument gauche A (1–2 tokens), relation (1–3 tokens), argument droit B (1–2 tokens). Les enregistrements conservent compte et provenance ; l'index A+relation propose le premier token de B lorsque le suffixe de clause correspond exactement. Le diagnostic est `COMPOSED_RELATION_MATCH`. Il s'agit d'une induction de spans observés, pas d'un analyseur syntaxique validé, d'une attribution fiable de rôles sémantiques ni d'une vérification de vérité.

### 2.2 DISC — mentions et alias candidats

DISC maintient les termes de discours et un registre de mentions de surface observées (suites de 1–4 tokens à initiale majuscule). `coreference_candidates()` calcule un recouvrement pondéré par fréquence inverse et retourne plusieurs candidats avec support, document et preuves ; le champ `resolved` reste `false`. La résolution pronominale, l'identification d'entités non capitalisées et l'équivalence multilingue ne sont pas revendiquées.

### 2.3 Retrait exact de lots

Les modèles nouvellement entraînés conservent les textes UTF-8 des lots et du corpus de validation. `remove_batch(batch_id)` construit un nouveau `ProbeModel`, rejoue le train initial puis les lots conservés, et reconstruit tous les états, y compris le réservoir RETR et COORD. Aucun décrément approximatif de compteurs n'est utilisé. Les checkpoints historiques dépourvus de registre complet refusent l'opération. Le texte conservé rend le checkpoint sensible et doit être protégé ; l'implémentation n'efface pas les sauvegardes antérieures, snapshots ou copies externes et ne fournit pas de suppression cryptographique.

### 2.4 Contexte et troncature

`max_context=0` désactive le plafond global additionnel ; les fenêtres locales par famille restent actives. Pour `max_context` positif, `predict_next` fournit `TRUNCATED_CONTEXT` et `context_scope` (éléments fournis/retenus/écartés). `score` retourne les cibles tronquées et le nombre d'éléments de contexte écartés dans `context_window`. Le rapport d'entraînement expose les événements de troncature.

## 3. Pipeline complet

1. Prévol P6 : lecture de `chemins_eSond_v2.json`, manifest savepoint, checklist travail et deux checklists d'erreurs ; intégrité du dernier snapshot vérifiée.
2. Inspection ciblée des modules `sem.py`, `disc.py`, `retr.py`, `model.py`, des contrats, schémas, GUI et CLI.
3. Ajout de relations candidates A–relation–B, mentions/alias DISC et opérations API/CLI/GUI.
4. Conservation des textes de lots et rejeu exact lors du retrait ; refus explicite des anciens modèles sans historique complet.
5. Ajout de l'option `max_context=0` et de diagnostics de troncature pour prédiction, entraînement et scoring.
6. Tests spécifiques P6, tests GUI sous Xvfb, suite globale, compilation Python et audit AST.
7. Correction du défaut LaTeX découvert sur une compilation fraîche (underscore non échappé), suivie de deux compilations propres et de la validation Draft 2020-12.
8. Mise à jour des guides, matrice de traçabilité, checklists, incidents, rapports et sauvegardes.

## 4. Commandes d'exécution

Répertoire : racine de `esond_v2_project`. Environnement : Python 3.13.5, Linux-6.18.57-x86_64-with-glibc2.41.

```bash
python scripts/preflight.py --phase P6
PYTHONPATH=src python -m unittest discover -s tests -p 'test_p6_advanced.py' -v
xvfb-run -a env PYTHONPATH=src python -m unittest discover -s tests -p 'test_gui_p4.py' -v
xvfb-run -a env PYTHONPATH=src python -m unittest discover -s tests -v
python -m compileall -q src/esonde tests
python scripts/validate_spec.py
PYTHONPATH=src python -c "from esonde.audit import purity_audit; import json; print(json.dumps(purity_audit('src/esonde')))"
cd formalism && pdflatex -interaction=nonstopmode -halt-on-error -jobname=formalism_v2_current -output-directory=../logs formalisme_eSond_v2.tex
```

Codes de retour constatés : prévol 0 ; tests P6 ciblés 0 ; suite GUI 0 ; suite globale 0 ; compileall 0 ; validation du formalisme 0 ; deux compilations LaTeX 0.

## 5. Résultats

| Contrôle | Résultat |
|---|---:|
| Tests P6 avancés | 10/10 PASS |
| Tests CLI | 6/6 PASS |
| Tests cœur | 14/14 PASS |
| Tests GUI | 3/3 PASS |
| Suite totale | **33/33 PASS** |
| Durée unittest (réexécution finale) | 31,827 s |
| Temps mural instrumenté (réexécution finale) | 33,38 s |
| RSS maximale pendant la suite (réexécution finale) | 363 488 KiB |
| Audit AST de pureté | 20 fichiers Python, 0 finding |
| Compilation LaTeX actuelle | pass11 et pass12 PASS ; validation de spécification PASS |
| Validation JSON Schema / matrice | PASS, 23 lignes de traçabilité à l'issue de l'ajout P6 |

Le test de retrait exact compare maintenant l'état appris complet, hors identité/horodatage du modèle reconstruit, à un entraînement de référence qui exclut le lot supprimé mais conserve un autre lot : les états sérialisés sont égaux. Le test vérifie aussi le recalcul des informations de COORD et la disparition du token/lot retiré.

Le test de contexte borné vérifie un prompt contenant six tokens plus BOS sous une limite de trois : quatre items sont déclarés écartés. Le test de scoring rapporte une cible tronquée et un item écarté lorsque la limite est atteinte. Le test `max_context=0` confirme que les 1 000 tokens fournis plus BOS demeurent présents dans le contexte remis au runtime et que la portée locale configurée est de 1 200 items.

## 6. Interprétation des résultats

Les tests valident la cohérence logicielle des fonctions P6 dans les cas spécifiés. L'égalité de l'état après rejeu fournit une preuve de reconstruction déterministe pour les lots/textes, la configuration et les versions de runtime testés ; elle ne certifie pas une suppression des copies externes ni une suppression sécurisée au niveau du stockage. Le registre de texte brut doit donc être traité comme une donnée sensible.

Les triplets SEM sont des partitions contiguës de surface ; des séquences arbitraires peuvent être enregistrées comme propositions candidates. La correspondance exacte du suffixe apporte une preuve de réutilisation d'un motif observé, pas une compréhension syntaxique ou une relation causale vraie. DISC fournit des alias de surface potentiels et ne résout pas les pronoms. Les familles locales continuent d'appliquer leurs fenêtres même quand le plafond global est désactivé.

La suite 33/33 confirme les contrats testés et l'intégration GUI/CLI. Elle ne mesure pas une qualité de génération représentative. Les métriques P5 demeurent celles d'un petit test (286 cibles, 167 OOV) avec politiques OOV non équivalentes entre systèmes ; les ablations in-vocabulary sont post-hoc. Le résultat P5 reste une observation exploratoire, non un classement général.

L'audit AST ne détecte aucune importation ou construction neuronale parmi les 20 fichiers runtime analysés. Il s'agit d'une preuve statique limitée aux règles scannées et aux sources Python courantes, pas d'une preuve mathématique contre tout comportement possible du langage ou environnement externe.

## 7. Conséquences

### Théoriques

Les mécanismes de composition sémantique et de mémoire de mentions deviennent exécutables et inspectables sans réseau de neurones. Leur portée correspond à une sémantique candidate fondée sur régularités observées ; un formalisme plus riche d'arguments typés, événements, négation, quantification, coréférence pronominale et composition entre langues demande des expériences séparées.

### Conceptuelles

Les sondes gardent des rôles différenciés : séquences exactes, positions discontinues, morphologie, contexte sémantique sparse, mentions discursives et récupération. COORD combine leurs distributions. Aucune raison empirique fournie par P5 ne justifie de supprimer une famille ; aucune observation n'établit non plus une supériorité universelle.

### Opérationnelles

La réversibilité exacte nécessite la conservation du texte source dans le checkpoint, ce qui augmente sa taille et sa sensibilité. `max_context=0` peut augmenter le coût d'inférence ; les fenêtres locales et le budget RETR doivent être dimensionnés. La GUI dépend de Tkinter ; Xvfb n'est requis que pour les tests sans écran. Les archives livrées resteront des dossiers applicatifs sans interpréteur Python embarqué multi-OS.

## 8. Conclusions

P6 implémente et teste les fonctions avancées identifiées, rend explicites les événements de troncature et corrige le formalisme LaTeX courant. La vérification logicielle est PASS pour les 33 tests exécutés et les contrôles de pureté/schema/compilation cités. Les limites de sémantique générale, de coréférence pronominale, de génération open-vocabulary, de mémoire à long terme et de performance comparative restent décrites comme non démontrées ou non implémentées, plutôt que présentées comme impossibles ou acquises.

## 9. Statut du modèle

**P6 : clôturée avec limitations documentées.** Le runtime 0.2.0 comprend les fonctionnalités P6 décrites ; les contrôles sortent avec les codes attendus. Les phases P0 et P5 conservent leurs réserves précédemment documentées. P7 — construction des trois archives, intégrité interne/externe, vérification du checkpoint et preuve finale — devient la prochaine phase autorisée. Aucun verdict préalable sur le potentiel global du modèle n'est émis.

## Annexes et preuves

- Résumé : `results/p6_validation_summary.json`.
- Suite complète : `logs/p6_final_full_suite.log`, `logs/p6_full_suite.exitcode`, `logs/p6_full_suite.time.log`.
- Tests P6 : `logs/p6_advanced_tests.log`, `logs/p6_advanced_tests.exitcode`.
- Tests GUI : `logs/p6_gui_suite.log`, `logs/p6_gui_suite.exitcode`.
- Compilation LaTeX : `logs/formalism_pass9.log`, `logs/formalism_pass10.log`.
- Validation spécification : `logs/p6_spec_validation.log`, `results/spec_validation_latest.json`.
- Audit pureté : `logs/p6_runtime_purity_audit.log`.
- Matrice : `manifests/requirement_traceability.csv`.
- Checklists : `checklist_de_travail_eSond_v2.json`, `checklist_erreurs_model.json`, `checklist_erreurs_no_model.json`.
- Sauvegarde pré-P6 : `sav_eSond_v2/snapshots/S33_P6_ADVANCED_FEATURES_PREEXEC`.
- Incident LaTeX initial : trois fichiers `logs/formalism_pass9.*` ont été écrasés par une relance ; voir `docs/incidents/P6_TEX_LOG_OVERWRITE_ATTESTATION.pdf` et sa signature Ed25519 détachée.


---

# Addendum de clôture P6 — validation finale, checkpoint réel et incident documenté

**Date :** 2026-11-09T12:04:46+01:00  
**Prévol :** `python scripts/preflight.py --phase P6` — PASS.  
**Savepoint pré-validation :** `S38_P6_FINAL_AUDIT_PREVALIDATION` (379 fichiers, 135 761 914 octets, copies vérifiées par SHA-256).

## 1. Description

Cet addendum clôt la campagne P6 après actualisation de la troncature de contexte, vérification du checkpoint P6 de démonstration et rectification du registre d'incident LaTeX. Les sources originales restent en lecture seule et n'ont pas été intégrées aux checkpoints ni aux archives de livraison.

## 2. Architecture

Le runtime conserve six familles de sondes explicites (`SEQ`, `SKIP_REL`, `MORPH`, `SEM`, `DISC`, `RETR`) et le coordonnateur `COORD`. Le statut de P6 est `PASS_WITH_DOCUMENTED_LIMITATIONS`, pas une revendication de parité avec un LLM généraliste. SEM induit des candidats de spans relationnels observés ; DISC retourne des alias candidats non résolus ; le retrait exact reconstruit un modèle depuis le registre texte de lots ; les limites globales/locales de contexte sont signalées.

## 3. Pipeline complet

1. Prévol et lecture des checklists/chemins/snapshot : PASS.
2. Snapshot `S38_P6_FINAL_AUDIT_PREVALIDATION` avant validations finales : PASS, 379 fichiers, 135 761 914 octets.
3. Compilation Python : PASS.
4. Tests complets CLI/cœur/GUI/P6 : PASS 33/33.
5. Validation formalisme et matrice/schema : PASS, 23 lignes uniques.
6. Audit AST de pureté : 20 fichiers runtime parcourus, 0 finding.
7. Validation du checkpoint P6 réel : JSON Schema Draft 2020-12 PASS, six familles présentes, sidecar conforme.
8. Vérification du cycle train/update/remove : trois checkpoints et trois sidecars vérifiés ; état canonical du modèle après retrait égal au checkpoint de base après exclusion de `model_id` et `created_at`.
9. Vérification cryptographique du rapport d'incident : signature Ed25519 PASS.

## 4. Commandes d'exécution

```bash
python scripts/preflight.py --phase P6
python -m compileall -q src/esonde tests
xvfb-run -a env PYTHONPATH=src python -m unittest discover -s tests -v
python scripts/validate_spec.py
PYTHONPATH=src python scripts/validate_trained_state.py --model models/esonde_v2_p6_demo_checkpoint.json --output results/p6_final_demo_schema_validation.json
PYTHONPATH=src python scripts/verify_p6_demo_checkpoint.py
PYTHONPATH=src python docs/incidents/verify_p6_incident_signature.py
```

Les stdout, journaux d'exécution, codes de retour et mesures GNU time sont conservés sous `logs/p6_final_*`.

## 5. Résultats

| Contrôle | Résultat final |
|---|---:|
| Compilation Python | PASS, exit 0 |
| Tests complets | **33/33 PASS**, exit 0 |
| Durée unittest | 31,827 s |
| Temps mural | 33,38 s |
| RSS maximale | 363 488 KiB |
| Validation spécification | PASS, 23 identifiants de traçabilité uniques |
| Pureté AST | 20 fichiers, 0 finding |
| Checkpoint P6 | 14 872 942 octets, SHA-256 `3af2f56702cdd4b1aa6339a31710a9db1df6e3869ece0fe0d061ce359f32c1da`, sidecar conforme |
| Test retrait de lot | état canonique identique au checkpoint base, 3/3 sidecars conformes |
| Smoke runtime du modèle livré | 10 candidats relationnels, 1 candidat DISC, `resolved=false`; prédiction next-token avec 0 candidats pour la requête smoke fournie |
| Signature attestation incident | Ed25519 vérifiée, SHA-256 PDF `b13fce3b6fb3a933a9b5e19f13a8cabea13b11f6bad7a5b0834efb3496060ca8` |

### Checkpoints de démonstration

Le checkpoint initial contient 8 documents / 415 tokens. Le checkpoint mis à jour contient 9 documents / 433 tokens, avec les lots `initial-train` et `p6-demo-update`. Le checkpoint issu du retrait contient 8 documents / 415 tokens. Après retrait, son état appris complet est identique à l'état de base, hors identifiant et horodatage de reconstruction. Les SHA-256 vérifiés sont : base `3bb33a091ee6ecf64bfba991747825d448e4250ba22838895cab1a10f7ab7c20`, mis à jour `3af2f56702cdd4b1aa6339a31710a9db1df6e3869ece0fe0d061ce359f32c1da`, après retrait `c7f23061accaad09f520fa9e32852457853dbbf66628a7e4250c5d9cfa8e6581`.

### Incident de journal LaTeX

La première tentative ayant échoué sur `_` dans `max_context`, trois journaux (`formalism_pass9.stdout.log`, `formalism_pass9.log`, `formalism_pass9.exitcode`) ont été écrasés par une relance réussie. Le transcript de l'exécution conserve le diagnostic `Missing $ inserted` à la ligne 71 et `Fatal error occurred`, mais les octets originaux et leurs empreintes ne sont pas récupérables. Le PDF `docs/incidents/P6_TEX_LOG_OVERWRITE_ATTESTATION.pdf` décrit cette perte ; `docs/incidents/P6_TEX_LOG_OVERWRITE_ATTESTATION.pub.pem` et `.sig` permettent de vérifier l'intégrité du PDF. Il s'agit d'une signature auto-générée d'intégrité et non d'une attestation d'identité juridique ou d'un horodatage tiers.

## 6. Interprétation

La campagne établit la conformité logicielle des contrats testés, l'intégrité des checkpoints de démonstration et la reconstruction exacte du modèle après retrait du lot pour les checkpoints récents. Le smoke runtime montre cependant zéro candidat next-token pour la requête de test choisie ; les candidats de relations/alias restent des observations sur le petit checkpoint d'exemple. Ni les 33 tests ni l'audit statique n'établissent une qualité linguistique générale, une capacité de raisonnement ou une parité TinyLLM/LLM. P5 reste un petit test multilingue exploratoire, 286 cibles dont 167 OOV, avec des politiques OOV non comparables globalement.

## 7. Conséquences

### Théoriques

Les mécanismes purs-sondes sont exécutables sans couches neuronales détectées dans les sources runtime auditées. Le sens des sorties SEM/DISC reste celui de candidats de motifs, pas une sémantique typée complète ni une coréférence pronominale résolue.

### Conceptuelles

Les résultats de benchmark, les tests de fonctionnement et les tests d'intégrité sont trois types de preuve distincts. Aucun ne doit être substitué à l'autre. La perte de trois journaux doit rester distinguée d'une perte de poids ou de données d'entraînement.

### Opérationnelles

Les checkpoints P6 contiennent du texte UTF-8 d'entraînement et de validation ; ils sont sensibles et nécessitent des contrôles d'accès et de conservation non fournis par le runtime. La suppression d'un lot recrée une nouvelle version mais n'efface pas les copies historiques/snapshots. Le paquet runtime n'embarque pas un interpréteur Python multi-OS ; Python 3.10+ est requis et Tkinter est requis pour la GUI.

## 8. Conclusions

Les contrôles P6 sont terminés avec les réserves ci-dessus. La perte des journaux LaTeX initiaux est documentée sans reconstruction fictive. Aucune perte de checkpoint, poids ou corpus n'a été constatée ; les poids P6 base, mis à jour et après retrait passent leurs contrôles SHA-256.

## 9. Statut du modèle

**P6 : PASS_WITH_DOCUMENTED_LIMITATIONS ; phase clôturable.** La transition vers P7 n'est autorisée qu'après écriture de ce résultat, des incidents et des nouvelles preuves dans les checklists, puis création du snapshot terminal P6. Aucun verdict préalable sur le potentiel général du modèle n'est posé.

### Références finales

- `results/p6_validation_summary.json`
- `results/p6_final_demo_schema_validation.json`
- `results/p6_demo_checkpoint_validation.json`
- `results/p6_demo_batch_removal_summary.json`
- `logs/p6_final_full_suite.log`, `.exitcode`, `.time.log`
- `logs/p6_final_compileall.stdout.log`, `.exitcode`
- `logs/p6_final_spec_validation.stdout.log`, `.exitcode`
- `logs/p6_final_runtime_purity_audit.stdout.log`, `.exitcode`
- `logs/p6_final_demo_checkpoint_verification.stdout.log`, `.exitcode`
- `docs/incidents/P6_TEX_LOG_OVERWRITE_ATTESTATION.pdf` et fichiers de vérification associés
- `S38_P6_FINAL_AUDIT_PREVALIDATION`
