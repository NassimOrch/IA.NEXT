# Rapport d'expérience — [ID]

**Date :** [date/heure avec fuseau]  
**Phase :** [phase]  
**Version runtime / code :** [version + empreintes]  
**Statut :** [PASS / PASS_PARTIEL / FAIL / BLOCKED / NOT_MEASURED]

## 1. Description

[Objectif, question étudiée, périmètre, corpus, splits, paramètres, conditions initiales.]

## 2. Architecture

[Modules, sondes, états, versions et configuration exactes. Séparer architecture cible et éléments réellement exécutés.]

## 3. Pipeline complet

[Étapes ordonnées, prétraitement, exécution, sorties, sauvegardes, validations, post-traitement.]

## 4. Commandes d'exécution

[Commandes exactes, répertoire courant, environnement, seed, code retour, version Python/OS.]

## 5. Résultats

[Tables de métriques brutes, journaux, erreurs, temps, mémoire, taille des états, nombres d'échantillons et empreintes. Distinguer résultat observé et valeur attendue.]

## 6. Interprétation des résultats

[Interprétation bornée au protocole, incertitudes, taille d'échantillon, fuites éventuelles, variance, résultats contradictoires et comparaisons équitables.]

## 7. Conséquences

### Théoriques

[Impact sur les hypothèses et formalismes ; aucune réécriture a posteriori des objectifs pour faire correspondre les résultats.]

### Conceptuelles

[Impact sur le rôle et les interactions des familles de sondes.]

### Opérationnelles

[Impact sur ressources, stabilité, reproductibilité, ergonomie, packaging, sauvegarde.]

## 8. Conclusions

[Réponses aux questions étudiées, sans extrapolation au-delà des observations.]

## 9. Statut du modèle

[Phase atteinte, fonctions réellement disponibles, critères passés/ouverts, risques, prochaine phase autorisée. Ne pas prédire la réussite ou l'échec global du modèle.]

## Annexes et preuves

[SHA-256, manifests, configurations, stdout/stderr, résultats, snapshots, erreurs connues, scripts exacts.]
