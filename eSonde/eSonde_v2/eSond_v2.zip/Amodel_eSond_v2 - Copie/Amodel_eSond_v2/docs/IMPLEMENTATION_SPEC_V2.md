# Spécification d'implémentation — eSond_v2 / eSonde_v1-Generalist

Version : 2.0.0-dev  
Date : 9 novembre 2026  
Statut : contrat P1 ; code et résultats à établir en P2–P6.

## 1. Description et objectifs

Le runtime `eSonde_v0` livré par ce projet est la première réalisation exécutable du profil `eSonde_v1-Generalist` défini par le programme eSond_v2. Il ne remplace pas silencieusement l'ancien `eSonde_v0` tabulaire des archives : ce dernier reste une référence historique séparée.

Le moteur prend du texte Unicode, construit un état causal multi-échelle, interroge six familles d'observation (SEQ, SKIP_REL, MORPH, SEM, DISC, RETR) plus COORD, agrège des distributions de conséquences et produit une continuation. SEM inclut des motifs relationnels A–relation–B ; DISC conserve les mentions observées et expose des candidats d'alias/coréférence. Le mot « généraliste » décrit le périmètre fonctionnel visé (documents, paragraphes, conversation, OOV en entrée, relations sparse et récupération), pas un niveau de qualité supposé. La compréhension, la qualité de réponse, le raisonnement et la robustesse restent des variables d'évaluation.

## 2. Invariants de pureté

Le graphe d'exécution ne doit contenir ni neurone, ni perceptron, ni MLP, ni bloc Transformer, ni embeddings denses appris, ni matrices affines entraînables, ni attention Q/K/V, ni tête de sortie linéaire, ni modèle externe appelé comme enseignant ou composant. Le runtime utilise uniquement Python standard library : chaînes Unicode, dictionnaires, ensembles, compteurs entiers, index inversés, listes d'adjacence, tables sparse, fonctions déterministes, distributions catégorielles et coefficients scalaires explicitement possédés par COORD.

Chaque état acquis doit être attribuable à une sonde ou à COORD et inspectable. Les nombres flottants sont limités aux distances, scores et coefficients de coordination ; ils ne sont pas des poids connectant des neurones. Aucune sérialisation pickle ou exécution de code depuis un checkpoint n'est admise. L'audit AST et les tests du graphe d'appel sont requis, sans être présentés seuls comme preuve absolue.

## 3. Architecture logique

```text
Texte Unicode
   │
   ▼
Tokenizer déterministe + frontières + offsets
   │
   ▼
État causal H_t (fenêtre locale / phrase / paragraphe / document / entités)
   │
   ├── SEQ      clés de suffixes exacts et comptes de continuation
   ├── SKIP/REL motifs de positions discontinues et relations observées
   ├── MORPH    préfixes/suffixes/n-grammes Unicode et formes de surface
   ├── SEM      profils lexicaux sparse + graphe de cooccurrence
   ├── DISC     mémoire de mentions et signaux de document déjà observés
   └── RETR     index inversé d'exemples avec offsets et origine
             │
             ▼
      COORD (sonde de coordination)
      support / distance / fiabilité / calibration / provenance
             │
             ▼
 Distribution catégorielle → décodage → ajout à H_t → itération
```

Les modules partagent un contrat commun `ProbeResponse`: `family`, `distribution`, `support`, `distance`, `entropy`, `diagnostics`, `provenance`, `active`. Les modules ne peuvent lire le futur du flux. Toutes les clés et tables sont sparse. L'état des documents et les index de conversation sont séparés.

## 4. Disposition et responsabilités par module

| Module | Contrat précis | Données d'état | Diagnostic minimum |
|---|---|---|---|
| `tokenizer.py` | tokenization déterministe Unicode NFC par catégories L/N/M, surface originale, offsets en indices de points de code Python, frontières, attributs de casse/ponctuation | version, règle Unicode, pattern | `OOV_INPUT`, `BOUNDARY` |
| `state.py` | `H_t`, mémoire causale multi-échelle, mentions et entités concurrentes | historique, positions, compteurs, frontières | `TRUNCATED_CONTEXT`, `MEMORY_BUDGET_REACHED` |
| `probes/seq.py` | suffixes contigus exacts, ordres 1..N, décroissance par ordre | table de contexte → conséquences | `EXACT_SUPPORT`, `UNSEEN_CONTEXT` |
| `probes/skip_rel.py` | couples/tuples aux offsets relatifs déclarés, frontières obligatoires | table motif → conséquence/relation | `SPARSE_MATCH`, `INCOMPLETE_PATTERN` |
| `probes/morph.py` | caractéristiques de caractères 1–5, préfixes/suffixes, longueur, casse, punctuation | feature → token conséquences; tables char si activées | `OOV_INPUT`, `MORPH_MATCH` |
| `probes/sem.py` | pondération TF-IDF sparse, Jaccard pondéré, graphe de cooccurrence et extraction de triplets de clause A–relation–B (A 1–2 tokens, relation 1–3, B 1–2) | postings, adjacency, tables de propositions/conséquences, provenance | `SEMANTIC_NEIGHBOR_MATCH`, `COMPOSED_RELATION_MATCH` |
| `probes/disc.py` | mémoire causale de termes et registre de mentions à initiale majuscule ; candidats d’alias par Jaccard pondéré IDF, sans résolution forcée | mentions, compteurs, fréquences, documents et preuves de source | `LONG_RANGE_MATCH`, `SURFACE_ALIAS_CANDIDATE` |
| `probes/retr.py` | top-k par index inversé/BM25/Jaccard, fenêtre strictement antérieure à la cible | enregistrements bornés, postings, attribution | `RETRIEVAL_MATCH`, `NEAR_COPY` |
| `probes/coord.py` | mélange probabiliste, poids simplex, repli train-only | poids, calibration, essais | `NO_ACTIVE_PROBE`, `COORD_FALLBACK` |
| `model.py` | orchestration train/predict/generate/score/retrieve/relations/coref/inspect/audit et retrait exact de lot par rejeu | assemblage de tous les états et registre d’entraînement retenu | diagnostics agrégés |
| `serialization.py` | JSON canonique, atomic replace, SHA-256, schéma, version | manifestes d'intégrité | `CHECKSUM_FAIL`, `SCHEMA_FAIL` |
| `cli.py` | façade CLI | aucun état d'apprentissage propre | codes de retour stables |
| `gui.py` | GUI Tk facultative, service partagé, opérations longues en worker | état UI seulement | exceptions et statut de sauvegarde |
| `diagnostics.py` | traces de provenance, tailles, supports, activation, copies | événements/rapports | inventaire complet |
| `evaluation.py` | log-loss, perplexité, top-k, relations, retrieval, coût, ablation | rapports reproductibles | statut NOT_MEASURED distinct de 0 |

## 5. Définition exécutable des sondes

Les détails mathématiques obligatoires sont dans `formalism/formalisme_eSond_v2.tex`. Contrats d'implémentation :

### SEQ
Construire `context_suffix -> Counter(next_token)` pour chaque ordre jusqu'à `max_order`. À l'inférence, lire du contexte le plus long vers le plus court et combiner selon `seq_decay`. Frontières de phrase/document dans les clés. Aucune table n'est préremplie par un résultat attendu.

### SKIP/REL
Utiliser l'ensemble initial de motifs `[(1,2),(1,3),(1,5),(1,8),(1,13),(2,5),(2,8)]`, configurable. Stocker une clé ordonnée incluant les distances et la frontière. Aucun motif incomplet ne s'active. Les relations structurées conservent exemple, positions et source.

### MORPH
Pour chaque token antérieur, extraire préfixes/suffixes, n-grammes et signature de surface Unicode ; associer les caractéristiques de contexte au token suivant observé. Une entrée OOV n'est pas remplacée par UNK : sa surface entre dans l'extraction. Le modèle initial n'annonce pas une génération ouverte arbitraire sans test de composition de caractères.

### SEM
Construire des postings sparse de termes du préfixe vers les conséquences. Pondération TF-IDF calculée sur le train uniquement. La similarité recommandée est Jaccard pondéré. Construire des arêtes de graphe avec type, compte, positions et identifiants source ; aucune matrice `|V| × |V|` dense. Le module induit aussi des triplets A–relation–B depuis chaque clause achevée au token courant et interroge les conséquences du suffixe A–relation exact. La preuve reste une composition de segments observés, pas un parseur validé.

### DISC
Mémoriser les termes distinctifs et les suites de 1–4 tokens à initiale majuscule déjà observées. Au pas d'entraînement t, les caractéristiques de discours sont calculées uniquement jusqu'au token courant observé, jamais sur les tokens suivants. Les candidats d'alias sont classés par recouvrement de tokens pondéré par fréquence inverse ; chaque candidat garde sa forme, distance, support, document et preuve. `resolved=false` reste obligatoire ; cette version ne revendique pas de résolution pronominale complète.

### RETR
Index des fenêtres de contexte causales, avec token suivant, source, offsets et hash. Recherche top-k avec index inversé et similarité sparse. Les extraits renvoyés conservent leur attribution. Les cas de copie exacte exigent l’égalité de la fenêtre ordonnée complète ; un simple Jaccard de caractéristiques identique n’est pas étiqueté copie. Le réservoir d’exemples applique un Algorithm-R déterministe et borné, avec index inversé corrigé lors des remplacements. Les cas de copie sont comptés séparément et n’alimentent pas une revendication de généralisation.

### COORD
Normaliser chaque distribution famille, puis combiner avec des coefficients non négatifs de somme 1. Calibration exclusivement sur validation indépendante. Si aucun support n'est actif, utiliser un backoff unigramme calculé sur le train et émettre `NO_ACTIVE_PROBE`. Si aucune validation n'est fournie, utiliser des coefficients neutres/configurés et écrire `calibration_status=NOT_CALIBRATED`.

## 6. Pipeline complet et séparation des données

1. Prévol : chemins canoniques, checklists, incidents, savepoint, environnement, capacité disque.
2. Inventaire des corpus : documents, encodage, frontières, SHA-256, exclusions et consentement.
3. Partition : séparation au niveau document/source lorsque possible ; aucune fenêtre d'un document ne doit traverser train/validation/test.
4. Tokenization : offsets, frontières et surfaces préservés.
5. Train : extraction causale des sondes et de leur provenance.
6. Validation : choix de paramètres et calibration COORD uniquement sur validation.
7. Gel : sauvegarder code/configuration/état/checksums et figer commande.
8. Test : test indépendant déclaré, jamais lu pour calibration.
9. Ablations : SEQ seul, chaque famille isolée, assemblages sans famille, mémoire/Retrival on/off.
10. Coûts : mesure indexation, fit, batch 1/16/64, p50/p95, mémoire et taille du modèle.
11. Rapport : commandes, logs, résultats, interprétation, effets théoriques/conceptuels/opérationnels, conclusion, statut.
12. Sauvegarde : snapshot atomique, checklists et manifestes réactualisés avant phase suivante.

Un corpus à document unique ne fournit pas de séparation indépendante par document. Dans ce cas, le programme doit l'indiquer et ne pas étiqueter une métrique calculée sur le même document comme mesure de généralisation.

## 7. Contrat d'état JSON et intégrité

Le modèle sauvegardé doit suivre `schemas/model_state.schema.json`. Les clés de tables sont sérialisées de manière canonique ; les compteurs sont des entiers positifs ; les scalaires sont finis ; les provenance entries réfèrent à un lot/hash/source. Le `payload_sha256` est calculé sur JSON canonique sans le champ `integrity`; un sidecar SHA-256 référence les octets exacts du fichier final. `save()` écrit au même volume dans un temporaire unique, synchronise lorsque disponible, puis remplace atomiquement. `load()` refuse un checksum, schéma ou version invalide ; l'ancien état n'est jamais écrasé avant validation complète.

Les poids du modèle ne sont pas des poids neuronaux : ils sont l'état original des sondes (compteurs, signatures, graphes, mémoire, index) et les coefficients simplex de COORD. Les archives sources EX3–EX12 et leurs checkpoints ne sont ni copiés ni importés dans le runtime release.

## 8. API publique

| Méthode | Entrée | Sortie | Garantie |
|---|---|---|---|
| `train(documents, config, validation=None)` | chemins/documents déclarés | modèle + rapport | train-only pour les index; validation isolée |
| `update(documents, batch_id)` | nouveau lot identifié | état mis à jour + preuves | ajout traçable; calibration marquée obsolète |
| `calibrate(validation)` | partition indépendante | rapport COORD | ajuste COORD seulement, pas les tables de sondes |
| `predict_next(text, top_k)` | contexte Unicode | distribution + diagnostics | aucune cible future consultée |
| `generate(prompt, max_tokens, strategy, seed)` | prompt/options | texte + trace | déterminisme si stratégie/graine fixes |
| `score(documents)` | corpus d'évaluation séparé | logloss/perplexity/top-k | n'entraîne/calibre pas le modèle |
| `retrieve(query, top_k)` | requête | passages attribués | provenance de chaque résultat |
| `inspect(family, key)` | famille/clé | support/compteurs/provenance | lecture seule |
| `audit()` | état courant | diagnostics/pureté/intégrité | n'exécute pas de code sauvegardé |
| `save(path)` / `load(path)` | chemin | état validé | JSON + SHA-256, round-trip |

## 9. CLI et GUI — contrat commun

CLI : `train`, `update`, `remove-batch`, `calibrate`, `generate`, `score`, `retrieve`, `relations`, `coref`, `inspect`, `audit`, `info`, `demo`. Les commandes doivent prendre `--model` ou `--output`, fournir `--help`, retourner un code non nul en cas d'erreur et préserver les fichiers précédents.

GUI minimale : choix de corpus et validation, configuration de l'entraînement, progression et logs, saisie de prompt, génération, récupération, inspection famille/sonde, affichage de provenance, état sauvegarde et audit. Les opérations longues ne s'exécutent pas dans la boucle Tk ; l'UI montre échec/succès réel, jamais un succès anticipé. Si Tkinter n'est pas installé dans la distribution Python hôte, le CLI reste utilisable et la dépendance OS est expliquée.

## 10. Traçabilité des tests et critères de sortie

Les identifiants `REQ-*` dans `manifests/requirement_traceability.csv` relient les sections formelles aux modules et tests. Les tests de familles incluent support, déterminisme, OOV, provenance, leakage causal, round-trip, top-k et ablation. Les tests P2–P6 doivent inscrire commande exacte, environnement, stdout/stderr, code retour, résultat JSON, SHA-256 et statut. Un test logiciel PASS ne constitue pas un résultat de qualité linguistique.

## 11. Limites explicitement ouvertes

- OOV en entrée et génération de formes nouvelles sont des capacités différentes.
- Le graphe de cooccurrence sparse et les triplets de segments constituent une sémantique opérationnelle candidate, pas une preuve de compréhension humaine ou de parse syntaxique.
- La coréférence actuelle couvre des candidats de mentions de surface, surtout les formes à initiale majuscule ; elle ne résout pas exhaustivement les pronoms ou les anaphores multilingues.
- La réversibilité exacte exige le registre complet du texte d’entraînement dans le checkpoint ; cela augmente taille et sensibilité des fichiers.
- `max_context=0` supprime le plafond global additionnel, mais ne supprime pas les fenêtres locales propres à chaque famille. Pour un plafond positif, le moteur renvoie explicitement les items fournis/retenus/écartés et compte les cibles de score tronquées.
- Coréférence et relation propositionnelle peuvent être ambigües ; les conflits doivent rester visibles.
- Une grande quantité de compteurs sparse peut être coûteuse ; budgets et évictions doivent être mesurés.
- La généralisation doit être mesurée par documents/sources/langues/domaines non vus.
- Le niveau de qualité d'un grand modèle de langage n'est ni présupposé ni exclu.

## 12. Statut

`P1_SPECIFICATION_IN_PROGRESS` jusqu'à validation des schémas, API, matrice de traçabilité, compilation du formalisme et tests de cohérence documentaire. Aucun entraînement ou benchmark du modèle n'est inclus dans cette phase.
