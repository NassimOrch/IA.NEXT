# Rapport de validation P5 — eSond_v2

**Date :** 2026-11-09T10:49:25+01:00  
**Phase :** P5_VALIDATION  
**Runtime :** eSond_v2, build source tree  
**Statut :** COMPLETE_WITH_DOCUMENTED_LIMITATIONS

## 1. Description

P5 évalue le runtime pure-sonde sur un corpus indépendant de 36 documents multilingues (anglais, français, arabe, espagnol) : 20 documents train, 8 validation et 8 test. Le jeu test comprend 8 documents et 286 tokens. Les modèles unigramme et suffixe n-gramme ordre 3 avec backoff sont les références descriptives pré-spécifiées dans le protocole. Aucune donnée des deux archives historiques n’a été importée dans ce benchmark.

Le but n’est pas de statuer sur la réussite ou l’échec futur de la famille eSonde. Le rapport expose les capacités observées, les résultats négatifs, les écarts méthodologiques et les éléments qui restent non démontrés.

## 2. Architecture

Le runtime exécuté est constitué de sondes symboliques/sparse : SEQ (ordres locaux), SKIP_REL (relations à positions distantes), MORPH (caractéristiques morphologiques Unicode), SEM (cooccurrences et graphe distributionnel sparse), DISC (contexte discursif/mémoire), RETR (récupération bornée avec provenance), et COORD (mélange catégoriel calibré sur validation). Le modèle n’utilise pas d’embeddings appris denses, de projections affines, de couches denses, d’attention Q/K/V ni de MLP. L’audit AST statique porte sur 20 fichiers du runtime et n’a relevé aucun finding ; il ne remplace pas une preuve formelle sur tout code tiers ou environnement d’exécution.

Le checkpoint de référence est `results/p5_multilingual_model.json`, 23 618 835 octets, SHA-256 `f9085d5016eb9091378db8c9ca23aa92c6410a653a3663c78065beed44defa46`. Toutes les six familles de sondes requises sont présentes ; le schéma JSON Draft 2020-12 passe sans erreur.

## 3. Pipeline complet

1. Lecture UTF-8 et normalisation déterministe du tokenizer. 2. Apprentissage des tables/graphes/structures des six sondes uniquement sur les 20 documents train (791 tokens). 3. Calibration COORD uniquement sur les 8 documents validation (285 cibles, 11 essais). 4. Sauvegarde du checkpoint avant l’évaluation de test. 5. Score sur les 8 documents test (286 tokens). 6. Comparaison aux baselines unigramme et suffix n-gramme. 7. Ablations leave-one-family-out et family-only en gardant les coefficients/configuration de référence. 8. Tests comportementaux, contrôles anti-fuite, audits statiques, validation du schéma et diagnostics OOV post-hoc. 9. Réentraînement instrumenté séparé, sans écraser le checkpoint de référence.

Le manifeste du checkpoint contient 20 éléments train et 8 validation ; aucun identifiant ni SHA-256 de document test ne recoupe ce manifeste. Ce résultat établit l’absence de test dans l’état sauvegardé, sans prétendre prouver indépendamment tous les accès de processus.

## 4. Commandes d’exécution

Les commandes ont été lancées depuis la racine du projet `/mnt/data/esond_work/esond_v2_project`.

```bash
python scripts/validate_p5_corpus.py
python -u scripts/run_p5_stages.py full
python -u scripts/run_p5_stages.py baselines
python -u scripts/run_p5_stages.py ablation --family SEQ
python -u scripts/run_p5_stages.py ablation --family SKIP_REL
python -u scripts/run_p5_stages.py ablation --family MORPH
python -u scripts/run_p5_stages.py ablation --family SEM
python -u scripts/run_p5_stages.py ablation --family DISC
python -u scripts/run_p5_stages.py ablation --family RETR
python -u scripts/run_p5_stages.py behavior
xvfb-run -a env PYTHONPATH=src python -m unittest discover -s tests -p test_*.py -v
python -m esonde audit --model results/p5_multilingual_model.json --output results/p5_runtime_model_audit.json
python scripts/validate_trained_state.py
python scripts/validate_spec.py
python scripts/analyze_p5_oov_fairness.py
python scripts/analyze_p5_in_vocab_ablations_fast.py
python scripts/audit_p5_protocol_timing.py
```

Réentraînement instrumenté séparé :

```bash
/usr/bin/time -v env PYTHONPATH=src python -m esonde train --corpus benchmarks/p5_multilingual/train --validation benchmarks/p5_multilingual/validation --config benchmarks/p5_config.json --output results/p5_instrumented_retrain_model.json
```

Les journaux bruts, sorties JSON et codes retour sont conservés dans `logs/` et `results/`. Deux passages de la suite complète ont donné 22/22 tests (19,531 s puis 19,144 s). Les lots cœur, CLI et GUI sont respectivement à 14/14, 5/5 et 3/3.

## 5. Résultats

### 5.1 Test complet (286 cibles)

| Système | Log-loss | Perplexité | Top-1 | Top-5 |
|---|---:|---:|---:|---:|
| eSonde | 17.879136 | 58184872.25 | 0.0839 | 0.2098 |
| Unigramme α=0,1 | 7.335605 | 1533.95 | 0.0804 | 0.1259 |
| Suffix n-gramme (3→2→1), α=0,1 | 6.508796 | 671.02 | 0.0909 | 0.2867 |

Les métriques globales de perplexité/log-loss ne sont pas directement comparables : les systèmes ont des politiques OOV différentes.

### 5.2 Couverture OOV et sous-ensemble contrôlé

Sur 286 cibles, 167 (58.39 %) sont OOV et 119 sont connues. Le taux OOV est particulièrement élevé en arabe : 74.58 %. Le diagnostic post-hoc sur les 119 cibles connues donne :

| Système | Log-loss | Perplexité | Top-1 | Top-5 |
|---|---:|---:|---:|---:|
| eSonde | 4.193717 | 66.27 | 0.2017 | 0.5042 |
| Unigramme | 4.941025 | 139.91 | 0.1933 | 0.3025 |
| Suffix n-gramme | 4.840147 | 126.49 | 0.2185 | 0.4034 |

Ce sous-ensemble est descriptif et post-hoc. Les cibles OOV sont retirées des métriques, mais les tokens OOV précédents restent dans le contexte ; les résultats ne remplacent donc pas un benchmark open-vocabulary commun et prospectif.

### 5.3 Ablations sur 119 cibles connues (post-hoc)

| Variante | Log-loss | PPL | Top-1 | Top-5 |
|---|---:|---:|---:|---:|
| Ensemble complet | 4.193717 | 66.27 | 0.2017 | 0.5042 |
| Sans SEQ | 4.289309 | 72.92 | 0.1849 | 0.4454 |
| Sans SKIP_REL | 4.188766 | 65.94 | 0.2101 | 0.5042 |
| Sans MORPH | 4.222711 | 68.22 | 0.2017 | 0.4958 |
| Sans SEM | 4.400114 | 81.46 | 0.2101 | 0.4706 |
| Sans DISC | 4.192630 | 66.20 | 0.2017 | 0.5042 |
| Sans RETR | 4.193911 | 66.28 | 0.2017 | 0.5042 |
| SEQ seule | 4.552024 | 94.82 | 0.2017 | 0.3950 |
| SKIP_REL seule | 4.434373 | 84.30 | 0.1849 | 0.3950 |
| MORPH seule | 4.490757 | 89.19 | 0.2101 | 0.3866 |
| SEM seule | 4.323376 | 75.44 | 0.2017 | 0.4454 |
| DISC seule | 4.626007 | 102.11 | 0.1849 | 0.4034 |
| RETR seule | 5.948069 | 383.01 | 0.0756 | 0.2353 |

L’optimisation de calcul a réutilisé les réponses de chaque sonde par contexte ; l’équivalence numérique est vérifiée avec une erreur absolue maximale de 1.110e-16. Le recalcul complet de référence correspond exactement aux métriques antérieures (différences nulles).

### 5.4 Comportement

Génération à graine fixe : répétition exacte = True. Exemple produit : ` A river changes its course slowly as water, downstream. from interpretation la durée. flood barrier `. L’entrée contenant `quorvex` est acceptée, mais le top-5 inclut essentiellement ponctuation et mots fréquents. Le contexte long de 1000 tokens active SEQ, MORPH, SEM, DISC, RETR. Ce test confirme l’exécution d’un long contexte, pas la qualité sémantique générale.

### 5.5 Ressources instrumentées

Un nouveau fit isolé, sur le même corpus train/validation et la même configuration, a été chronométré : 21.83 s écoulées, RSS max 249,240 KiB, sortie 23,618,835 octets. Le code retour stocké et le statut GNU time valent 0. Après suppression des champs purement métadonnées (`model_id`, `created_at`, enveloppe `integrity`), l’état canonique du deuxième modèle est identique à l’état de référence (différences structurelles : 0). Les empreintes du fichier entier diffèrent car ces métadonnées changent. Ce chiffre provient d’un réentraînement de mesure, pas du processus initial de production du checkpoint.

## 6. Interprétation des résultats

Les tests logiciels indiquent une exécution stable des parcours automatisés, un round-trip de sérialisation exact, une calibration persistée et une auditabilité des états. Le résultat top-5 d’eSonde sur les 119 cibles connues est descriptivement supérieur aux deux références observées, tandis que le top-1 du suffix n-gramme demeure supérieur ; le jeu est trop réduit pour généraliser ces comparaisons. Sur le test complet, la perplexité eSonde n’est pas interprétable comme une comparaison honnête avec les baselines tant que la politique OOV n’est pas commune.

Les ablations in-vocabulary montrent une perte log-loss importante lorsque SEM est retirée, puis lorsque SEQ est retirée ; l’absence de SKIP_REL réduit légèrement la log-loss dans cet échantillon. DISC et RETR sont proches de l’ensemble dans le test leave-one-out, mais leurs configurations seules sont sensiblement moins bonnes. Ces observations sont propres à ce corpus, à la calibration et à 119 cibles connues ; elles ne constituent pas un classement définitif des familles.

La sortie de génération mêle plusieurs langues. L’entrée OOV est tolérée en contexte, mais le système ne produit pas de nouvelles unités lexicales ouvertes : la sortie est restreinte au vocabulaire acquis. Ainsi, l’objectif « généraliste avec sémantique et traitement OOV » est partiellement implémenté, mais non validé au niveau d’un petit modèle de langage généraliste du marché.

Chronologie : le protocole Markdown, le manifeste du corpus et la configuration précèdent le checkpoint. En revanche, l’enregistrement JSON formel `P5_PREREGISTRATION.json` est postérieur aux premiers résultats complets et baselines. Il est donc faux de qualifier cet enregistrement JSON de pré-enregistrement prospectif. Le manifeste sauvegardé du modèle a zéro recouvrement avec les ID et SHA des documents test ; les horodatages mtime demeurent une preuve limitée, non signée et non fiable cryptographiquement.

## 7. Conséquences

### Théoriques

Les observations ne remettent pas en cause la formalisation pure-sonde ; elles montrent que le vocabulaire fermé et l’agrégation de sondes symboliques ne suffisent pas encore à démontrer une sémantique compositionnelle ou une généralisation lexicale ouverte. La famille SEM joue un rôle marqué dans le sous-ensemble mesuré, mais cet effet doit être retesté sur un corpus plus grand et prospectif.

### Conceptuelles

La séparation entre sondes lexicales locales (SEQ), relationnelles (SKIP_REL), morphologiques (MORPH), distributionnelles (SEM), discursives (DISC) et de récupération (RETR) est exécutable. La contribution de chaque famille varie selon l’échantillon. L’ablation ne justifie pas de supprimer aujourd’hui une famille du modèle général.

### Opérationnelles

Le cœur s’exécute en bibliothèque standard Python ; Tkinter dépend de l’installation OS et le runtime requiert Python 3.10+. Le modèle d’évaluation pèse 23,6 MB. Le réentraînement instrumenté consomme 249 240 KiB de RSS maximale dans cet environnement ; ce nombre est spécifique à cette machine et ne doit pas être universalisé. Les snapshots successifs conservent les états et journaux.

## 8. Conclusions

P5 a produit un runtime et des workflows testés, des évaluations multilingues, des ablations, un audit statique pur-sonde et des contrôles d’intégrité reproductibles. Les métriques OOV globales sont non comparables entre systèmes ; le sous-ensemble connu et ses ablations sont post-hoc et de petite taille. La génération déterministe est démontrée ; une qualité sémantique généraliste ou une génération lexicale ouverte ne l’est pas. Aucune conclusion préalable de réussite ou d’échec global n’est émise.

## 9. Statut du modèle

**P5 : clôturée avec limitations et réserves méthodologiques documentées.** Le noyau, CLI, GUI, sauvegarde/chargement, audit, génération déterministe, calibration et évaluations exécutées sont disponibles. La validation logicielle est positive (22/22 tests deux fois). La validation sémantique est seulement exploratoire et limitée. Les risques SEM, OOV, calibration sous changement de domaine, mémoire à grande échelle et preuve de non-fuite au niveau processus restent ouverts.

**P6 n’est pas ouverte par ce rapport.** Elle ne pourra commencer qu’après la clôture formelle P5, puis la rédaction d’un protocole neuf, d’un jeu indépendant et de critères de sortie dédiés à l’ouverture du vocabulaire, à la composition sémantique et à l’évaluation inter-domaines.

## Annexes et preuves

- Checkpoint de référence : SHA-256 `f9085d5016eb9091378db8c9ca23aa92c6410a653a3663c78065beed44defa46`.
- Corpus : `benchmarks/p5_dataset_manifest.json`; configuration : `benchmarks/p5_config.json`.
- Protocole et réserve chronologique : `docs/PROTOCOL_EXPERIMENTAL_VALIDATION.md`, `results/p5_protocol_timing_audit.json`.
- Résultats : `results/p5_stage_full.json`, `results/p5_stage_baselines.json`, `results/p5_stage_ablations.json`, `results/p5_stage_behavior.json`, `results/p5_oov_fairness_diagnostic.json`, `results/p5_in_vocab_ablations_diagnostic.json`.
- Validation : `logs/p5_test_suite_run1.log`, `logs/p5_test_suite_run2.log`, `results/p5_runtime_model_audit.json`, `logs/p5_trained_state_schema.log`, `logs/p5_spec_validation.log`.
- Ressources : `logs/p5_instrumented_train.time.log`, `logs/p5_instrumented_train.stdout.log`, `results/p5_instrumented_retrain_model.json`.
- Résumé agrégé JSON : `results/p5_validation_summary.json`.
- Snapshot de pré-exécution instrumentée : `S29_P5_INSTRUMENTED_TRAIN_PREEXEC`.


## Addendum d'audit P6 — clarification du test de contexte long

L'audit du code d'inférence (`src/esonde/model.py`, méthode `_context_from_text`) précise la portée du test de 1 000 tokens mentionné en section 5.4 : le runtime construit `[BOS] + tokens`, puis conserve seulement `context[-max_context:]`. Avec `max_context=512`, seuls les 512 derniers éléments sont transmis aux sondes ; les 488 éléments les plus anciens sont écartés et le marqueur BOS peut également sortir de la fenêtre. Le test P5 confirme donc l'acceptation et le traitement d'une entrée de 1 000 tokens avec troncature, et non une capacité de mémoire effective sur les 1 000 tokens. La mention antérieure d'activation des familles est à lire dans ce périmètre tronqué.

Cette clarification ne change pas les métriques P5 ni les poids ; elle remplace toute interprétation plus large du test long. Risque `LONG-001` actualisé dans `checklist_erreurs_model.json`.
