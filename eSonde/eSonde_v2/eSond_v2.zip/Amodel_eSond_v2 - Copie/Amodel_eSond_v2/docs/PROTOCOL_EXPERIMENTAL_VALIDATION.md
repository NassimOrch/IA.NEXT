# Protocole expérimental eSonde v2 — validation logicielle et qualité linguistique

**Version :** 1.0  
**Date d'enregistrement :** 9 novembre 2026  
**Objectif :** évaluer le comportement fonctionnel et linguistique de façon falsifiable, sans présupposer l'issue.

## 1. Règles méthodologiques

1. Séparer les tests de correction logicielle des mesures de qualité linguistique.
2. Déclarer corpus, langue, domaine, split, métriques, graines et paramètres avant les runs.
3. Ne pas utiliser le jeu test pour entraîner, calibrer COORD, choisir hyperparamètres ou modifier les sondes.
4. Toute modification après lecture des résultats test crée une nouvelle version expérimentale et exige un nouveau jeu test ou une séparation temporelle/source indépendante.
5. Conserver les résultats bruts, les échecs, les essais invalides et leurs empreintes.
6. Comparer sur les mêmes documents/tokenizers et splits ; ne pas comparer des chiffres issus de protocoles différents.
7. Les baselines classiques sont des comparateurs externes au modèle, pas des modules importés dans eSonde.
8. L'ablation est exécutée sur des copies en mémoire de l'état entraîné ; le checkpoint de référence reste immuable.
9. Les métriques sont toujours accompagnées du nombre de documents/tokens. Un échantillon minuscule est décrit comme exploratoire.
10. Aucun résultat de code/test ne vaut preuve de compréhension ou de performance commerciale.

## 2. Questions P5 pré-enregistrées

- Q1 : le runtime complet s'exécute-t-il de manière déterministe et sans erreur sur des entrées multilingues documentées ?
- Q2 : quelles métriques next-token observées le modèle obtient-il sur des documents indépendants en anglais, français, arabe et espagnol ?
- Q3 : comment les résultats se comparent-ils à un baseline unigramme et à un baseline n-gramme de suffixes ?
- Q4 : quelles familles contribuent au score complet selon les ablations leave-one-family-out et family-only ?
- Q5 : quelles familles s'activent pour contexte local, contexte éloigné et récupération ?
- Q6 : le modèle garde-t-il une provenance correcte et évite-t-il fuite/leakage sur le protocole déclaré ?
- Q7 : quels coûts en temps, mémoire et taille du checkpoint sont observés ?

## 3. Corpus P5

Le corpus `benchmarks/p5_multilingual/` est construit pour l'évaluation de ce projet et ne copie pas les sources utilisateur. Il contient quatre langues (en, fr, ar, es), des domaines mixtes, et des partitions disjointes au niveau document : train, validation et test. Le manifeste `benchmarks/p5_dataset_manifest.json` donne le SHA-256 de chaque document. Les partitions test ne sont ni fournies au modèle pendant l'entraînement ni utilisées pour calibration.

La validation sert uniquement à calibrer COORD. La configuration est figée dans `benchmarks/p5_config.json`. La graine des baselines stochastiques, lorsqu'elles existent, doit être persistée ; les baselines de ce protocole sont déterministes.

## 4. Baselines

- **Unigramme** : compte de tokens du train avec lissage add-alpha, calculé uniquement sur le train.
- **N-gramme suffixe** : backoff exact sur suffixes d'ordre 3, 2, 1, puis unigramme ; alpha fixé avant le test. Aucun entraînement neuronal.

Ces comparateurs servent à contextualiser les métriques. Ils ne sont pas des composants d'eSonde et ne sont pas injectés dans le runtime.

## 5. Métriques

- Nombre de documents et de tokens évalués.
- Log-loss moyenne par token et perplexité `exp(log-loss)`.
- Exactitude top-1 et top-5.
- Résultats globaux et par langue.
- Temps d'entraînement, score, prédiction batch, taille JSON, pic RSS si mesurable.
- Ablations : full, leave-one-family-out pour chaque famille, family-only pour chaque famille.
- Diagnostics : activation des familles, poids COORD, couverture contexte, OOV, provenance, copie exacte et fuite de split.

Les pertes peuvent devenir très élevées quand la cible est absente du vocabulaire appris ; ce comportement est reporté, non tronqué ou masqué. Les métriques sont rapportées avec leur dénominateur.

## 6. Ablations

Les ablations opèrent sur un modèle chargé en mémoire. Pour `leave-one-family-out`, mettre à zéro le poids COORD de la famille retirée puis renormaliser les autres poids non négatifs. Pour `family-only`, la famille testée reçoit le poids 1 et les autres 0. Les paramètres de sondes et le jeu train ne changent pas. Le checkpoint principal n'est jamais écrasé.

Si une famille n'est pas active dans un contexte, le coordonnateur utilise uniquement les familles actives conformément au contrat du modèle ; les observations d'activation doivent être interprétées séparément des poids nominaux.

## 7. Contrôles logiciels et intégrité

- compileall sur le runtime, CLI et GUI.
- suite complète P2/P3/P4.
- répétition de génération avec seed identique ; comparaison des sorties exactes.
- chargement du checkpoint et vérification sidecar/payload.
- validation JSON Schema sur l'état réel.
- audit AST statique de pureté, accompagné de l'inspection des dépendances.
- détection de fuite par ID et SHA-256 entre partitions.
- sauvegarde avant toute exécution d'entraînement/benchmark ; sauvegarde après et journal de commande.

## 8. Interprétation et limites

Aucun seuil de réussite général n'est fixé après coup. Les observations sont confrontées aux critères documentés et aux baselines. Les différences de domaine, d'écriture, de langue et de tokenisation sont rapportées. Une bonne valeur sur un petit test ne prouve pas une généralisation ; une mauvaise valeur n'établit pas une impossibilité architecturale.

Toute anomalie de code conduit à un incident documenté, un correctif versionné, un nouveau snapshot pré-exécution et une reprise complète du test concerné. Toute modification après une mesure test interdit de réutiliser cette mesure comme validation indépendante de la version modifiée.

## 9. Rapport attendu

Chaque run est décrit avec `docs/REPORT_TEMPLATE.md` et inclut description, architecture, pipeline complet, commandes d'exécution, résultats, interprétation, conséquences théoriques/conceptuelles/opérationnelles, conclusions et statut. Les fichiers sources d'origine restent exclus des archives runtime, audit et suivi.


## 10. Réserve de chronologie du registre P5

L'audit `results/p5_protocol_timing_audit.json` distingue les documents méthodologiques préexistants du registre JSON structuré. Les mtime UTC disponibles indiquent que ce protocole Markdown, `p5_config.json` et `p5_dataset_manifest.json` précèdent le checkpoint ; le checkpoint précède les premiers résultats complets et baseline ; le fichier `P5_PREREGISTRATION.json` est postérieur à ces premiers résultats. Il est donc incorrect de qualifier le fichier JSON comme pré-enregistrement prospectif des premières mesures. Les résultats P5 sont conservés, mais portent cette réserve de traçabilité. Le checkpoint contient 20 entrées train et 8 validation ; aucun ID ni SHA-256 du test ne recoupe son manifeste. Les mtimes sont des métadonnées de système de fichiers, pas un horodatage cryptographique de confiance.
