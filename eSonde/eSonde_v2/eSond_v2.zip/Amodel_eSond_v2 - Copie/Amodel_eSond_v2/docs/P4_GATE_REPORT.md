# Rapport de clôture P4 — Interface graphique eSonde v2

**Date :** 9 novembre 2026  
**Phase :** P4_GUI  
**Périmètre :** démarrage Tkinter, workflows graphiques, exécution asynchrone, gestion d'erreurs et documentation utilisateur.  
**Statut de la phase :** PASS sur critères GUI et fonctionnement d'interface.

## 1. Description

P4 fournit une interface graphique locale au modèle eSonde v2. Elle couvre les principales opérations d'utilisation et partage strictement la même classe `ProbeModel` que la CLI. Aucun service distant, framework de machine learning tiers ou moteur d'inférence parallèle n'est requis.

## 2. Architecture

- `src/esonde/gui.py` : interface Tkinter, onglets, formulaires, dialogues de fichiers et orchestration des tâches.
- `run_esonde_gui.py` : lanceur depuis l'arborescence extraite sans installation du package.
- `run_esonde_gui.sh` et `run_esonde_gui.bat` : lanceurs Linux/macOS et Windows.
- `queue.Queue` et `threading.Thread` : transport des résultats/erreurs depuis le thread de travail vers le thread UI.
- `ProbeModel`, `load_documents` et sérialisation runtime : mêmes fonctions que la CLI.

Quatre onglets couvrent entraînement/mise à jour, génération, évaluation/récupération, inspection/audit. Le panneau journal restitue les sorties JSON, les erreurs et le statut de la tâche.

## 3. Pipeline complet

1. Le formulaire valide localement les champs obligatoires et les limites simples.
2. L'action capture les chemins et paramètres depuis le thread UI.
3. Un thread de travail charge les corpus ou l'état JSON, vérifie l'intégrité du modèle et appelle le runtime `ProbeModel`.
4. Entraînement, update et calibration enregistrent JSON + sidecar SHA-256 via l'écriture atomique du runtime.
5. Le thread de travail pousse un objet succès/erreur dans une file thread-safe.
6. La boucle Tk récupère le message et met à jour le journal, le statut et le chemin du modèle courant.
7. Pendant une tâche, les boutons d'action sont désactivés pour éviter les actions concurrentes.

## 4. Commandes d'exécution

```bash
python -m compileall -q src/esonde tests run_esonde_gui.py scripts/gui_launch_smoke.py
xvfb-run -a env PYTHONPATH=src python scripts/gui_launch_smoke.py
xvfb-run -a env PYTHONPATH=src python -m unittest discover -s tests -p 'test_gui_p4.py' -v
python run_esonde.py audit --model models/esonde_v2_demo_checkpoint.json --output results/p4_runtime_audit.json
```

Les sorties exactes sont persistées dans `logs/p4_gui_compileall.log`, `logs/p4_gui_launch_smoke.log`, `logs/p4_gui_tests_attempt2.log` et `logs/p4_runtime_audit.*`.

## 5. Résultats

- Compilation Python : code retour 0.
- Démarrage GUI sous Xvfb : PASS, 4 onglets et 10 boutons d'action détectés.
- Tests GUI : **3/3 PASS** en 12,167 secondes.
- Couverture workflow : entraînement, génération, score, récupération, inspection SEM, audit, mise à jour, calibration COORD.
- Gestion des entrées invalides : une erreur de formulaire est affichée dans le journal et ne démarre pas de tâche.
- Asynchronisme : un job de test exécuté sur thread séparé restitue le résultat dans le thread UI ; les tests pilotent la boucle Tk pendant l'attente.
- Audit runtime : **PASS**, 20 fichiers Python scannés, zéro finding.
- Guides : `README.md`, `docs/GUI_GUIDE.md`, `docs/CLI_GUIDE.md` et `docs/GUIDE_UTILISATION_CLI_GUI.md` créés/mis à jour.

## 6. Interprétation des résultats

Les éléments démontrent que la fenêtre démarre sous un serveur d'affichage, que les actions graphiques principales pilotent le runtime et que les tâches lentes ne sont pas exécutées directement dans le callback UI. Les erreurs de saisie restent visibles. La GUI passe par le même chemin de chargement et de vérification des checkpoints que la CLI.

Le test ne démontre pas une compatibilité universelle de toutes les distributions Tkinter, toutes résolutions ou tous systèmes. Tkinter/Tcl-Tk doit être présent dans la distribution Python locale. Les tests GUI utilisent Xvfb ; aucun résultat de qualité linguistique n'est déduit de cette phase.

## 7. Conséquences

### Théoriques

Aucune modification du formalisme ou du modèle de sondes. P4 ajoute seulement une interface de présentation/commande au-dessus du runtime défini précédemment.

### Conceptuelles

Les opérations d'utilisation demeurent identiques entre CLI et GUI. La GUI ne précharge pas de réponse, ne corrige pas la génération et ne guide pas artificiellement le modèle vers une cible attendue.

### Opérationnelles

L'utilisateur peut entraîner, mettre à jour, calibrer, générer, scorer, récupérer, inspecter et auditer depuis une fenêtre locale. Les tâches longues sont asynchrones et les erreurs sont visibles. Les scripts de lancement et guides sont fournis.

## 8. Conclusions

Les critères de sortie P4 sont satisfaits sur l'environnement testé. Tous les workflows graphiques spécifiés ont une action implémentée ; les tests automatiques couvrent le parcours central et le traitement asynchrone. Les contraintes de disponibilité de Tkinter et du serveur graphique sont documentées.

## 9. Statut du modèle

**eSonde v2 — GUI : PASS sur environnement Tkinter 8.6 + Xvfb.**  
**Runtime pur-sonde : audit statique PASS (20 fichiers).**  
**Qualité linguistique générale : non jugée par P4 ; réservée à P5.**  
**Phase suivante autorisée : P5_VALIDATION**, après snapshot P4 et nouveau prévol.
