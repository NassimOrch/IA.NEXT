# Guide CLI — eSonde v0.2.0 / eSond_v2

## 1. Prérequis et lancement

Le moteur d'exécution utilise uniquement la bibliothèque standard de Python 3.10 ou plus récent. `jsonschema` n'est pas nécessaire pour l'inférence, l'entraînement ou le chargement. La compilation et les outils de développement peuvent utiliser des outils supplémentaires, mais ils ne sont pas importés par le moteur.

Deux modes sont fournis :

```bash
# Exécution depuis l'archive extraite, sans installation
python run_esonde.py --help

# Ou avec le package source
PYTHONPATH=src python -m esonde --help

# Installation facultative avec setuptools/pip
python -m pip install .
esonde --help
```

Le premier mode (`run_esonde.py`) ne nécessite pas l'installation du package ni un accès réseau. L'installation par `pip` est facultative et dépend du mécanisme de construction Python présent sur la machine.

## 2. Formats et corpus

Les entrées sont des fichiers UTF-8 ou UTF-8 avec BOM. Les suffixes reconnus lors de l'énumération d'un dossier sont `.txt`, `.text`, `.md`, `.rst`, `.csv`, `.tsv` et `.jsonl`. Un fichier fourni explicitement est lu comme texte UTF-8, quel que soit son suffixe. Un dossier est parcouru récursivement et les fichiers sont triés par chemin. Les fichiers vides sont ignorés. Les chemins et empreintes SHA-256 entrent dans le manifeste du modèle.

La séparation est faite au niveau document. Ne placez pas une même source ou une copie exacte dans train, validation et test. Le runtime rejette les recouvrements d'identifiants ou d'empreintes SHA-256, y compris lorsque le même contenu est renommé.

## 3. Entraîner un modèle

```bash
python run_esonde.py train \
  --corpus ./corpus/train \
  --validation ./corpus/validation \
  --config ./config.json \
  --output ./models/model.json
```

`--validation` est optionnel ; lorsqu'il est absent, COORD reste `NOT_CALIBRATED`. La validation n'est pas ajoutée aux compteurs des sondes. Les paramètres autorisés sont contrôlés, les clés inconnues et valeurs invalides sont rejetées. Exemple de configuration :

```json
{
  "max_context": 512,
  "seq_max_order": 5,
  "seq_decay": 0.65,
  "skip_patterns": [[1, 2], [1, 3], [1, 5], [1, 8], [1, 13], [2, 5], [2, 8]],
  "morph_recent_words": 3,
  "sem_window": 64,
  "disc_window": 512,
  "disc_recent_cutoff": 16,
  "retrieval_context_window": 32,
  "retrieval_budget": 50000,
  "retrieval_top_k": 8,
  "coordinator_smoothing": 0.12,
  "calibration_sample_limit": 1200
}
```

Le paramètre `max_context` accepte `0` pour désactiver le plafond global de contexte ; les fenêtres SEQ/SKIP_REL/MORPH/SEM/DISC/RETR restent gouvernées par leurs paramètres dédiés et leur portée effective figure dans l’état. La valeur par défaut `512` limite le contexte global supplémentaire. En mode borné, `predict_next` expose `TRUNCATED_CONTEXT` et `context_scope` (éléments fournis, retenus, écartés) ; `score` renvoie un bloc `context_window` avec le nombre de cibles tronquées et d'éléments écartés. Le rapport de formation expose les événements de troncature observés. Le résultat de commande donne aussi le nombre de documents/tokens, les supports de chaque famille, le statut de calibration et les empreintes d'intégrité. Le fichier modèle est un JSON inspectable avec sidecar `.sha256` ; il n'utilise pas `pickle`.

## 4. Ajouter un lot

```bash
python run_esonde.py update \
  --model ./models/model.json \
  --corpus ./corpus/new_batch \
  --batch-id batch_2026_11_09
```

La commande refuse les identifiants et contenus déjà présents. COORD passe à `STALE` si un modèle calibré est mis à jour. Les nouveaux checkpoints conservent les textes UTF-8 de chaque lot pour permettre un retrait exact et une reconstruction déterministe ; protégez donc le JSON du modèle comme un fichier pouvant contenir votre corpus. Fournissez `--validation ./corpus/validation_v2` pour recalibrer après le nouvel apport :

```bash
python run_esonde.py update --model ./models/model.json \
  --corpus ./corpus/new_batch --batch-id batch_2026_11_09 \
  --validation ./corpus/validation_v2
```

Vous pouvez également utiliser `calibrate --model ... --validation ...` séparément. La calibration remplace le manifeste de validation précédent, mais ne modifie pas les tables des sondes. L'écriture utilise un remplacement atomique du JSON, avec un sidecar de checksum.

## 5. Calibrer COORD indépendamment

```bash
python run_esonde.py calibrate --model ./models/model.json \
  --validation ./corpus/validation_v2
```

La commande vérifie l'absence de recouvrement ID/SHA-256 entre validation et documents entraînés, puis ajuste uniquement les coefficients de coordination. Elle ne modifie pas les sondes SEQ/SKIP_REL/MORPH/SEM/DISC/RETR.


### Retirer exactement un lot

```bash
python run_esonde.py remove-batch --model ./models/model.json \
  --batch-id batch_2026_11_09
```

Le runtime reconstruit un nouvel état en rejouant tous les lots conservés, validation comprise. Cette opération reconstruit aussi les tables SEM/DISC et le réservoir RETR ; elle ne tente pas de décrémenter des compteurs ou des entrées de réservoir perdus. Elle refuse les checkpoints historiques sans registre complet des textes d'entraînement. Le fichier existant n'est remplacé qu'après réussite et sauvegarde atomique.

## 6. Générer une continuation

```bash
python run_esonde.py generate --model ./models/model.json \
  --prompt "The atmosphere" --max-tokens 32 --strategy greedy

python run_esonde.py generate --model ./models/model.json \
  --prompt-file ./prompt.txt --max-tokens 48 \
  --strategy sample --seed 123 --top-k 20

# N'afficher que le texte final (sans trace JSON)
python run_esonde.py generate --model ./models/model.json \
  --prompt "Un modèle" --max-tokens 16 --plain
```

La stratégie `greedy` est déterministe. `sample` est reproductible pour une graine identique. `top-k` restreint les candidats de décodage ; il ne modifie pas l'état du modèle. La génération continue à partir du vocabulaire de sortie acquis lors de l'entraînement ; la conservation d'une entrée OOV n'est pas une revendication de génération ouverte de tokens inconnus.

## 7. Évaluer sans réentraîner

```bash
python run_esonde.py score --model ./models/model.json \
  --corpus ./corpus/test --top-k 5 --output ./reports/score.json
```

`score` est read-only et renvoie le nombre de tokens, log-loss, perplexité, exactitude top-1/top-k et métriques par document. `NOT_MEASURED` est distinct d'un score nul. L'évaluation refuse une fuite d'ID ou de SHA-256 avec train/validation.

## 8. Récupération et inspection

```bash
python run_esonde.py retrieve --model ./models/model.json \
  --query "energy climate" --top-k 5

python run_esonde.py inspect --model ./models/model.json --family SEM
python run_esonde.py inspect --model ./models/model.json --family COORD
python run_esonde.py inspect --model ./models/model.json --family SEQ --key '["The","cat"]'
```

Les résultats RETR portent le document source, sa position, l'offset du token cible, le score de recouvrement et le statut de correspondance exacte du contexte ordonné. Les clés d'inspection doivent correspondre exactement à leur représentation JSON sérialisée.

## 9. Relations composées et candidats de coréférence

```bash
python run_esonde.py relations --model ./models/model.json \
  --left "cats" --relation "eat" --top-k 20
python run_esonde.py coref --model ./models/model.json \
  --text "Alice returned to the city."
```

`relations` expose les segments A–relation–B induits depuis des clauses observées ; le suffixe A–relation sert aussi à proposer le premier token de B dans la réponse SEM. Il s'agit de candidats issus des partitions de 1–2 tokens pour A, 1–3 tokens pour la relation et 1–2 tokens pour B, non d'une analyse syntaxique certifiée. `coref` expose des candidats de rapprochement entre mentions de surface (1–4 tokens à initiale majuscule) et alias observés, avec support et provenance ; la sortie indique `resolved=false` et ne prétend pas effectuer une résolution pronominale complète.

## 10. Audit, état et démonstration

```bash
python run_esonde.py audit --model ./models/model.json --output ./reports/audit.json
python run_esonde.py info --model ./models/model.json
python run_esonde.py demo --output ./models/demo_model.json
```

`audit` exécute l'audit AST des imports/constructions neuronales et produit les diagnostics d'état. `info` expose version Python, architecture et résumé du modèle. `demo` entraîne un petit modèle sur les textes neutres fournis sous `examples/demo_train` et utilise `examples/demo_validation` pour calibrer COORD. Ce corpus de démonstration sert aux tests d'usage ; il ne s'agit pas d'un corpus de pré-entraînement, d'un jeu de données benchmark, ni d'une garantie de qualité.

## 11. Codes de sortie et résolution des erreurs

- `0` : commande terminée ; le résultat affiché est celui effectivement observé.
- `2` : argument, chemin, encodage, configuration, état ou entrée invalide ; le message est sur stderr.
- `3` : audit pureté signalant une violation statique.

Les exceptions ne sont pas converties en résultat positif. En cas d'erreur d'intégrité, ne supprimez pas le sidecar et ne modifiez pas manuellement le JSON : restaurez le snapshot vérifié ou entraînez une nouvelle version, puis comparez les empreintes.

## 12. Répétabilité et sauvegarde

Avant une exécution de formation ou de mise à jour, conservez une copie du corpus/configuration et du modèle courant. En contexte de développement du projet, exécutez le script de prévol `python scripts/preflight.py --phase P6` (ou la phase active inscrite dans la checklist) et vérifiez `chemins_eSond_v2.json` ainsi que `sav_eSond_v2/SAVEPOINT_MANIFEST.json`. Ces fichiers de suivi ne sont pas requis par un utilisateur final qui extrait seulement le package runtime. Consignez commande, stdout, stderr, code retour, résultat JSON et SHA-256. Les tests et résultats de ce projet utilisent des corpus séparés de l'archive des sources historiques.
