# Journal des incidents P6

Mis à jour : 2026-11-09T11:57:07+01:00

| ID | Incident constaté | Conséquence | Résolution / statut |
|---|---|---|---|
| P6-TEX-COMPILE-001 | LaTeX a rejeté un underscore non échappé dans `max_context` sur la version P6 courante. | La première tentative n'a pas produit de PDF valide. Ses trois traces `formalism_pass9.stdout.log`, `formalism_pass9.log` et `formalism_pass9.exitcode` ont ensuite été écrasées par une relance réussie ; les octets initiaux et leurs SHA-256 ne sont plus disponibles. | Source corrigée ; compilations post-correction réussies ; perte de traçabilité consignée dans `docs/incidents/P6_TEX_LOG_OVERWRITE_ATTESTATION.pdf`, signée par Ed25519 auto-généré. |
| P6-FULL-SUITE-TIMEOUT-001 | Une tentative sous Xvfb a expiré à 90 s sans code retour capturé. | Résultat de cette tentative incomplet, sans preuve de perte d'artefact. | Test GUI isolé et suite complète relancés ; 33/33 PASS après ajout du diagnostic de troncature. |
| P6-GUI-HEADLESS-001 | Le test Tk ne peut pas ouvrir la fenêtre dans une session sans serveur d'affichage. | Incident d'environnement, pas finding du runtime. | GUI exécutée sous Xvfb, 3/3 PASS. |
| P6-TEST-LOG-CAPTURE-001 | Première commande instrumentée redirigeait stdout du test et stdout de `time` vers le même chemin. | Le transcript initial a été capturé dans le fichier time ; le stdout dédié était vide. | Transcript vérifié/récupéré puis nouvelle exécution propre avec logs séparés ; code retour 0. |
| P6-TEST-IMPORT-001 | Première commande ciblée a nécessité `PYTHONPATH=src` pour résoudre le paquet source. | Erreur de lancement, aucun état modèle modifié. | Environnement de test documenté et commande relancée avec `PYTHONPATH=src`. |

**Perte constatée :** trois fichiers de journal de la première compilation LaTeX P6 ont été écrasés lors d'une relance vers les mêmes chemins. L'incident ne concerne pas des poids, checkpoints, corpus ou sources. Les octets originaux ne sont pas restaurables et aucune empreinte historique n'est inventée. Une attestation PDF spécifique, sa clé publique, sa signature détachée et un vérificateur sont conservés sous `docs/incidents/`. La signature auto-générée certifie uniquement l'intégrité du PDF, pas une identité juridique ni un horodatage tiers. Aucun constat de vol ou de corruption des poids n'est émis.


Incident distinct : `P6-TEX-LOG-OVERWRITE-001` — les fichiers journaux initiaux `formalism_pass9.*` ont été remplacés par les sorties de relance. Voir l’attestation PDF signée et le fichier de vérification cryptographique dans `docs/incidents/`.
