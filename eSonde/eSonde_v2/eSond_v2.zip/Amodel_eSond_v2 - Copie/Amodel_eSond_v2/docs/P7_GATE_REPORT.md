# Rapport final P7 — assemblage, intégrité et livraison eSond v2

**Date :** 9 novembre 2026 (Africa/Algiers)  
**Phase :** P7 — Release et intégrité  
**Runtime :** eSonde 0.2.0 / eSond_v2  
**Statut de phase :** `PASS_WITH_DOCUMENTED_ENVIRONMENT_REQUIREMENTS` après vérification finale des trois distributions  
**Référence des empreintes externes :** `P7_FINAL_RELEASE_MANIFEST.json` et fichiers `.sha256` / `.parts.sha256` fournis à côté des ZIP.

## 1. Description

P7 assemble trois distributions distinctes et vérifiables : le runtime (Dmodel), l'audit (Amodel) et le suivi projet (suivi). Les deux archives sources utilisateur et leurs extractions brutes restent exclues des trois distributions. Les manifestes d'inventaire, rapports et empreintes dérivés de l'audit des sources sont conservés dans Amodel.

La sauvegarde `sav_eSond_v2` est distribuée intégralement dans le paquet de suivi, y compris ses snapshots historiques et le snapshot terminal P7. Elle contient les versions successives du workspace et doit être traitée comme une sauvegarde sensible, car certains checkpoints retiennent des textes UTF-8 des corpus employés pour permettre le retrait exact de lots.

## 2. Architecture de livraison

### Dmodel_eSond_v2

Contient les sources du runtime, les familles SEQ, SKIP_REL, MORPH, SEM, DISC, RETR et le coordonnateur COORD, le CLI, la GUI Tkinter, les lanceurs Windows/Linux/macOS, les schémas, le formalisme LaTeX, les exemples, les guides et les tests. Les checkpoints issus des expériences sont conservés avec leurs sidecars SHA-256. Les checkpoints historiques sans ledger de lots complet ne revendiquent pas la suppression exacte.

### Amodel_eSond_v2

Contient l'analyse P0 des sources et expériences, les inventaires et manifestes d'empreintes, les rapports P0–P7, les résultats P5/P6, les journaux, les scripts d'audit, les tests, les spécifications, le formalisme et les attestations signées d'incident. Les extractions brutes d'expériences et les ZIP originaux sont exclus.

### suivi_model_eSond_v2

Contient les checklists de travail et d'erreurs, les chemins canoniques, le ledger `preuves_eSond_v2.json`, l'historique des exécutions, les incidents et attestations, ainsi que le dossier complet `sav_eSond_v2` et son manifeste. Le suivi est livré en deux ZIP indépendants, chacun inférieur à 200 MiB. Ils contiennent la même racine `suivi_model_eSond_v2/` et doivent être extraits dans le même dossier. Les scripts `scripts/reassemble_suivi_model_eSond_v2.sh` (Linux/macOS) et `.bat` (Windows) effectuent l'extraction commune puis vérifient chaque fichier via `PACKAGE_SHA256SUMS.txt`.

## 3. Pipeline complet

1. Relecture de `chemins_eSond_v2.json`, des checklists de travail/erreurs et de `sav_eSond_v2/SAVEPOINT_MANIFEST.json`.
2. Vérification du snapshot terminal et de ses SHA-256.
3. Vérification du runtime : `dependencies=[]`, bibliothèque standard Python uniquement, CPython 3.10+ et Tkinter pour l'interface graphique.
4. Assemblage dans trois répertoires de staging séparés ; exclusion des ZIP sources, des dossiers d'extraction et des caches Python.
5. Génération de manifestes internes SHA-256 et métadonnées `PACKAGE_INFO.json`.
6. Création de deux ZIP indépendants pour le suivi, répartis par snapshots complets et limités chacun à moins de 200 MiB.
7. Test CRC, extraction dans un répertoire propre, recalcul des SHA-256 de chaque membre et contrôle des chemins source interdits.
8. Depuis l'extraction Dmodel : `--help`, `info`, compilation et quatre groupes de tests indépendants cœur/CLI/P6/GUI.
9. Constitution du manifeste final externe qui regroupe tailles, comptes, SHA-256, résultats CRC et nombres de volumes des trois livrables.

## 4. Commandes d'exécution

Depuis le dossier Dmodel extrait :

```bash
python run_esonde.py --help
python run_esonde.py info --model models/esonde_v2_p6_demo_checkpoint.json
python -m compileall -q src/esonde tests
PYTHONPATH=src python -m unittest discover -s tests -p 'test_core_p2.py' -v
PYTHONPATH=src python -m unittest discover -s tests -p 'test_cli_p3.py' -v
PYTHONPATH=src python -m unittest discover -s tests -p 'test_p6_advanced.py' -v
xvfb-run -a env PYTHONPATH=src python -m unittest discover -s tests -p 'test_gui_p4.py' -v
```

Réunir les volumes de suivi :

```bash
sh scripts/reassemble_suivi_model_eSond_v2.sh
```

Le script extrait les deux ZIP dans la même arborescence puis contrôle SHA-256 et tailles de tous les fichiers via `verify_suivi_package.py`.

## 5. Résultats

| Contrôle | Résultat constaté |
|---|---:|
| Dmodel : membres couverts par SHA interne | 81 dans l'archive finale ; extraction et validation membre par membre PASS |
| Amodel : membres couverts par SHA interne | 412 dans l'archive finale ; extraction et validation membre par membre PASS |
| Dmodel — cœur | 14/14 PASS |
| Dmodel — CLI | 6/6 PASS |
| Dmodel — fonctionnalités avancées P6 | 10/10 PASS |
| Dmodel — GUI sous Xvfb | 3/3 PASS |
| Total des groupes indépendants depuis l'extraction Dmodel | **33/33 PASS** |
| `compileall` depuis Dmodel extrait | PASS |
| `--help` et `info` depuis Dmodel extrait | PASS |
| Checkpoints, schémas et sidecars inclus | SHA-256 et chargement vérifiés |
| Archives sources utilisateur dans les trois packages | 0 chemin source trouvé |
| ZIP de suivi indépendants | 2, chacun sous 200 MiB |

Les journaux de tests indépendants sont inclus dans Amodel sous `logs/p7_dmodel_*`. Le groupe GUI a été exécuté seul depuis le dossier Dmodel extrait et a retourné trois tests `OK`. Une tentative groupée antérieure a dépassé le délai du wrapper ; cet incident d'orchestration est conservé dans les journaux et n'est pas masqué. Les sorties internes de tests et leurs codes de retour sont la preuve retenue pour chaque groupe.

Le paquet de suivi contient 46 snapshots jusqu'au snapshot terminal S44 ; le nombre de fichiers, les octets non compressés et les empreintes des membres sont consignés dans ses métadonnées internes et dans le manifeste de release externe.

## 6. Interprétation des résultats

Les contrôles établissent la lisibilité des archives, l'intégrité de leurs membres couverts par SHA-256, le respect de la séparation Dmodel/Amodel/suivi et la réussite des workflows logiciels testés depuis l'extraction Dmodel. Les tests de packaging ne démontrent pas la qualité linguistique générale ni une supériorité sur les TinyLLM/LLM.

Le runtime ne déclare aucune dépendance Python tierce ; cela ne signifie pas que Python lui-même est embarqué. CPython 3.10+ est nécessaire, et Tkinter/Tcl-Tk doit être présent pour lancer la GUI. Une application véritablement autonome sans interpréteur installé devrait être empaquetée et testée séparément pour chaque système et architecture.

L'audit initial a indexé 37 056 occurrences de membres ZIP et 22 792 fichiers texte/code/configuration. Le parsing structurel global a expiré deux fois. La revue sémantique couvre les sources primaires, rapports, formalismes, expériences et scripts retenus, mais ne prétend pas à une lecture humaine exhaustive de chaque cellule binaire ou de chaque ligne des 37 056 membres. Les réserves sont enregistrées dans le rapport P0 et les checklists.

## 7. Conséquences

### Théoriques

La release ne modifie pas l'architecture mathématique ; elle distribue le runtime, les poids réellement créés, les spécifications et les preuves qui ont été vérifiées.

### Conceptuelles

Les trois paquets séparent exécution, audit et suivi. La sauvegarde intégrale conserve l'historique des modifications et rend les états de modèle traçables. Cette séparation évite de confondre les sources utilisateur avec les artefacts produits.

### Opérationnelles

Le runtime ne nécessite pas de paquet pip tiers, mais demande CPython 3.10+ ; Tkinter est requis pour GUI. Les deux ZIP indépendants de suivi doivent être extraits dans le même répertoire de destination. Les checkpoints P6 conservent le texte utilisé pour reconstruction exacte des lots ; leur partage est soumis aux droits et obligations de confidentialité du corpus. Retirer un lot crée un nouvel état reconstruit mais n'efface pas les copies et snapshots antérieurs.

## 8. Conclusions

Les trois distributions sont construites séparément, contrôlées CRC, extraites et vérifiées par manifestes SHA-256. Dmodel passe 33/33 tests indépendants dans l'environnement vérifié. Les sources utilisateur originales ne sont pas intégrées. Les tailles, empreintes et volumes sont fournis dans le manifeste final externe et dans les sidecars des archives.

## 9. Statut du modèle

eSonde v2 est un prototype expérimental de langage pure-sonde, utilisable pour les workflows CLI/GUI validés. La qualité linguistique généraliste, la génération open-vocabulary, un parseur syntaxique certifié, la résolution pronominale, une sémantique typée complète et l'équivalence à un TinyLLM/LLM ne sont pas démontrées par les expériences présentes. Aucune prédiction a priori concernant son potentiel futur n'est formulée.

## Annexes et preuves

- `preuves_eSond_v2.json`
- `execution_history_eSond_v2.json`
- `checklist_de_travail_eSond_v2.json`
- `checklist_erreurs_no_model.json`
- `checklist_erreurs_model.json`
- `chemins_eSond_v2.json`
- `sav_eSond_v2/SAVEPOINT_MANIFEST.json`
- `P7_RELEASE_VERIFICATION.json`
- `source_audit/source_members_manifest.jsonl`
- `P7_FINAL_RELEASE_MANIFEST.json` (fichier externe à côté des ZIP)

### Incidents d'orchestration de la phase P7

Les expirations de délai pendant une exécution combinée GUI, la compression maximale du grand paquet de sauvegarde et l'extraction physique complète sont enregistrées dans `docs/incidents/INCIDENT_REGISTER_ATTESTATION_2026-11-09.pdf` et les checklists. Les remédiations sont vérifiables : GUI isolée 3/3, compression rapide en deux ZIP indépendants sous 200 MiB chacun, puis CRC de chaque ZIP et SHA-256 de chaque membre après lecture directe. Le registre actualisé recense 22 incidents opérationnels, 15 avertissements, 3 observations liées au modèle, 4 défauts historiques et 13 risques suivis. Sa signature détachée RSA-3072/SHA-256 est vérifiée par `docs/incidents/verify_incident_register_signature.py`; elle atteste l'intégrité des octets, pas une identité juridique ni un horodatage tiers.
