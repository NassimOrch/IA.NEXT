# Guide complet de l'interface graphique eSonde v2

## 1. Prérequis et lancement

- Python 3.10 ou plus récent.
- Tkinter/Tcl-Tk disponible dans la distribution Python pour la GUI. La CLI n'en dépend pas.
- Aucun paquet Python tiers n'est requis par le moteur ni par l'interface.

Depuis la racine du dossier extrait :

```bash
python run_esonde_gui.py
```

Raccourcis fournis : `run_esonde_gui.sh` sous Linux/macOS et `run_esonde_gui.bat` sous Windows. Sous Windows, l'installation Python doit inclure Tcl/Tk. Sur certaines distributions Linux, Tkinter est livré dans un paquet système séparé (souvent nommé `python3-tk`).

L'interface s'ouvre dans une fenêtre redimensionnable. Le chemin du modèle courant se trouve en haut ; le checkpoint de démonstration livré est sélectionné par défaut.

## 2. Modèle courant et intégrité

Le champ **Modèle courant** accepte un chemin JSON. Le bouton **Parcourir…** ouvre le sélecteur de fichier. Toute opération qui charge un modèle valide le sidecar `.sha256`, le digest du payload et le schéma minimal avant usage. Un modèle modifié manuellement ou dépourvu de sidecar est rejeté.

Quand un entraînement crée un nouveau checkpoint, le champ du modèle courant est automatiquement remplacé par le chemin du nouveau fichier après la réussite effective de la tâche. Le chemin n'est pas changé avant confirmation du thread de travail.

## 3. Onglet « Entraînement / mise à jour »

**Corpus d'entraînement** : dossier ou fichier(s) texte UTF-8. Plusieurs chemins peuvent être séparés par `;`. Le sélecteur ajoute un dossier au champ sans effacer les chemins précédents.

**Corpus validation** : facultatif à l'entraînement ; s'il est fourni, il est utilisé uniquement pour la calibration du coordonnateur COORD et doit être disjoint du corpus d'entraînement.

**Fichier modèle de sortie** : chemin où écrire le checkpoint JSON et le sidecar SHA-256. Le bouton **Entraîner** construit un nouvel état depuis les documents du train. Le bouton **Démo intégrée** entraîne avec les exemples neutres livrés.

Pour ajouter des documents à un état existant, renseigner **Corpus à ajouter** et **Identifiant de lot**, puis cliquer **Mettre à jour le modèle courant**. La mise à jour refuse les identifiants ou empreintes de contenu déjà présents. Après une mise à jour, la calibration peut devenir obsolète. Les checkpoints récents conservent le texte UTF-8 des lots pour pouvoir reconstruire exactement toutes les tables lors du retrait d’un lot ; ils contiennent donc le corpus d’entraînement et doivent être protégés comme tel. Le bouton **Supprimer un lot (reconstruction exacte)** utilise l’identifiant de lot saisi et reconstruit le modèle sans ce lot. Les checkpoints historiques sans registre complet refusent cette opération.

**Recalibrer COORD** utilise le champ Corpus validation pour recalibrer le coordonnateur sans réentraîner les familles de sondes. Les documents de validation ne doivent pas recouvrir le corpus entraîné.

## 4. Onglet « Génération »

Saisir un prompt, choisir le nombre maximum de tokens (1 à 2048) et une stratégie :

- `greedy` : choix déterministe du candidat le mieux classé ;
- `sample` : échantillonnage avec la graine fixe de l'interface (0) pour rendre les appels identiques reproductibles dans les mêmes conditions.

Cliquer **Générer**. La sortie, les tokens et la trace de prédiction sont ajoutés au journal commun. Une génération peut être vide si aucun candidat actif n'est disponible ; la sortie ne doit pas être interprétée comme une garantie de qualité linguistique. Lorsque le plafond global `max_context` écarte une partie du prompt, le journal de prédiction montre le diagnostic `TRUNCATED_CONTEXT` et les nombres fournis/retenus/écartés.

## 5. Onglet « Évaluation / récupération »

**Corpus de test** : sélectionner un dossier/fichier de test indépendant, puis **Évaluer (score)**. La commande renvoie log-loss, perplexité, exactitude top-1/top-k, résultats par document et la portée du contexte (cibles tronquées et nombre d'éléments écartés). L'évaluation est read-only et rejette les fuites par identifiant ou SHA-256.

**Requête de récupération** : saisir une question ou des termes puis cliquer **Récupérer des contextes**. Les résultats RETR incluent les informations d'attribution disponibles : document source, position, offset et score.

## 6. Onglet « Inspection / audit »

Sélectionner l'une des familles `SEQ`, `SKIP_REL`, `MORPH`, `SEM`, `DISC`, `RETR` ou `COORD`. Une clé JSON exacte peut être ajoutée pour sélectionner une entrée précise. Cliquer **Inspecter** pour voir l'état de la famille.

**Audit de pureté / état** exécute l'audit AST statique et expose les diagnostics d'état. **Informations modèle** affiche version, paramètres et métadonnées du checkpoint. La section **Relations composées** recherche des candidats A–relation–B par argument gauche/relation/argument droit (champs vides = filtre non contraint). La section **Candidats de coréférence / alias** classe les mentions de surface observées et conserve leur preuve ; ces candidats ne sont pas une résolution pronominale complète et ne sont jamais marqués comme résolus automatiquement.

## 7. Exécution asynchrone et erreurs

Les tâches d'entraînement, de chargement et d'inférence sont exécutées dans un thread de travail distinct. Le thread GUI ne réalise que l'affichage et la mise à jour du statut via une file de messages. Les boutons d'action sont désactivés pendant une tâche afin d'éviter les mises à jour concurrentes de même état. Les erreurs de validation synchrones et les exceptions du thread sont affichées dans le journal commun ; aucune erreur n'est convertie en réussite.

Fermer la fenêtre termine l'interface. Une opération déjà en cours s'exécute dans un thread daemon ; pour les entraînements longs, attendez l'état « Terminé » et vérifiez le sidecar avant de fermer. Sauvegardez régulièrement les fichiers de modèle hors du dossier temporaire.

## 8. Données et confidentialité

La GUI ne contacte aucun service externe et ne transmet aucun corpus. Les chemins d'origine et empreintes des documents utilisés sont conservés dans le manifeste du modèle. Évitez les corpus contenant des données confidentielles dans les fichiers de démonstration ou les rapports partagés.

## 9. Dépannage

- **Tkinter introuvable** : la CLI reste utilisable ; installez/activez le composant Tcl/Tk de votre distribution Python puis relancez la GUI.
- **Modèle introuvable** : sélectionnez un JSON valide dans le champ Modèle courant.
- **SHA-256 mismatch / sidecar missing** : restaurez le JSON et son sidecar depuis une sauvegarde intègre ; ne recréez pas le sidecar à partir d'un modèle dont l'intégrité est incertaine.
- **Corpus vide ou UTF-8 invalide** : vérifiez le chemin, l'encodage et la présence de fichiers reconnus.
- **Fuite train/validation/test** : créez des splits au niveau source ; renommer un doublon ne rend pas les contenus disjoints.
- **GUI non visible en environnement headless** : lancez les tests sous Xvfb ou utilisez la CLI dans une session sans serveur graphique.
