#!/usr/bin/env python3
"""Verify the detached Ed25519 signature for the P6 incident PDF."""
from pathlib import Path
import base64, hashlib, sys
from cryptography.hazmat.primitives.serialization import load_pem_public_key

root = Path(__file__).resolve().parent
pdf = root / 'P6_TEX_LOG_OVERWRITE_ATTESTATION.pdf'
public_key = root / 'P6_TEX_LOG_OVERWRITE_ATTESTATION.pub.pem'
signature = root / 'P6_TEX_LOG_OVERWRITE_ATTESTATION.sig'
expected = (root / 'P6_TEX_LOG_OVERWRITE_ATTESTATION.pdf.sha256').read_text().split()[0]
raw = pdf.read_bytes()
actual = hashlib.sha256(raw).hexdigest()
if actual != expected:
    raise SystemExit(f'FAIL: SHA-256 mismatch: expected={expected} actual={actual}')
key = load_pem_public_key(public_key.read_bytes())
key.verify(base64.b64decode(signature.read_text()), raw)
print(f'PASS: SHA-256 {actual}; Ed25519 signature valid')
