# Registre d’incidents et attestation de traçabilité

- Projet : eSond_v2
- Généré : 2026-11-09T13:12:03+01:00
- PDF : `INCIDENT_REGISTER_ATTESTATION_2026-11-09.pdf`

## Comptages

- Incidents opérationnels enregistrés : 22
- Avertissements opérationnels suivis : 15
- Observations/écarts liés au modèle : 3
- Défauts historiques du modèle suivis : 4
- Risques techniques suivis : 13

## Perte confirmée
Une perte de traçabilité concerne trois journaux d’une compilation LaTeX P6 initiale, écrasés par une relance. Les octets et empreintes initiaux ne sont pas disponibles. Aucun checkpoint, poids, corpus ou archive source n’est déclaré perdu.

## Sources
- `checklist_erreurs_no_model.json`
- `checklist_erreurs_model.json`
- Journaux et attestations cités dans les champs de preuves.

## Portée de la signature
Le PDF est signé par signature détachée RSA-3072/SHA-256. La vérification prouve uniquement l’intégrité cryptographique des octets signés, pas l’identité juridique du signataire ni un horodatage tiers.
