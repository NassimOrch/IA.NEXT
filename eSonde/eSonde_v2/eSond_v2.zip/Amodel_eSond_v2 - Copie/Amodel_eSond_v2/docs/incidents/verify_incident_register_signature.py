#!/usr/bin/env python3
from pathlib import Path
import subprocess, hashlib, sys
root=Path(__file__).resolve().parent
stem='INCIDENT_REGISTER_ATTESTATION_2026-11-09'
pdf=root/f'{stem}.pdf'; sig=root/f'{stem}.sig'; pub=root/f'{stem}.pub.pem'
sha=hashlib.sha256(pdf.read_bytes()).hexdigest()
expected=(root/f'{stem}.pdf.sha256').read_text().split()[0]
if sha!=expected: raise SystemExit(f'SHA-256 mismatch: {sha} != {expected}')
r=subprocess.run(['openssl','dgst','-sha256','-verify',str(pub),'-signature',str(sig),str(pdf)],capture_output=True,text=True)
if r.returncode: print(r.stdout+r.stderr); raise SystemExit(r.returncode)
print(f'PASS: SHA-256 {sha}; RSA/SHA-256 detached signature valid')
