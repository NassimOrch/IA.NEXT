# Attestation d'incident - écrasement des journaux d'une compilation LaTeX P6

**Référence :** `P6-TEX-LOG-OVERWRITE-001`  
**Projet :** eSonde v2  
**Date de constat et d'établissement :** 9 novembre 2026 (heure locale Africa/Algiers)  
**Statut :** incident de traçabilité confirmé ; données du modèle et sources de référence non concernées selon les contrôles réalisés.

## 1. Description

Lors de la validation du formalisme P6, une compilation LaTeX fraîche a échoué sur un identifiant `max_context` dont le caractère `_` n'était pas échappé dans le texte LaTeX. Le diagnostic disponible dans le transcript d'exécution indiquait `! Missing $ inserted`, à la ligne 71, puis `Fatal error occurred`. La correction a remplacé les identifiants de code par une notation LaTeX échappée (`\\texttt{max\\_context}`), après quoi deux compilations ultérieures ont réussi.

Au moment de la relance réussie, les chemins de sortie utilisés pour la tentative échouée ont été réutilisés. Les fichiers suivants ont donc été remplacés par les sorties de la relance :

- `logs/formalism_pass9.stdout.log` ;
- `logs/formalism_pass9.log` ;
- `logs/formalism_pass9.exitcode`.

Les fichiers actuellement présents à ces chemins correspondent à la compilation réussie, et non à la première compilation échouée. L'original de ces trois traces n'est plus présent dans le workspace.

## 2. Architecture / périmètre de l'incident

L'incident touche la capture de la sortie et du statut d'une commande de compilation documentaire. Il ne touche pas :

- le contenu des archives sources jointes ;
- les fichiers du runtime eSonde ;
- les paramètres ou états du modèle ;
- les corpus d'entraînement, de validation ou de test ;
- les checkpoints P5/P6 ou leurs sidecars, d'après les vérifications d'intégrité consignées.

## 3. Pipeline complet et chronologie

1. Une compilation P6 a été lancée avec `pdflatex -interaction=nonstopmode -halt-on-error` sur `formalism/formalisme_eSond_v2.tex`.
2. La compilation a échoué à la ligne 71, à cause du `_` de `max_context` non échappé.
3. La sortie indiquait `Missing $ inserted`, suivie de `Fatal error occurred`.
4. Le diagnostic et le statut ont été écrits dans les chemins `formalism_pass9.*`.
5. Le source LaTeX a été corrigé.
6. Une compilation réussie a réutilisé les mêmes chemins ; les premières traces ont été écrasées.
7. Deux compilations post-correction ont été contrôlées comme réussies (`formalism_pass9` et `formalism_pass10` selon les journaux actuellement disponibles ; d'autres passes ultérieures sont aussi consignées dans le journal de projet).
8. Le contrôle actuel confirme la présence des journaux de succès, mais ne permet pas de restaurer les octets des journaux initiaux échoués ni leur empreinte SHA-256 antérieure.

## 4. Commandes d'exécution

Commande de compilation utilisée dans cette séquence (le chemin de sortie a été réutilisé lors de la relance) :

```bash
cd /mnt/data/esond_work/esond_v2_project/formalism
pdflatex -interaction=nonstopmode -halt-on-error \
  -jobname=formalism_v2_current \
  -output-directory=../logs \
  formalisme_eSond_v2.tex
```

Les noms exacts de sortie `formalism_pass9.*` ont été utilisés par l'orchestration de la première tentative et de sa relance ; la ligne ci-dessus documente les options du compilateur, mais n'est pas présentée comme une transcription exacte de la commande shell initiale qui avait redirigé stdout.

## 5. Résultats et preuves disponibles

**Résultats établis :**

- L'échec initial est attesté par le transcript d'exécution encore présent dans l'historique de cette conversation : diagnostic `Missing $ inserted`, ligne 71, mention `max_context`, puis `Fatal error occurred`.
- Les fichiers actuellement conservés `logs/formalism_pass9.log`, `logs/formalism_pass9.stdout.log` et `logs/formalism_pass9.exitcode` sont ceux de la relance réussie ; ils ne sont pas des copies des journaux échoués.
- Les journaux post-correction `formalism_pass9` / `formalism_pass10` sont présents et leurs codes de sortie indiquent le succès.
- Le source LaTeX actuel est corrigé et a passé les compilations post-correction enregistrées.

**Éléments qui ne sont pas disponibles :**

- octets exacts du journal LaTeX de la première compilation échouée ;
- stdout complet et code retour original sauvegardés à part ;
- SHA-256 des versions écrasées ;
- empreinte de la version du source antérieure à la correction.

Les diagnostics d'erreur cités ci-dessus sont une reconstruction factuelle à partir du transcript d'exécution visible, et non la restauration du fichier original. Aucune empreinte ancienne n'est inventée.

## 6. Interprétation

Il s'agit d'une perte de traçabilité limitée à trois fichiers de journal liés à une compilation documentaire. Ce n'est pas une preuve de corruption du formalisme courant, du modèle ou des poids. La compilation échouée a été corrigée et les compilations suivantes ont réussi ; cela ne rétablit toutefois pas l'historique binaire qui a été écrasé.

## 7. Conséquences

### Théoriques

Aucune modification des hypothèses ou de l'architecture des sondes n'est impliquée. La correction concerne la syntaxe du formalisme LaTeX.

### Conceptuelles

Les résultats d'une exécution ne doivent pas être assimilés à ceux de la relance. Les journaux actuels de succès ne peuvent pas servir de preuve de l'exécution initialement échouée.

### Opérationnelles

Les journaux d'exécution doivent être immuables et uniques par tentative. Toute relance doit utiliser un nouvel identifiant, un nouveau stdout, un nouveau stderr et un nouveau fichier de code retour. Les étapes de snapshot doivent inclure les journaux avant de réutiliser un nom.

## 8. Conclusions et statut

- **Incident :** confirmé.
- **Données concernées :** journaux d'une tentative LaTeX échouée, trois chemins écrasés.
- **Données du modèle/checkpoints :** aucune perte ou corruption constatée dans les contrôles effectués ; cette attestation ne constitue pas une preuve universelle de l'intégrité de tous les fichiers non concernés.
- **Restauration :** impossible pour les octets initiaux, car aucune copie immuable n'a été identifiée.
- **Prévention :** noms uniques par tentative, conservation stdout/stderr/exitcode distincte, SHA-256 à l'émission, snapshot préalable et interdiction de rediriger une relance vers les chemins d'une tentative antérieure.

## 9. Signature et portée

Le PDF associé est signé par une clé Ed25519 auto-générée pour attester que les octets du PDF n'ont pas changé depuis la signature. La clé publique et la signature détachée sont jointes. Cette signature ne constitue ni une signature électronique qualifiée, ni un certificat d'identité, ni un horodatage qualifié, ni une preuve juridique de l'auteur humain. La clé privée n'est pas livrée.
