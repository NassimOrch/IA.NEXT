# Rapport de clôture P3 — Interface CLI eSonde v2

**Date :** 9 novembre 2026  
**Phase :** P3_CLI  
**Périmètre :** interface en ligne de commande, workflows, erreurs d'entrée, intégrité des états sérialisés.  
**Statut de la phase :** PASS sur les critères CLI ; qualité générale du modèle non évaluée par cette phase.

## 1. Description

P3 valide l'interface CLI fournie avec le runtime eSonde v2. Elle expose les opérations de création et d'évolution d'un état de modèle, de génération, d'évaluation, de récupération, d'inspection, d'audit et de démonstration. La CLI utilise la même classe `ProbeModel` que l'API Python et n'ajoute pas de moteur d'inférence parallèle.

Les entrées de corpus sont des documents texte UTF-8. Les commandes d'entraînement et d'évaluation imposent une séparation document/contenu entre train, validation et test. Le checkpoint est un JSON canonique avec un sidecar SHA-256 et une validation de cohérence à son chargement.

## 2. Architecture

- `src/esonde/cli.py` : définition des sous-commandes et orchestration des appels runtime.
- `src/esonde/corpus.py` : lecture, normalisation et manifeste des corpus.
- `src/esonde/model.py` : entraînement, prédiction, génération, score, récupération et inspection.
- `src/esonde/serialization.py` : écriture atomique, validation de schéma minimal, empreintes du payload et du fichier.
- `src/esonde/audit.py` : audit statique AST de la pureté du runtime.

Sous-commandes livrées : `train`, `update`, `calibrate`, `generate`, `score`, `retrieve`, `inspect`, `audit`, `info`, `demo`.

## 3. Pipeline complet

1. Parser les arguments et valider les options CLI.
2. Lire les fichiers de corpus UTF-8 et construire les documents avec identifiants et empreintes.
3. À l'entraînement, ne construire les tables de sondes qu'à partir de train ; validation sert à la calibration du coordonnateur.
4. Sérialiser l'état de façon canonique, écrire atomiquement le JSON et son sidecar SHA-256.
5. Pour toute commande chargeant un état, vérifier sidecar, empreinte exacte du fichier, digest du payload et schéma minimal.
6. Exécuter la fonction demandée via `ProbeModel`.
7. Émettre un objet JSON (ou le texte seul avec `generate --plain`) et un code de retour stable.
8. Conserver les stdout, stderr, codes de retour, résultats et empreintes dans `results/p3_cli_execution/`.

## 4. Commandes d'exécution

Depuis la racine du projet :

```bash
python run_esonde.py --version
python run_esonde.py --help
python run_esonde.py demo --output results/demo_model.json
python run_esonde.py train --corpus examples/demo_train --validation examples/demo_validation --output results/model.json
python run_esonde.py generate --model results/model.json --prompt "La science" --max-tokens 12 --strategy greedy
python run_esonde.py score --model results/model.json --corpus examples/demo_test --top-k 5
python run_esonde.py retrieve --model results/model.json --query "système vivant énergie" --top-k 3
python run_esonde.py inspect --model results/model.json --family SEM
python run_esonde.py inspect --model results/model.json --family COORD
python run_esonde.py audit --model results/model.json --output results/audit.json
python run_esonde.py info --model results/model.json
python run_esonde.py update --model results/model.json --corpus ./new_batch --batch-id batch-001
python run_esonde.py calibrate --model results/model.json --validation examples/demo_validation
```

Les commandes exécutées avec succès, les fichiers de résultats et leurs codes retour sont dans `results/p3_cli_execution/`. La commande négative de chemin absent est également enregistrée.

## 5. Résultats observés

### Tests automatisés

- `python -m compileall -q src/esonde tests` : code retour 0.
- `PYTHONPATH=src python -m unittest discover -s tests -p 'test_cli_p3.py' -v` : **5/5 tests PASS**, code retour 0.
- Le test de workflow couvre train, generate, score, retrieve, inspect SEM, audit, info, update et calibrate.
- Les tests négatifs couvrent chemin absent, chevauchement train/validation et `top_k` invalide.

### Parcours manuel sur les exemples du projet

| Commande | Résultat | Code retour |
|---|---:|---:|
| `demo` | `DEMO_MODEL_SAVED` | 0 |
| `train` | `TRAINED` | 0 |
| `generate` | `GENERATED` | 0 |
| `score` | `MEASURED` | 0 |
| `retrieve` | JSON avec résultats attribués | 0 |
| `inspect SEM` | famille inspectée | 0 |
| `inspect COORD` | coordonnateur inspecté | 0 |
| `audit` | `PASS`, aucune violation AST trouvée | 0 |
| `info` | métadonnées runtime et état | 0 |
| `update` | `UPDATED` | 0 |
| `calibrate` | `CALIBRATED` | 0 |
| train sur chemin inexistant | erreur visible, aucun modèle créé | 2 (attendu) |

### Mesure exploratoire du petit jeu de test

Le modèle manuel initial a été entraîné sur 8 documents / 415 tokens, vocabulaire de 279 unités, avec 2 documents de validation (80 échantillons de calibration). Le jeu test indépendant contient 2 documents et 72 tokens. Résultats observés : log-loss **17.8370**, perplexité **55 784 831.80**, exactitude top-1 **0.1250** et top-5 **0.2083**.

La génération greedy sur le prompt `La science` a produit `La science............` (12 tokens de ponctuation). Cette sortie est conservée telle quelle dans les logs ; elle n'est ni corrigée ni présentée comme une génération linguistique satisfaisante.

L'audit statique a examiné 19 fichiers Python du runtime et rapporté `PASS` avec zéro finding. L'audit AST est un contrôle statique ciblé, pas une preuve universelle de l'absence de toute construction neuronale dans tous les environnements.

### Intégrité et checkpoint

Les deux checkpoints de parcours ont une empreinte de fichier correspondant au premier champ du sidecar `.sha256`. Le format du sidecar inclut également le nom du fichier ; le premier contrôle ad hoc a initialement comparé le digest à toute la ligne et échoué à tort. La comparaison a été corrigée en extrayant le premier champ puis vérifiée directement avec SHA-256. Aucun fichier modèle n'a été altéré ; les empreintes calculées concordent.

Un checkpoint de démonstration final (après update et calibration) est conservé sous `models/esonde_v2_demo_checkpoint.json` avec sidecar correspondant.

## 6. Interprétation des résultats

La phase démontre que les opérations CLI implémentées peuvent être invoquées de bout en bout, que les sorties et codes d'erreur sont observables, que l'intégrité des états sauvegardés est contrôlée et que les principales règles de séparation des corpus sont exercées par les tests.

Les métriques du minuscule corpus sont des observations exploratoires, pas une estimation fiable de la performance générale. Elles signalent une qualité prédictive faible sur ce test, et une génération répétitive sur le prompt essayé. Ces résultats doivent être conservés comme point de départ pour P5 ; ils ne permettent ni de conclure sur l'architecture complète, ni de préjuger du potentiel du modèle, ni de revendiquer une équivalence à un LLM commercial.

## 7. Conséquences

### Théoriques

Les résultats ne modifient pas le formalisme du modèle. Ils confirment seulement la possibilité d'atteindre les fonctions d'interface requises avec l'API pure-sonde actuelle.

### Conceptuelles

L'interface sépare les opérations d'entraînement, de calibration et de test. La génération et l'évaluation sont exposées sans injection de réponses attendues. La CLI ne contient pas de règles de réponse spécifiques au test.

### Opérationnelles

Les checkpoints disposent de contrôles d'intégrité, les erreurs usuelles renvoient des codes stables, les résultats sont persistés et les options principales sont documentées dans `docs/CLI_GUIDE.md`. Le checkpoint livré est explicitement identifié comme un modèle d'exemple entraîné à partir des seuls exemples fournis.

## 8. Conclusions

Tous les critères de sortie de P3 sont satisfaits : les dix commandes sont documentées, les workflows sont exécutés, les tests CLI passent, les erreurs d'entrée essentielles sont gérées et les preuves sont persistées. Les observations de qualité du corpus minuscule sont consignées sans maquillage et réservées à l'analyse approfondie P5.

## 9. Statut du modèle

**eSonde v2 — CLI : PASS.**  
**Noyau : P2 PASS logiciel.**  
**Qualité sémantique générale : NON ÉTABLIE ; mesures exploratoires faibles consignées.**  
**Phase suivante autorisée : P4_GUI**, sous réserve d'un nouveau prévol, d'une consultation des checklists et d'un snapshot avant modifications/exécutions GUI.
