# Documentation eSonde_v2

- `../formalism/formalisme_eSond_v2.tex` : formalisme mathématique version 2.
- `IMPLEMENTATION_SPEC_V2.md` : architecture et contrats d'implémentation.
- `API_CONTRACT.md` : contrat API/runtime.
- `CLI_GUIDE.md` : guide complet CLI.
- `GUI_GUIDE.md` : guide complet interface graphique.
- `GUIDE_UTILISATION_CLI_GUI.md` : guide combiné de bout en bout.
- `REPORT_TEMPLATE.md` : template commun obligatoire des rapports.
- `PROTOCOL_EXPERIMENTAL_VALIDATION.md` : protocole P5 et réserve chronologique.
- `P3_GATE_REPORT.md`, `P4_GATE_REPORT.md`, `P5_GATE_REPORT.md` : rapports de phase.
- `../results/p5_validation_summary.json` : résumé machine-readable de P5.
