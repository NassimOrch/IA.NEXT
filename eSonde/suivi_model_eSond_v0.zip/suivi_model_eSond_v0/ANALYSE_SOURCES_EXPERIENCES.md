# Audit des sources et expériences — eSonde_v0

**Date de l'audit :** 8 novembre 2026  
**Périmètre :** les deux archives utilisateur fournies, toutes les extractions ZIP imbriquées présentes dans ces archives et les documents d'expérience/référence retrouvés dans ces arbres.  
**Principe :** les observations défavorables ou favorables sont rapportées comme résultats des expériences sources ; elles ne constituent pas une prédiction sur eSonde_v0. Aucune donnée scellée n'a été générée, rescorrée ou utilisée pour ajuster eSonde_v0.

## 1. Description et provenance

Deux archives ont été reçues : `last_sources_3.zip` et `EX12_NEXT_0_DELIVERABLES - Copie.zip`. Les tests CRC des deux archives et des 23 archives imbriquées inventoriées passent. L'extraction récursive et l'index SHA-256 recensent **35 901 fichiers et 2 230 514 939 octets**. Le manifeste est `source_file_manifest.jsonl` et son résumé `source_manifest_summary.json`. La re-vérification finale du 8 novembre 2026 a relu les 35 901 fichiers : 35 901/35 901 tailles et SHA-256 concordants, zéro manque, zéro ajout et zéro différence (`source_integrity_recheck_20261108.json`). Le document index `document_index/text_document_index.{jsonl,csv}` couvre 590 fichiers textuels (442 Markdown, 49 TeX, 1 reStructuredText, 98 TXT) avec taille, chemin, SHA-256, premières lignes et titres/sections détectés.

La validation structurelle rapporte 17 750 JSON analysés, 293 JSONL, 2 894 CSV, 6 020 NPZ, 140 NPY et 23 ZIP. Les NPZ/NPY/CSV ont été lus avec les lecteurs publics/parseurs correspondants sans anomalie structurelle. Une ligne JSONL invalide demeure dans `sources_ng_adapt_0/dataset/batch_dataset.jsonl`, ligne 784 (chaîne tronquée/non terminée) ; elle est conservée telle quelle et n'a pas été réparée. Les PDF sont inventoriés et hashés, mais n'ont pas été priorisés conformément à la consigne. Les 7 133 fichiers `.pt` (481 434 258 octets) sont tous hashés et consignés dans `checkpoint_safe_load_audit.jsonl`. La première passe restreinte `weights_only=True` a décodé 6 557 états et classé 554 comme références globales non admises à ce stade. Les passes complémentaires ont ensuite décodé 347 états avec une liste blanche limitée aux types NumPy standards et 207 avec des classes substituts inertes, toujours sous `weights_only=True`. Bilan final : 7 111 graphes d'état `.pt` décodés ; les 22 autres sont TorchScript, inspectés statiquement mais non chargés/exécutés. Les 8 `.joblib` sont inspectés statiquement sans `joblib.load`; le Parquet est hashé et sa signature `PAR1` contrôlée, mais son contenu n'a pas été lu par colonnes faute de moteur disponible. Aucun `weights_only=False`, `joblib.load` ou `torch.jit.load` n'a été utilisé.

### Couverture réelle de lecture

- Chaque fichier extrait est présent dans le manifeste fichier-par-fichier avec son hash et sa taille.
- Tous les documents textuels ciblés (590) sont indexés par titres/sections et provenance.
- Les textes primaires de théorie, protocoles et rapports finaux EX3–EX12 listés ci-dessous ont été lus et confrontés entre eux.
- Les données tabulaires et conteneurs numériques ont été vérifiés structurellement ; cela n'équivaud pas à lire manuellement chacune des valeurs de chaque tableau.
- État au premier audit : 6 557 `.pt` décodés, 554 globals hors liste blanche, 22 TorchScript statiques ; ce statut historique a été complété. État final : 7 111 graphes d'état décodés sous `weights_only=True` (347 avec allowlist NumPy, 207 avec stubs inertes) ; 22 TorchScript restent statiques uniquement. Les 8 `.joblib` ont des marqueurs/opcodes statiques partiels sans reconstruction d'objet ; le Parquet n'a pas été lu sémantiquement faute de moteur. Les fichiers bruts restent disponibles byte-for-byte.

## 2. Théorie primaire et portée

### 2.1 Sonde adaptative

Source primaire : `etude_et_formalisme_sonde_adaptative_1.tex` (présente dans les copies de référence EX6 et de la branche principale de théorie). Le formalisme traite une sonde adaptative par une classe de réponse, une règle de mise à jour et un état initial. Il insiste sur l'état complet d'apprentissage (paramètres, moments d'optimiseur, compteurs, RNG, buffers et mémoire). Il distingue adaptation de paramètres, adaptation globale partagée et méta-adaptation de la règle elle-même. Il sépare cinq niveaux de revendication : observation, inclusion exacte, approximation, identifiabilité et mécanisme de remplacement.

Conséquence pour la conception : une observation peut être appelée « sonde » au sens descriptif sans que cela prouve qu'un ensemble fini de sondes apprend la fonction, l'identifie hors-échantillon ou remplace tout MLP. Les résultats d'inclusion exacte sont conditionnels à l'appartenance de la fonction cible à la classe expressive. Les observations finies ne distinguent pas deux fonctions qui coïncident sur les échantillons et divergent hors support.

### 2.2 Adaptation globale

Source : `FORMALISME_ADAPTATION_GLOBALE.tex`. Elle formalise sondes indépendantes, réseau/coordination de sondes, adaptation locale et variables globales partagées. Une coordination passive/fixe ne satisfait pas la notion d'adaptation globale ; il faut un état global effectivement mis à jour par la perte commune et affectant plusieurs sondes. Elle traite l'identifiabilité latente, les conditions d'inversion et les erreurs de composition.

Conséquence : eSonde_v0 distingue explicitement préférences et température partagées des paramètres internes de sondes. Elle ne qualifie pas une simple moyenne fixe de « coordination adaptative ».

### 2.3 Théorie des empreintes/observations

Source : `DDD_Base_theorie_des_empreintes_complete_order_5.tex` et famille `NGeGenBrain_observation_formalisme*`. Une application d'observation induit des fibres et une relation d'indiscernabilité ; les sondes supplémentaires raffinent les partitions d'observations. Une fonction factorise par l'empreinte lorsque sa valeur est constante sur les classes d'équivalence concernées. Ces résultats sont utiles pour la représentation et l'identifiabilité conditionnelle, mais ils ne donnent pas automatiquement généralisation, stabilité, efficacité d'apprentissage ou contrôle d'extrapolation.

### 2.4 Formalismes CNG/CNC et tests théoriques

Sources : `th_sondes_core_test_0.tex`, `th_sondes_core_test_1.tex`, `EX7_formalisme_hybride_arch_0.tex`, `EX7_chat_sentheses_0.tex`, `Replica_U_0.tex`. Ces travaux spécifient des sondes groupées (CNG), des sondes d'opération (CNC), des graphes de calcul, de la composition et des variantes hybrides. Certaines réalisations historiques ajoutent toutefois un encodeur affine, une composition linéaire ou une tête de sortie. Un tel montage n'est pas « 100 % sondes » selon la contrainte présente. Les spécifications théoriques ne sont pas confondues avec un code testé.

## 3. Analyse expérience par expérience

Les valeurs ci-dessous sont celles des rapports fournis. Quand les métriques proviennent de validation, elles ne sont pas présentées comme test final. Quand un protocole ou artefact manque, la conclusion est explicitement limitée.

### EX3 — spécification initiale, résultats historiques incomplets

**Description :** le prompt `prompt_ex3.json` définit une comparaison de sondes adaptatives compactes avec MLP apparié, dont un objectif de budget relatif (MLP au moins quatre fois plus grand), séparation train/validation/test et mécanismes de combinaison de type RETRO/MIXA.  
**Architecture :** prototypes locaux/adaptatifs et compositions ; le prompt ne suffit pas à prouver l'implémentation complète de toutes les variantes.  
**Pipeline :** spécification protocolaire présente, mais le workspace EX3 complet, sorties, prédictions et checkpoints sources ne sont pas présents dans les archives reçues.  
**Commandes :** non reproductibles depuis les seuls fichiers transmis.  
**Résultats :** les nombres dans `debrit_0.txt` sont des valeurs historiques rapportées et non vérifiables avec les artefacts présents.  
**Interprétation :** EX3 est une spécification utile de protocole et non une preuve brute reproductible. Ne pas confondre EX3 avec EX2, mentionné dans certains dossiers ultérieurs.  
**Conséquences :** théorique — exigences de budget et de séparation des jeux ; conceptuelle — le comparateur doit être indépendant du cœur ; opérationnelle — récupérer le workspace EX3 original serait nécessaire pour une réplication complète.  
**Conclusion / statut :** PROMPT DISPONIBLE, WORKSPACE ET RÉSULTATS BRUTS ABSENTS ; métriques historiques non certifiées.

### EX4 — premiers essais RBF adaptatifs (Wisconsin)

**Description :** expériences sur Wisconsin Breast Cancer (569 observations, 30 variables), développement partitionné (341 train, 85 validation, 57 adaptation, 86 test dans le protocole historique), normalisation ajustée sur train.  
**Architecture :** RBF adaptatif, centres/largeurs, croissance et coordonnateur ; plusieurs configurations incorporent encodeur linéaire + tanh et lecture linéaire. Ce n'est donc pas un remplacement strictement sans affine.  
**Pipeline :** essais multi-graines et réglages sur validation ; contrôleurs RETRO/MIXA/plateau. Certains contrôleurs atteignent le meilleur checkpoint avant que le mécanisme global ne s'active, donc les métriques retenues ne démontrent pas nécessairement l'effet de l'adaptation globale.  
**Commandes :** les scripts/checkpoints sont présents dans l'arborescence EX4, mais l'expérience n'a pas été réexécutée intégralement dans cet audit.  
**Résultats :** résultats de validation hétérogènes. Exemple rapporté, configuration d2/k4 : accuracy 0,97882 (égale au comparateur MLP indiqué), log-loss 0,07868 contre 0,05552 ; fit 0,358 s contre 0,286 s ; p50 0,07588 ms contre 0,01377 ms. Une configuration d16/k32 rapporte 0,97647 contre 0,98824 d'accuracy et log-loss 0,07710 contre 0,04531.  
**Interprétation :** résultats ponctuels sur un seul domaine de développement, validation réutilisée pour choix et compte-rendu ; pas de validation externe indépendante, pas d'IC pré-enregistrés ni de mesure énergétique.  
**Conséquences :** théorique — les RBF peuvent être étudiés comme réponses locales ; conceptuelle — l'encodeur/tête affine doit être retiré pour satisfaire la contrainte eSonde ; opérationnelle — séparer métriques de sélection et métriques finales.  
**Conclusion / statut :** EXPÉRIENCE DE DÉVELOPPEMENT ; indicateurs mesurés, aucune preuve de généralisation externe.

### EX5 — coordination micro-MIXA, hiérarchie et résidu OOF

**Description :** continue le même domaine Wisconsin et la base de développement EX4 ; 390 associations/confrontations rapportées, variantes de portes adaptatives/fixes et hiérarchies.  
**Architecture :** MicroMIXA, porte adaptative/fixe, partage de porte, hiérarchie à deux niveaux et hybride résiduel OOF. Les expériences comprennent une vérification stricte de gel d'optimiseur.  
**Pipeline :** splits hérités, comparaisons de validation, variantes OOF et contrôles de gel des optimiseurs. Le travail d'EX4/5 est développement corrélé, pas réplication indépendante.  
**Commandes :** ressources et résultats livrés ; non exécutés en totalité durant l'audit source.  
**Résultats :** valeurs du rapport : H_HYBRID accuracy 0,97412 / log-loss 0,05881 ; adaptive_then_fixed 0,98118 / 0,06914 ; le résidu OOF rapporte 0,97647 / 0,05218 contre MLP 0,98588 / 0,05037. Latence p50 indiquée 0,641 ms contre 0,01655 ms, fit ~2,20 s contre ~0,268 s.  
**Interprétation :** certaines variantes améliorent une métrique sans dominer toutes les autres. Les performances sont issues du même univers de développement et la métrique de validation guide les choix. La leçon Adam est importante : `lr=0` ne gèle pas nécessairement moments/compteurs ; un gel strict saute l'étape d'optimiseur et conserve l'état.  
**Conséquences :** théorique — la coordination a une dynamique propre ; conceptuelle — l'OOF résiduel n'est pas un « pur probe » s'il dépend d'une tête linéaire ; opérationnelle — geler paramètres ET état d'optimiseur, apparier les coûts.  
**Conclusion / statut :** DÉVELOPPEMENT APPROFONDI, PAS DE PREUVE DE DOMINATION NI D'EXTERNALISATION.

### EX6 v003 — Emplica, Orchestra, réplication et cascades

**Description :** protocole incomplet centré sur les méthodes OOF, la réplication structurelle et la composition en cascade.  
**Architecture :** Emplica simple/Orchestra OOF, Replica-U et cascades de sondes. Une base de sonde demeure gelée dans certaines configurations, et les pipelines de cascade sont particulièrement coûteux.  
**Pipeline :** 35 comptes de paramètres, 105 prédictions recalculées exactement ; comparaison de validation et mesures de temps.  
**Résultats :** log-loss OOF ponctuellement rapportées 0,03637 / 0,03982 contre MLP 0,04675 / 0,04733, avec IC recouvrant zéro ; fit ~2,18–11,82 s contre 0,21–0,26 s ; latence batch 1 ~1,63–1,87 ms contre ~0,027–0,031 ms (environ 54–70×). Parité d'une représentation répliquée à ~4,77e-7 mais coût supplémentaire.  
**Interprétation :** exactitude de réplication numérique n'est pas performance ; petits écarts de validation avec IC non séparés ; coût important.  
**Conséquences :** théorique — l'équivalence de calcul est distincte de l'expressivité ; conceptuelle — une sonde gelée ne prouve pas l'apprentissage complet d'une architecture ; opérationnelle — rapporter temps de fit et latence.  
**Conclusion / statut :** INCOMPLETE selon le rapport EX6 ; pas de mesure GPU/énergie complète.

### EX7 V002 — Orchestra / Emplica et architectures Matrix

**Description :** étude en développement, y compris folds OOF et variantes récursives.  
**Architecture :** RBF-Lite récursif, Orchestra, Emplica et propositions Matrix, Matrix-Vector et Hybrid. Les trois dernières sont essentiellement des architectures candidates et ne sont pas validées comme modèles complets dans les résultats disponibles.  
**Pipeline :** validation OOF 2-fold/5-fold, budgets de paramètres et comparateurs ; protocole de développement.  
**Résultats :** Orchestra Org rapporte environ 6 800 paramètres, accuracy 97,88 %, log-loss 0,05535 vs MLP apparié ; pipeline OOF ~21,99 s contre 0,40 s. Emplica structural rapporte log-loss 0,03884 vs MLP 0,04675, mais accuracy 0,9835 vs 0,9882 et coût pipeline ~44,4×.  
**Interprétation :** les mesures sont contradictoires suivant la métrique ; le coût est nettement supérieur et le test indépendant n'est pas démontré.  
**Conséquences :** théorique — plusieurs niveaux de composition sont possibles ; conceptuelle — architecture Matrix ne doit pas être déclarée éprouvée ; opérationnelle — ne pas agréger un gain ponctuel en promesse de remplacement.  
**Conclusion / statut :** DÉVELOPPEMENT ; objectif global non atteint selon le rapport EX7 V002.

### EX8 v010 — PCA, récursion, B10/B11 et RETRO

**Description :** variantes A/B testées surtout sur Wisconsin de développement et données SMS historiques.  
**Architecture :** A0 concat/PCA et RBF récursif ; B10/B11 coordinations action-language ; RETRO. Certaines variantes reposent encore sur des transformations qui doivent être auditées pour pureté.  
**Pipeline :** multi-graines et choix validation ; variantes d'action et portes.  
**Résultats :** sur Wisconsin, A0 PCA2 rapporte log-loss 0,0431 vs MLP 0,0543 (3/5 graines, IC recouvrant zéro). Sur SMS, A0 0,10682 vs MLP 0,07268. B10 Wisconsin 0,0414 vs 0,0547 (5/5 faveur rapportée), B11 0,0444 vs 0,0543 ; B10 ~2,85× plus lent que B11. Sur SMS B10 0,1002 et B11 0,10349 vs MLP 0,07413. RETRO n'est fréquemment jamais déclenché ; la récursion demeure moins favorable et plus lente.  
**Interprétation :** transfert de domaine faible ; les avantages Wisconsin ne sont pas transportés au SMS ; résultats dépendants du domaine et de la variante.  
**Conséquences :** théorique — portes variables potentiellement informatives ; conceptuelle — efficacité sur un jeu ne prouve pas robustesse ; opérationnelle — séparer la sélection, conserver tests multi-domaines.  
**Conclusion / statut :** V010 DÉVELOPPEMENT ; résultats mixtes et non généralisables à partir de ces seuls domaines.

### ARCH_UP_TEST_1 — graphes dynamiques d'empreintes

**Description :** test complémentaire d'un graphe dynamique d'empreintes B4 contre B0 et graphes randomisés.  
**Architecture :** B4 dynamique, ablation B0, témoins randomisés préservant certains degrés.  
**Pipeline :** essais par fonction ; le rapport rapporte des écarts de qualité et de coût.  
**Résultats :** avantage B4 sur B0 dans 19/20 comparaisons, mais avantage sur graphe randomisé préservant les degrés rapporté autour de 11/20 ou 12/20 selon le document (divergence conservée). B4 : 1 219 paramètres vs 61 pour B0 (~20×), entraînement ~4,73× plus lent, latence p50 batch 1 ~9,39× et batch 64 ~21,85×.  
**Interprétation :** comparaison B4/B0 confond topologie, capacité et coût ; le contrôle randomisé est beaucoup moins concluant. Le document ne fournit pas une comparaison MLP suffisamment alignée.  
**Conséquences :** théorique — graphes de réponses sont une piste d'expression ; conceptuelle — un effet de topologie doit être distingué d'un effet de capacité ; opérationnelle — contrôler exactement nombre de sondes, paramètres, profondeur et FLOPs/latence.  
**Conclusion / statut :** EXPLORATOIRE ; Matrix/graphes ne sont pas sélectionnés comme cœur v0.

### EX9 v011 — transfert multi-domaines et pilote CNG/CNC

**Description :** tentative de validation des variantes A0/B10/B11 sur deux domaines synthétiques additionnels, plus pilote CNG/CNC.  
**Architecture :** B10/B11/A0, ablations B10, pilotes CNG (3 variantes) et CNC (6 variantes).  
**Pipeline :** domaine synthétique de développement, ablations validation, test XOR8 tenté après gel mais script évaluateur défaillant avant la première prédiction. Ce test est rapporté compromis/consommé et n'a pas été réexécuté.  
**Résultats :** sur les comparaisons confirmatoires multi-domaines reportées, 12/12 deltas log-loss candidat−MLP sont positifs et 0/5 graines favorables ; pertes typiques environ 0,20–0,26 vs MLP environ 0,04–0,12 selon domaine, avec latences B10/B11/A0 autour de 0,2–0,39 ms contre ~0,017 ms. Les pilotes CNG/CNC ne comportent pas de comparateur MLP suffisant ni de graphes de composition CNC confirmatoires.  
**Interprétation :** les gains observés sur Wisconsin EX8 ne se transfèrent pas automatiquement aux domaines testés ; le pilote CNG/CNC reste trop petit et sans comparateur pour conclure sur sa contribution.  
**Conséquences :** théorique — les réponses locales doivent être évaluées hors des distributions d'origine ; conceptuelle — ne pas confondre pilote et validation ; opérationnelle — test XOR8 non réutilisable, données scellées respectées.  
**Conclusion / statut :** RAPPORT FINAL DISPONIBLE, TEST XOR8 NON VALIDE, CNG/CNC PILOTE EXPLORATOIRE.

### EX10 v011 — grande étude CNG/CNC et graphes composés

**Description :** 550 modèles (460 CNG, 90 CNC), 65 ensembles train/validation, 80 jeux frontière, 30 extrapolation d'opérations, 20 extrapolation CNG ; 1 695 holdouts one-shot annoncés. Le prompt d'origine `prompt_ex10.json` manque ; le protocole est reconstitué depuis READMEs, rapports et scripts et est étiqueté comme tel.  
**Architecture :** CNG simple/moyenne/porte apprise (G1/G2/G3, tailles M2/M4/M7) ; CNC spécialistes d'opérations ; graphes de composition C1 (gelé), C2 (fine-tuning conjoint), C3 (MLP), comparateur direct RBF.  
**Pipeline :** les 550 prédictions de validation et 1 695 métriques holdout ont été recalculées par l'expérience ; 3 037/3 037 hashes vérifiés. Cette audit de sources ne relance pas les générateurs et ne rescorr pas les holdouts.  
**Résultats :** CNG varie avec la fonction et le régime : certains cas frontière f2_mul/f3_square_plus montrent un avantage CNG G3/M4, tandis que l'extrapolation correspondante se dégrade (ex. f2 extrapolation ~0,494 contre MLP ~0,455 ; f3 ~1,014 contre ~0,842). Plusieurs fonctions/régimes restent défavorables. Les CNC spécialistes ont des erreurs OOD élevées sur certaines opérations (p. ex. EXP rapporté ~3,672, MUL ~1,99). Dans les graphes, C2 fine-tuné conjointement est nettement meilleur que C1 gelé, mais souvent derrière MLP direct C3 ; exemples G1 test MAE C1 ~0,536, C2 ~0,0822, MLP ~0,0161 ; G2 C1 ~0,493, C2 ~0,0862, MLP ~0,0247 ; G3 C1 ~0,515, C2 ~0,0202, MLP ~0,00963. Les mesures de fit/RSS sont contredites ou non vérifiées pour 180/550 modèles ; 370 sont déclarés sans chevauchement et restent descriptifs.  
**Interprétation :** CNG a des effets spécifiques aux tâches et aux régimes et ne se transpose pas uniformément ; les graphes composés ont besoin de fine-tuning mais ce dernier ne prouve pas la composition zéro-shot.  
**Conséquences :** théorique — interaction et composition de sondes sont plausibles à formaliser ; conceptuelle — spécialisation n'est pas générale ; opérationnelle — chaque opérateur et domaine nécessite holdouts dédiés, profilage fiable.  
**Conclusion / statut :** EXPÉRIENCE LARGE ET HOLDOUT-AUDITÉE, RÉSULTATS MIXTES/CONDITIONNELS ; protocole initial partiellement reconstruit.

### EX11 — snapshot 38/65, réplication et extensions

**Description :** archive étiquetée snapshot 38/65. P0–P2 PASS, P3 incomplet, P4 test scellé non commencé, P5 partiel. Prompt canonical reconstruit v2.3.1 ; pas d'archive source complète de toutes phases.  
**Architecture :** D1/D2 variantes mêmes calculs avec gradient parity ; D3 partage ; Replica-U v003/v004 ; CNG/CNC v001–v004 ; KMeans/LOO, graphes.  
**Pipeline :** contrôles exacts et microbenchmarks, mais pas de validation holdout confirmatoire scellée.  
**Résultats :** D1/D2 parité gradient 40/40 ; speedups microbench rapportés ~1,75–4,0× sans effet d'architecture démontré. D3 réduit le nombre de paramètres, sans preuve de qualité équivalente. Replica-U v003 65/65 ne satisfait pas l'entraînement externe complet ; v004 partiel. CNG v001 comprend 18 essais exploratoires ; KMeans et LOO non exécutés. CNC v004 est mixte ; C2 aide certains graphes, pas d'autres, C4 plus petit mais souvent derrière C3.  
**Interprétation :** la parité algorithmique et microbench ne sont pas preuves de qualité générale ; des phases importantes non faites.  
**Conséquences :** théorique — la réplication est une propriété de calcul conditionnelle ; conceptuelle — réduire des paramètres ne prouve pas la conservation du comportement ; opérationnelle — ne pas ouvrir le test scellé ni annoncer une conclusion qui dépendrait de P4.  
**Conclusion / statut :** PARTIEL 38/65 ; test scellé non commencé dans ce snapshot.

### EX12 NEXT 0 — étude confirmatoire HC-RBF P0–P7

**Description :** package organisé autour de protocoles et d'audits P0–P7, avec `EX12_FINAL_SCIENTIFIC_REPORT.md`, rapports P5/P6/P7, sources, scripts, métriques et données associées.  
**Architecture :** HC-RBF R0/C2/C3/C4 ; C1 global-only ; graphes G1/G2. Le noyau HC-RBF historique emploie `z=tanh(W_e x+b_e)` (encodeur affine), des centres, largeurs positives, activations radiales et readout ; C4 ajoute un résidu affine. C5 (low-rank) et C6 (top-q) sont différés/non implémentés dans ce package. Ces variantes HC-RBF ne sont donc pas une architecture pure-sonde au sens strict demandé ici.  
**Pipeline :** P0–P7 passent leurs portes procédurales/integrité. P3 contient 480 exploratoires (8 tâches × 10 graines indiquées dans le rapport). P7 compare 640 modèles à paramètres entraînables appariés à ±1 % (R0/C2/C3/C4 vs MLP), 4 fonctions × 20 graines × 4 régimes ; 2 560 lignes d'évaluation, 1 075 200 échantillons latence, 1 280 paires, 16 contrastes primaires. L'audit sans rescoring a été reproduit dans ce travail : 25/25 tests et 11/11 contrôles P7, checksums package valides.  
**Résultats :** P7 : moyenne des deltas log-loss candidat−MLP rapportée de −0,00571 en interpolation et −0,03192 en frontière, mais +0,20559 en extrapolation, +0,00298 sous shift. 11/16 contrastes satisfont la non-infériorité avec marge +0,02 ; 7/16 significatifs après Holm. La supériorité est fonction/régime-dépendante ; f1_sin est défavorable en interpolation, certaines variantes f2/f3/f4 bénéficient en frontière. Sur P5, médiane pipeline batch 1 candidate/MLP ~1,825–2,254×, batch 256 ~2,586–3,104×, fit ~1,44–1,62× ; 0/80 paires batch1 ne sont plus rapides selon le rapport. P6 : seuls 7 centres franchissent conjointement deux tests de spécialisation parmi 1 024 examinés. Diabetes P3 : holdout de 67 observations demeure scellé.  
**Interprétation :** résultats confirmatoires substantiels mais mixtes, pas de domination générale ; extrapolation est un point de vigilance quantifié. Les PASS P0–P7 valident le protocole et l'intégrité, pas la supériorité. Le caractère affine du HC-RBF signifie que ses nombres ne peuvent pas être attribués à un cœur eSonde strictement pur.  
**Conséquences :** théorique — réponse radiale locale est un motif exploitable mais la fiabilité hors support doit être mesurée ; conceptuelle — performance prédictive et respect de la pureté sont deux axes distincts ; opérationnelle — ne pas copier l'encodeur affiné, garder paramètres appariés, comparer extrapolation/shift/latence.  
**Conclusion / statut :** SOURCE SCIENTIFIQUE CONFIRMATOIRE ET AUDITÉE ; résultats dépendants du domaine/régime ; holdout Diabetes toujours scellé ; aucun prédicat sur les performances d'eSonde_v0.

## 4. Autres branches de recherche et artefacts de contexte

### NGeGenBrain / formalismes d'observation

Les branches `NGeGenBrain_observation_formalisme*` et les expériences associées élaborent une théorie d'empreintes et des prototypes d'observation. V1 est un laboratoire de test ; v2 utilise un adaptateur simulé et un transformeur synthétique, pas un chargement d'un LLM externe ; v3.1 charge des modèles locaux GGUF de famille Llama et TinyLLM PyTorch mais ne reconstruit pas leurs mécanismes internes. Les scores router rapportés (2/16 validation, 9/32 test final dans le rapport consulté) sont faibles et ne démontrent pas une reconstruction d'architecture. Ces travaux ne sont pas confondus avec les modèles de prédiction tabulaire.

### Replica-U

`Replica_U_0.tex` formalise la duplication/coordination d'unités et les états de réplication. Les rapports EX6/EX11 montrent des résultats de parité ponctuelle et des coûts différents. La duplication exacte de réponses sur un jeu testé ne prouve pas une équivalence hors du jeu ni une réplication autonome de la dynamique d'apprentissage.

### Branches EX4–EX8 historiques et duplications

Plusieurs dossiers incluent des copies de rapports finaux, README par version et archives de continuation. Le manifeste et l'index conservent chaque copie séparément avec son hash. Quand des copies se contredisent, les divergences sont gardées (ex. comptage B4 vs graphe randomisé) et non normalisées silencieusement.

## 5. Matrice de traçabilité et lacunes

| Élément | État de la source | Traitement dans eSonde_v0 |
|---|---|---|
| Sonde adaptative locale | théorie + prototypes | retenue au cœur, sans encodeur/tête affine |
| Couverture / centres globaux | formalismes et variantes | famille distincte, ancre gelée et auditée |
| Interactions pairwise | théorie/CNC pilotes | famille dédiée par paires, sans opérateur symbolique injecté |
| Coordonnateur global | théorie CNG/MIXA | préférences et température partagées apprises |
| Graphes d'empreintes | essais ARCH_UP, formalisme | formalisé comme extension, pas implémenté dans v0 |
| Composition CNC | EX10/11 | extension non intégrée au cœur v0 ; résultats conservés |
| OOF/hybrides résiduels | EX5–EX9 | non copiés s'ils nécessitent tête linéaire/MLP |
| HC-RBF P7 | EX12 | comparateur et contexte, non repris car encodeur affine |
| C5/C6 EX12 | différés | pas déclarés présents |
| EX3 workspace | absent | chiffres historiques non vérifiables |
| EX10 original prompt | absent | protocole reconstitué et étiqueté |
| EX11 prompt canonique | absent/reconstruit | version 2.3.1 documentée comme reconstruction |
| arch_up_test_0.zip | absent | seule version arch_up_test_1 auditée |
| ligne JSONL 784 | invalide | conservée et exclue de toute ingestion automatique |
| checkpoints `.pt` | hash complet, décodage sûr partiel | aucun chargement pickle non sûr |

## 6. Interprétation globale des sources (sans préjuger eSonde_v0)

Les sources n'établissent pas un classement absolu unique entre familles. Les variantes locales RBF, coordinations CNG/CNC, hiérarchies, interactions et graphes donnent des effets qui varient selon la tâche, le domaine, le régime d'extrapolation, la procédure de sélection et le budget de calcul. Les essais de Wisconsin sont historiquement réutilisés plusieurs fois ; ils ne sont pas des réplications indépendantes. EX9 documente un transfert synthétique défavorable à plusieurs variantes. EX10 met en évidence des gains CNG sur certains cas frontière/fonctions, et des erreurs d'extrapolation/composition ailleurs. EX12 apporte le contrôle confirmatoire le plus large, mais concerne HC-RBF avec encodeur affine et montre de grands écarts entre interpolation/frontière et extrapolation.

En conséquence, eSonde_v0 ne reprend pas aveuglément une architecture complète ancienne. Le cœur choisi est une sonde locale adaptative dont la réponse, l'ancre, l'échelle et la conséquence sont directement paramètres de sonde ; les sondes de couverture et d'interaction sont des familles distinctes pour ablation et coordination dans le même pool. Les graphes, opérateurs symboliques et résidus affines ne sont pas maquillé en sondes ; ils sont traités comme extensions distinctes ou exclus du noyau pur tant qu'une définition et un code vérifiables ne les rendent pas sonde-purs.

Cette sélection est une décision d'ingénierie testable, pas une prédiction de succès. Le résultat scientifique de la v0 reste ouvert jusqu'à un plan de comparaison multi-domaines, apparié en paramètres et ressources, avec validation indépendante, graines pré-déclarées, intervalles, tests de shift/extrapolation et holdout intact.

## 7. Sources primaires consultées

- `input_sources/rapport_analyse_ex3_ex10.tex`
- `input_sources/th_sondes_core_test_0.tex`
- `input_sources/th_sondes_core_test_1.tex`
- `input_sources/Replica_U_0.tex`
- `input_sources/last_sources_3/EX7_formalisme_hybride_arch_0.tex`
- `input_sources/last_sources_3/EX7_chat_sentheses_0.tex`
- EX4: `sondes_ex4_workspace_20261030/.../deliverables/rapport_continuite_finale_ex4.md`, `audit_tests_final.md`
- EX5: `sondes_ex5_workspace_20261030/.../deliverables/rapport_reprise_finale_ex5.md`, `rapport_continuite_finale_ex5.md`
- EX6: `sondes_ex6_v003_livrables/.../reports_v3/FINAL_REPORT_EX6_V003.md`
- EX7: `sondes_ex7_prompt_ex7_integral_v005/.../04_REPORTS_AND_AUDITS/FINAL_REPORT_EX7_V002.md`
- EX8: `EX8_v010/RAPPORT_FINAL_V010.md` et rapports imbriqués
- EX9: `EX9_v011_DELIVERABLES/.../reports/REPORT_EX9_FINAL.md`, `MULTI_DOMAIN_SYNTH_DEV_REPORT.md`, `REPORT_CNG_CNC_PILOT.md`
- EX10: `EX10_v011_COMPLETE/.../reports/EX10_FINAL_RESULTS.md`, `EX10_FINAL_INTEGRITY_AUDIT.md`
- EX11: `EX11_DELIVERABLES_SNAPSHOT_38_OF_65.../EX11/reports/EX11_FINAL_REPORT.md`, CNG/CNC/Replica/efficiency reports
- EX12: `EX12_NEXT_0/10_reports/EX12_FINAL_SCIENTIFIC_REPORT.md`, `P5_RESOURCE_REPORT_V3.md`, `P6_FALSIFICATION_REPORT.md`, `P7/P7_CONFIRMATORY_FINAL_REPORT.md`
- ARCH_UP: `arch_up_test_1/README.md` et résultats associés.

Le détail par fichier, la totalité des chemins et checksums est dans les index/manifeste livrés avec l'audit.

### 1.1 Audit des checkpoints et artefacts sérialisés

Le relevé détaillé de tous les `.pt` est `checkpoint_safe_load_audit.jsonl` : 7 133 lignes, toutes avec chemin, taille, empreinte et statut final. Le premier passage avait 6 557 chargements natifs et 554 rejets de globals ; les passes complémentaires ont décodé 347 états avec allowlist NumPy et 207 avec stubs inertes, toujours sous `weights_only=True`. Le bilan est 7 111 états décodés et 22 TorchScript inspectés statiquement sans exécution. Le décodage d'un état n'est pas une validation fonctionnelle de son modèle. Les huit `.joblib` ont été inspectés par marqueurs/opcodes sans désérialisation ; le Parquet demeure signature/hash only faute de moteur.


## Addendum — seconde passe des artefacts sérialisés (2026-11-08)

Les 7 133 fichiers `.pt` (481 434 258 octets) sont tous hashés et consignés dans `checkpoint_safe_load_audit.jsonl`. La première passe `weights_only=True` a décodé 6 557 fichiers et rejeté 554 références globales. Une seconde passe a identifié puis chargé, toujours avec `weights_only=True`, 347 fichiers dont les seules références bloquantes étaient les constructeurs NumPy standards, au moyen d’une liste blanche NumPy explicite. Le bilan corrigé est donc 7 111 états `.pt` décodés sous `weights_only=True` (6 557 dans la première passe, 347 avec liste blanche NumPy, 207 avec classes substituts inertes), sans exécuter les classes originales ; 22 archives TorchScript sont inspectées statiquement mais non désérialisées/exécutées. Aucun `weights_only=False`, `joblib.load` ou `torch.jit.load` n’a été utilisé. Les 8 `.joblib` ont des marqueurs statiques de `TfidfVectorizer`/`StandardScaler`, mais n’ont pas été désérialisés. Le fichier Parquet commence et se termine par `PAR1`; il n’a pas été décodé sémantiquement faute de moteur Parquet présent (installation réseau de `pyarrow` impossible). Ces statuts ne prouvent pas un comportement malveillant ni une corruption.
