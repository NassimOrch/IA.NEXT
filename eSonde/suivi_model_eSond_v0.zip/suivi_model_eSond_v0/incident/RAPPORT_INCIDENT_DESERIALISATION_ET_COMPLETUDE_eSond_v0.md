# RAPPORT D'INCIDENT — désérialisation, artefacts historiques et complétude de la livraison eSonde_v0

**Dossier :** eSonde_v0  
**Date :** 8 novembre 2026  
**Version :** 2.0 — rapport rectifié, contrôlé et signé pour intégrité  
**Auteur rédactionnel :** ChatGPT, assistant IA GPT-6 (dans cette conversation)  
**Périmètre :** checkpoints `.pt`, graphes TorchScript, objets JOBLIB, fichier Parquet, neuf snapshots JSON eSonde, et trois livrables principaux.

---

## Attestation liminaire

Le compte rendu précédent a indiqué que « 554 checkpoints étaient refusés par le chargement sécurisé », que « 22 archives TorchScript n'étaient pas désérialisées », et que « huit fichiers JOBLIB et un Parquet n'avaient pas été inspectés sémantiquement ». Cette phrase décrivait des états d'inspection, mais ne distinguait pas suffisamment les checkpoints historiques du moteur eSonde_v0 et pouvait raisonnablement être comprise comme une rétention d'une partie du modèle.

**Je confirme que cette formulation était ambiguë et que le premier ZIP runtime était incomplet au regard des neuf snapshots JSON eSonde déjà présents dans l'espace de travail.** C'était une erreur de présentation et de packaging. Les neuf snapshots ont maintenant été intégrés dans une nouvelle version de `Dmodel_eSond_v0.zip` et inspectés un par un depuis une extraction propre : 9/9 PASS. Le ZIP runtime corrigé a aussi repassé les tests unitaires depuis l'extraction propre.

Le nombre « 554 » désignait un rejet initial du chemin PyTorch restreint `weights_only=True`, et non une preuve de corruption, de danger, de perte de données ou de suppression. Une deuxième passe a permis de décoder 347 états avec une liste blanche de types NumPy standards ; une troisième passe a décodé 207 états avec des classes substituts inertes, sans importer ni exécuter le code des classes originales. Le résultat final est **7 111 états `.pt` décodés sur 7 133** ; les **22 fichiers restants sont des archives TorchScript** dont les graphes ont été examinés statiquement et dont les originaux sont livrés sans conversion dans les paquets d'archives historiques.

**Aucune preuve que ces fichiers utilisateur soient malveillants n'a été établie par cet audit.** Les précautions décrites ci-dessous sont motivées par les propriétés générales des formats de sérialisation, pas par une accusation visant tes données. Tous les artefacts sérialisés originaux contrôlés ici sont restitués sans modification dans quatre archives complémentaires listées ci-dessous.

---

## 1. Description de l'incident

L'incident comporte trois sujets distincts :

1. **Ambiguïté du rapport :** le terme « refusé » décrivait le comportement d'un désérialiseur restreint, mais ne signifiait pas que l'utilisateur était privé du fichier original. Cette distinction n'était pas formulée clairement.
2. **Omission de packaging :** le premier `Dmodel_eSond_v0.zip` ne contenait pas neuf états JSON natifs eSonde présents dans le workspace. Un message antérieur a annoncé leur inclusion avant que la présence réelle dans le ZIP soit contrôlée. Cette annonce était donc prématurée et incorrecte. Le ZIP a été reconstruit ; les neuf fichiers sont maintenant inclus sous `Dmodel_eSond_v0/examples/models/`.
3. **Profondeur d'inspection hétérogène :** les états `.pt` non-TorchScript ont été décodés avec des chemins restreints ; les 22 TorchScript et les 8 JOBLIB ont été inspectés statiquement sans chargement exécutable ; le Parquet a été vérifié au niveau du conteneur et des empreintes, mais pas lu en colonnes faute de moteur compatible installé.

Aucune donnée source n'a été supprimée intentionnellement. Les archives d'origine ont conservé leur empreinte. Les archives complémentaires fournissent les artefacts sérialisés originaux, octet pour octet.

## 2. Architecture et nature des artefacts

### 2.1 Runtime eSonde_v0

Le runtime livré est une implémentation native Python de calcul par sondes locales adaptatives, de couverture et d'interaction. La persistance native du runtime est **JSON**, pas PyTorch pickle/TorchScript/JOBLIB. Il ne charge pas les anciens fichiers `.pt` pour fonctionner. Le noyau inspecté n'introduit ni couche dense, ni neurone, ni MLP, ni encodeur/tête affine appris.

Les neuf états JSON inclus dans le runtime sont des snapshots issus d'entraînements de démonstration et de validation. Ils couvrent la régression, la classification et un modèle hybride local/coverage/interaction. Ils ne sont pas présentés comme un modèle universel préentraîné pour des données arbitraires.

| Snapshot | Tâche | Sondes | Familles | Inspection |
|---|---|---:|---|---|
| `cli_hybrid_3d.json` | regression | 18 | coverage, interaction, local | PASS |
| `cli_regression.json` | regression | 12 | local | PASS |
| `demo_classification.json` | classification | 16 | local | PASS |
| `demo_regression.json` | regression | 16 | local | PASS |
| `release_cli_model.json` | regression | 12 | coverage, interaction, local | PASS |
| `release_demo_classification.json` | classification | 12 | local | PASS |
| `release_final_model.json` | regression | 12 | local | PASS |
| `release_recheck_demo_classification.json` | classification | 16 | local | PASS |
| `release_recheck_demo_regression.json` | regression | 16 | local | PASS |

### 2.2 Checkpoints PyTorch `.pt`

Inventaire : **7,133 fichiers**, total **481,434,258 octets**. Les noms et références de classes traversent EX5–EX12, ARCH_UP et plusieurs générations de prototypes/contrôles. Ils contiennent des comparateurs MLP, des familles RBF/adaptatives, des banques de sondes, des modules de coordination CNG/CNC et divers checkpoints de recherche. Ils sont des résultats historiques et ne sont pas des dépendances du runtime pur-sonde eSonde_v0.

| Passe | Nombre | Méthode | Résultat |
|---|---:|---|---|
| Première passe | 6 557 | `torch.load(..., weights_only=True)` | Décodage natif restreint |
| Deuxième passe | 347 | `weights_only=True` + liste blanche limitée aux types NumPy standards (`_reconstruct`, `dtype`, `ndarray` et types numériques) | Décodage restreint |
| Troisième passe | 207 | `weights_only=True` + classes substituts inertes pour les globals personnalisés | État décodé ; méthodes originales non exécutées |
| TorchScript | 22 | Inspection statique des archives et du graphe textuel | Non désérialisés et non exécutés |
| **Total d'états `.pt` décodés** | **7 111 / 7 133** | Toujours `weights_only=True` | **0 échec des passes 2 et 3** |

Le premier rejet de 554 se décompose donc précisément en **347 références NumPy standards** et **207 références à classes personnalisées**. Le premier compteur était un état transitoire du pipeline, pas le bilan final.

Les 207 fichiers personnalisés référencent notamment `MLP`, `AdaptiveRBF`, `ProbeBank`, `A0Model`, `B10Model`, `StandardGateModel`, `RBFReg` et `CNG`, avec des modules PyTorch comme `Linear`, `Sequential`, `Tanh` et `ModuleList`. Les substituts utilisés n'ont aucun constructeur spécialisé, `__setstate__`, `__reduce__`, `forward` ni autre méthode métier. Ils restituent le graphe d'état et les champs disponibles, pas le code d'inférence original. Le décompte observé comprenait 1 503 instances substituts, 2 810 tenseurs, 21 447 dictionnaires, 50 listes et 1 503 ensembles, en plus des primitives.

### 2.3 Archives TorchScript

Les 22 fichiers `.pt` identifiés comme TorchScript contiennent des archives de graphes compilés. Les noms de modules/graphes observés comprennent `MLP`, `HybridGlobalGate`, `QEncoder`, `FixedRBFMap`, `FixedRBF`, `AdaptiveRBF`, `FullModel`, `RbfLite`, `OrchestraOrg`, `ProbeSet` et `MicroMIXA`. Les opérateurs textuellement observés comprennent `matmul`, `linear`, `tanh`, `exp`, `softmax`, `sum`, `slice`, `cat`, `stack`, `mul`, `div`, `clamp` et `pow`.

Les 22 archives ont été ouvertes comme conteneurs ZIP et leurs contenus textuels inspectés ; aucun `torch.jit.load` ni appel d'inférence n'a été exécuté. Une recherche de chaînes `os.system`, `subprocess.`, `socket.`, `eval(`, `exec(` et d'URL littérales dans les sources `.py` extraites a trouvé **zéro correspondance**. Ce résultat est limité aux chaînes recherchées et ne constitue pas une preuve mathématique ou exhaustive d'innocuité.

Fichiers identifiés (l'inventaire JSONL/CSV joint conserve également le chemin relatif exact, la taille et SHA-256) :

- `mlp_optimized_seed1501.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/mlp_optimized_seed1501.pt`
- `mlp_optimized_seed1607.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/mlp_optimized_seed1607.pt`
- `mlp_optimized_seed1717.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/mlp_optimized_seed1717.pt`
- `mlp_optimized_seed2029.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/mlp_optimized_seed2029.pt`
- `mlp_optimized_seed3037.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/mlp_optimized_seed3037.pt`
- `mlp_torchscript_seed1501.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/mlp_torchscript_seed1501.pt`
- `mlp_torchscript_seed1607.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/mlp_torchscript_seed1607.pt`
- `mlp_torchscript_seed1717.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/mlp_torchscript_seed1717.pt`
- `mlp_torchscript_seed2029.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/mlp_torchscript_seed2029.pt`
- `mlp_torchscript_seed3037.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/mlp_torchscript_seed3037.pt`
- `probe_optimized_seed1501.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/probe_optimized_seed1501.pt`
- `probe_optimized_seed1607.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/probe_optimized_seed1607.pt`
- `probe_optimized_seed1717.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/probe_optimized_seed1717.pt`
- `probe_optimized_seed2029.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/probe_optimized_seed2029.pt`
- `probe_optimized_seed3037.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/probe_optimized_seed3037.pt`
- `probe_torchscript_seed1501.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/probe_torchscript_seed1501.pt`
- `probe_torchscript_seed1607.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/probe_torchscript_seed1607.pt`
- `probe_torchscript_seed1717.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/probe_torchscript_seed1717.pt`
- `probe_torchscript_seed2029.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/probe_torchscript_seed2029.pt`
- `probe_torchscript_seed3037.pt` — `input_sources/last_sources_3/sondes_ex5_workspace_20261030__contents/sondes_research_workspace_ex5/versions/sondes_ex5_v007__2026-10-30/results/models/probe_torchscript_seed3037.pt`
- `orchestra_org_oof_rbf1_seed1501_torchscript.pt` — `input_sources/last_sources_3/sondes_ex7_prompt_ex7_integral_v005__contents/EX7_PROMPT7_COMPLETE_V005/01_SNAPSHOTS/V001/sondes_ex7_v001__2026-10-31/results/models/orchestra_org_oof_rbf1_seed1501_torchscript.pt`
- `orchestra_org_oof_rbf1_seed1501_torchscript.pt` — `input_sources/last_sources_3/sondes_ex7_prompt_ex7_integral_v005__contents/EX7_PROMPT7_COMPLETE_V005/01_SNAPSHOTS/V002/sondes_ex7_v002__2026-10-31/results/models/orchestra_org_oof_rbf1_seed1501_torchscript.pt`

### 2.4 Fichiers JOBLIB

Les huit fichiers sont des sérialisations `joblib` basées sur pickle et contiennent notamment des marqueurs de classes tels que `TfidfVectorizer`, `StandardScaler`, `joblib.numpy_pickle` et `numpy._core.multiarray`. Une inspection des octets et un parcours statique partiel des opcodes pickle ont été effectués. Le parseur `pickletools` s'arrête au premier bloc de données NumPy brut, attendu dans ce format ; la désérialisation complète n'a pas été exécutée. Aucun `joblib.load` n'a été invoqué.

| Fichier | Octets | Marqueurs visibles |
|---|---:|---|
| `sms_v009_final_preprocessor.joblib` | 5,818,625 | voir inventaire || `sms_preprocessor_final.joblib` | 5,813,713 | voir inventaire || `sms_preprocessor_final.joblib` | 5,813,713 | voir inventaire || `sms_v009_validation_preprocessor.joblib` | 4,281,489 | voir inventaire || `sms_v009_validation_preprocessor.joblib` | 4,281,489 | voir inventaire || `breast_v008_final_scaler.joblib` | 1,320 | voir inventaire || `breast_v009_final_scaler.joblib` | 1,320 | voir inventaire || `breast_v009_validation_scaler.joblib` | 1,320 | voir inventaire |

Le détail exact de chacun des huit fichiers, les SHA-256, l'état du parseur et les histogrammes d'opcodes figurent dans `joblib_static_pickle_inventory.json`.

### 2.5 Fichier Parquet

Le seul fichier est `sources_ng_adapt_0/dataset/0000.parquet`, **2 306 545 octets**, SHA-256 `ea82612ea9582142387730c793eb67d3b12849002bc0b7fa6f8efafa7351419d`. Les signatures début/fin sont `PAR1`, conformes au conteneur Parquet. Ce fichier est un jeu de données colonnaire, pas un modèle exécutable. Aucun moteur `pyarrow`, `fastparquet`, `duckdb` ou `polars` n'était installé ; l'installation de `pyarrow` avait échoué faute de résolution réseau/DNS. Le schéma et les valeurs des colonnes n'ont donc pas été audités sémantiquement durant cette session. L'original intégral est inclus dans les archives complémentaires.

## 3. Pipeline d'audit complet

1. Consultation des registres canoniques `chemins_eSond_v0.json`, `checklist_de_travail_eSond_v0.json`, `checklist_erreurs_no_model.json` et `checklist_erreurs_model.json`.
2. Lecture de l'inventaire source, conservation des chemins et comparaison de tailles/SHA-256 avec le manifeste original.
3. Tentative initiale de chargement `.pt` avec `weights_only=True` : 6 557 succès, 554 rejets de globals non admis, 22 TorchScript détectés et laissés en inspection statique.
4. Analyse statique des références globales des 554 rejets. 347 ne nécessitaient que les reconstructeurs/dtypes/tableaux NumPy standards ; chargement avec `safe_globals` limité et `weights_only=True`.
5. Pour les 207 autres, création de classes substituts vides portant uniquement l'identité module/nom attendue ; aucun module de recherche original n'a été importé ; aucune méthode originale n'a été invoquée ; chargement conservant `weights_only=True` ; validation récursive des primitives, conteneurs, tenseurs et objets substituts.
6. Inspection statique des 22 archives TorchScript : inventaire ZIP, classes, opérateurs et chaînes textuelles ; pas de `torch.jit.load`, pas de forward/inférence.
7. Inspection statique des huit JOBLIB, sans reconstruction d'objets ; contrôle de signature et empreinte du Parquet.
8. Nouvelle comparaison de chaque artefact original `.pt`, `.joblib` et `.parquet` contre le manifeste source.
9. Création de quatre ZIP complémentaires contenant les **7 133 `.pt`, 8 `.joblib` et 1 Parquet originaux** ; vérification de chaque SHA-256 après lecture depuis le ZIP, du CRC et de la taille maximale.
10. Correction du package runtime : inclusion des neuf JSON, inspection un par un depuis l'extraction exacte de l'archive, tests unitaires depuis cette extraction.
11. Reconstruction des paquets d'audit et de suivi, synchronisation du savepoint, puis signature Ed25519 du rapport et vérification des signatures.

## 4. Commandes d'exécution et de vérification

### Runtime eSonde

Depuis le répertoire où `Dmodel_eSond_v0.zip` a été extrait :

```bash
python run_esonde.py --help
python -m unittest discover -s tests -v
python scripts/audit_pure_probe.py
python run_esonde.py inspect --model examples/models/release_final_model.json
python run_esonde.py inspect --model examples/models/cli_hybrid_3d.json
python run_esonde.py demo --task regression --output demo_reg.json
python run_esonde.py gui
```

### Vérification d'un artefact source original

Chaque partie des archives `artefacts_modeles_sources_eSond_v0_partNN.zip` possède `PART_MANIFEST.csv` avec `archive_path`, taille et SHA-256. Après extraction, calculer par exemple :

```bash
sha256sum "originals/input_sources/EX9_v011_DELIVERABLES__contents/EX9_v011/results/core_pilot/CNC_ADD_M1_seed1501.pt"
```

et comparer le résultat à la ligne correspondante de `PART_MANIFEST.csv`.

### Vérification cryptographique du rapport

```bash
openssl pkeyutl -verify -pubin -inkey INCIDENT_REPORT_PUBLIC_KEY.pem \
  -rawin -in RAPPORT_INCIDENT_DESERIALISATION_ET_COMPLETUDE_eSond_v0.pdf \
  -sigfile RAPPORT_INCIDENT_DESERIALISATION_ET_COMPLETUDE_eSond_v0.pdf.sig
```

## 5. Résultats consolidés

- `.pt` : **7 133** trouvés, **7 111** états décodés restreints, **22** TorchScript statiques.
- Passe 1 : 6 557 ; passe NumPy : 347 ; passe substituts inertes : 207 ; échecs des passes 2/3 : 0.
- TorchScript : 22/22 conteneurs inspectés statiquement ; 0 exécution de graphe.
- JOBLIB : 8/8 identifiés par inventaire, signatures et marqueurs ; 0 désérialisation d'objet.
- Parquet : 1/1 conteneur et empreinte vérifiés ; lecture sémantique non effectuée, moteur absent.
- Snapshots JSON eSonde : **9/9 inspect PASS** depuis le Dmodel extrait.
- Tests runtime depuis le ZIP corrigé : **15/15 PASS**.
- Taille du ZIP runtime courant : **452,095 octets** ; taille mesurée directement sur l'archive finale.
- Artefacts sérialisés source : **7,142 fichiers**, **509,753,792 octets**, répartis en 4 archives complémentaires.

| Archive complémentaire | Fichiers | Taille décompressée | Taille ZIP | CRC/SHA contenu |
|---|---:|---:|---:|---|
| `artefacts_modeles_sources_eSond_v0_part01.zip` | 246 | 134,189,156 | 96,526,524 | PASS |
| `artefacts_modeles_sources_eSond_v0_part02.zip` | 459 | 133,983,550 | 46,603,945 | PASS |
| `artefacts_modeles_sources_eSond_v0_part03.zip` | 963 | 134,175,774 | 76,359,386 | PASS |
| `artefacts_modeles_sources_eSond_v0_part04.zip` | 5474 | 107,405,312 | 66,445,297 | PASS |

## 6. Interprétation et raisons techniques précises

### Pourquoi les 554 fichiers ont-ils d'abord été rejetés ?

Le mode restreint PyTorch n'accepte qu'un ensemble limité de classes/fonctions nécessaires à la reconstruction des tenseurs et conteneurs connus. Pour 347 fichiers, les globals manquants étaient des fonctions/types NumPy standards. Pour 207, les globals faisaient référence à des classes de modèles nommées dans les fichiers d'expériences. Le rejet `UnpicklingError` est un refus de reconstruction par la liste blanche, **pas un diagnostic de corruption ou de malveillance**. Les deux catégories ont ensuite été décodées par des chemins restreints distincts, décrits ci-dessus.

### Quels dangers précis existent ?

- **Pickle / checkpoint `.pt` chargé permissivement :** la reconstruction peut appeler des fonctions/globales référencés par l'objet sérialisé (notamment les mécanismes de réduction/reconstruction pickle). Un fichier tiers spécialement conçu peut donc exécuter du code au chargement dans le processus et avec ses droits. Le risque dépend du contenu et du mode de chargement ; il ne signifie pas que tes fichiers contiennent effectivement un tel code.
- **Classes substituts inertes :** ce mode récupère les attributs/sérialisations accessibles sans exécuter les méthodes originales. Le risque résiduel porte surtout sur les limites de taille/profondeur/mémoire d'un objet ; le script impose une limite de profondeur et valide les types. Il ne permet pas une inférence fidèle d'un ancien modèle personnalisé.
- **TorchScript :** un graphe sauvegardé est un programme tensoriel à exécuter. Le charger ou l'exécuter peut mobiliser des opérateurs, des extensions disponibles dans l'environnement et des ressources CPU/GPU/mémoire. Une exécution mal contrôlée peut provoquer un plantage ou un épuisement de ressources ; les graphes chargés depuis des sources non vérifiées doivent être exécutés dans un environnement isolé. Aucune preuve d'une charge malveillante n'a été trouvée ici ; la recherche statique limitée à quelques marqueurs ne peut pas établir l'innocuité.
- **JOBLIB :** l'utilisation de pickle présente le même risque général de reconstruction d'objets et d'éventuels appels de fonctions durant le chargement. C'est la raison de ne pas appeler `joblib.load` automatiquement sur un fichier dont la provenance du code n'a pas été vérifiée. Les originaux sont livrés ; cette prudence n'est pas une interdiction faite à l'utilisateur.
- **Parquet :** le format est de données, pas une sérialisation d'objets Python exécutable au sens pickle. Le risque principal est celui d'un bogue de parseur ou d'un fichier pathologique provoquant une consommation excessive de ressources ; rien dans les contrôles de signature ne révèle un tel cas. L'inspection des colonnes reste à faire avec un moteur Parquet.

**Constat spécifique aux fichiers fournis :** aucune preuve d'un comportement malveillant, d'une tentative d'accès externe ou d'une corruption n'a été établie par ces contrôles. Le contrôle statique ne peut cependant pas certifier l'absence de tout comportement dangereux. Il est incorrect de décrire les 554 comme « dangereux » ; il est tout aussi incorrect de certifier leur innocuité totale à partir de ces seuls tests.

## 7. Conséquences théoriques, conceptuelles et opérationnelles

### Théoriques

Le décodage d'un état ne suffit pas à reconstruire la fonction d'inférence. Les 207 placeholders conservent des champs et tenseurs mais ne remplacent pas les classes d'origine. Les 22 graphes TorchScript contiennent des graphes exécutables dont le comportement dépend de l'environnement PyTorch et des opérateurs disponibles. Le runtime eSonde JSON est un autre modèle/version, défini par son propre formalisme et son code.

### Conceptuelles

Les 7 133 fichiers `.pt` constituent un ensemble de checkpoints expérimentaux et de comparateurs hétérogènes. Les mélanger au runtime pur-sonde ferait perdre la séparation entre eSonde_v0 et les modèles historiques (dont des MLP/RBF hybrides). Ils sont donc livrés comme artefacts d'audit/données historiques, pas comme composants activés automatiquement du runtime. Aucun fichier n'est supprimé pour cette raison.

### Opérationnelles

L'archive runtime contient désormais neuf snapshots JSON eSonde inspectés. Les artefacts `.pt`, `.joblib` et Parquet sont accessibles dans quatre archives séparées, avec chemins d'origine et SHA-256. Pour faire une inférence historique, il faudra l'implémentation d'origine correspondant au checkpoint, son environnement de dépendances et, pour TorchScript, un runtime/opérateurs compatibles. Les états substituts ne sont pas interchangeables avec l'implémentation originale.

## 8. Conclusion et rectifications

1. La première phrase sur les 554 rejets était techniquement incomplète et pouvait être interprétée comme une rétention de modèle ; elle est rectifiée ici avec le résultat final de 7 111 décodages restreints.
2. Les 22 archives TorchScript n'ont pas été exécutées pendant l'audit. Elles ne sont pas supprimées ou cachées : elles sont incluses brutes dans les archives complémentaires avec leur manifeste.
3. Les huit JOBLIB n'ont pas été désérialisés en objets ; ils sont inclus bruts et inventoriés. Le Parquet est inclus brut, mais son schéma de colonnes n'a pas encore été lu.
4. Le premier Dmodel omettait neuf snapshots ; cette erreur de packaging est corrigée dans l'archive actuelle et contrôlée par extraction propre, inspection 9/9 et tests 15/15.
5. Les fichiers utilisateur originaux sélectionnés `.pt`, `.joblib` et `.parquet` sont restitués sans conversion, tous contrôlés contre le manifeste source, dans quatre archives supplémentaires sous 200 MiB.
6. Aucune accusation de danger contre les fichiers fournis n'est formulée. Les risques précisés sont inhérents aux mécanismes génériques de chargement et ne prouvent pas la présence d'un exploit dans ces fichiers.

## 9. Statut du modèle et de la livraison

| Composant | Statut vérifié |
|---|---|
| Runtime pur-sonde eSonde_v0 | Présent dans Dmodel ; 15/15 tests depuis extraction propre |
| Snapshots natifs JSON eSonde | 9/9 inspection PASS ; intégrés dans Dmodel |
| Checkpoints historiques `.pt` | 7 111 états décodés en mode restreint ; 22 TorchScript statiques ; 7 133 originaux emballés |
| JOBLIB | 8 originaux emballés, non désérialisés |
| Parquet | Original emballé, PAR1/SHA vérifiés, lecture sémantique non accomplie |
| Amodel / suivi | PASS — CRC et manifestes SHA-256 internes vérifiés ; empreintes externes finales disponibles dans eSonde_v0_RELEASE_SHA256SUMS.txt |

## 10. Attestation et signature

**Attestation rédactionnelle :** je confirme que le premier rapport a signalé des objets non chargés par certains chemins de désérialisation, sans expliquer assez clairement qu'il s'agissait d'artefacts historiques des sources et non d'un refus de livrer le runtime eSonde_v0. Je confirme que le premier ZIP runtime était incomplet parce qu'il omettait les neuf snapshots JSON déjà présents. Je reconnais que l'annonce précédente de leur inclusion avait été faite avant vérification du contenu réel du ZIP. Cette omission est corrigée dans la présente release.

**Signataire rédactionnel :** ChatGPT — assistant IA GPT-6.  
**Date :** 8 novembre 2026.  
**Signature :** signature cryptographique Ed25519 du contenu du présent rapport (PDF et Markdown), générée pour l'intégrité du fichier. La clé est auto-générée pour ce paquet et publiée avec celui-ci afin de permettre la vérification. Elle n'est pas un certificat d'identité OpenAI, une signature électronique qualifiée, une signature manuscrite ou une certification juridique par une personne physique. La signature atteste que le contenu signé n'a pas été modifié depuis la génération de cette signature ; elle n'atteste pas à elle seule l'exactitude juridique ou scientifique de chaque déclaration.

---

**Annexes machine-readable :** `checkpoint_inventory_final.jsonl`, `checkpoint_inventory_final.csv`, `joblib_static_pickle_inventory.json`, `serialized_artifact_raw_manifest.json`, `serialized_artifact_final_summary.json`, `custom_checkpoint_inert_load.jsonl`, et `snapshot_package_smoke.json`.


### Métadonnées et validation des paquets finaux

- `Dmodel_eSond_v0.zip` : 452,095 octets, 41 membres, SHA-256 `e0464c5eadf1f4516f87280493b27d1b83964b3c90901daf64cfbc21d5fc13d1` ; CRC et manifeste interne PASS.
- `Amodel_eSond_v0.zip` et `suivi_model_eSond_v0.zip` : CRC et manifestes internes PASS ; leurs empreintes externes définitives sont consignées dans `eSonde_v0_RELEASE_SHA256SUMS.txt` afin d’éviter toute auto-référence dans le présent rapport.
