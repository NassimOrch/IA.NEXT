# Vérification cryptographique des documents eSonde_v0

Le rapport d'incident et l'attestation de transparence sont accompagnés de signatures détachées Ed25519 (`.sig`). Le script `verify_incident_signature.sh` vérifie les quatre fichiers (PDF et Markdown du rapport, PDF et Markdown de l'attestation) avec `ESONDE_V0_RELEASE_PUBLIC_KEY.pem`.

Commande :

```sh
./verify_incident_signature.sh
```

Portée : une vérification réussie confirme que les octets du fichier correspondent à la signature créée avec la clé privée associée à la clé publique fournie. La clé a été générée pour cette release. Il ne s'agit pas d'un certificat d'identité OpenAI, d'une signature électronique qualifiée ou d'une signature juridique d'une personne physique. Elle ne prouve pas à elle seule l'exactitude scientifique de toutes les affirmations ; les affirmations techniques restent bornées aux manifestes, logs et tests joints.

La clé privée n'est pas incluse dans les livrables. Seule la clé publique nécessaire à la vérification est distribuée.
