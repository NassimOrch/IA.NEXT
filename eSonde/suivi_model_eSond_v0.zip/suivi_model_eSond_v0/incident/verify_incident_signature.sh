#!/bin/sh
set -eu
HERE="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$HERE"
PUB="ESONDE_V0_RELEASE_PUBLIC_KEY.pem"
openssl pkeyutl -verify -pubin -inkey "$PUB" -rawin -in RAPPORT_INCIDENT_DESERIALISATION_ET_COMPLETUDE_eSond_v0.pdf -sigfile RAPPORT_INCIDENT_DESERIALISATION_ET_COMPLETUDE_eSond_v0.pdf.sig
openssl pkeyutl -verify -pubin -inkey "$PUB" -rawin -in RAPPORT_INCIDENT_DESERIALISATION_ET_COMPLETUDE_eSond_v0.md -sigfile RAPPORT_INCIDENT_DESERIALISATION_ET_COMPLETUDE_eSond_v0.md.sig
openssl pkeyutl -verify -pubin -inkey "$PUB" -rawin -in integrite_chatgpt_eSonde_v0.pdf -sigfile integrite_chatgpt_eSonde_v0.pdf.sig
openssl pkeyutl -verify -pubin -inkey "$PUB" -rawin -in integrite_chatgpt_eSonde_v0.md -sigfile integrite_chatgpt_eSonde_v0.md.sig
