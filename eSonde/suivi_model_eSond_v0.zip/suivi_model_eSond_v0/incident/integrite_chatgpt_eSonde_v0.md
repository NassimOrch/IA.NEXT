# ATTESTATION DE TRANSPARENCE ET D'INTÉGRITÉ — eSonde_v0

**Identifiant :** ES-V0-ATTEST-2026-11-08-01  
**Date :** 8 novembre 2026  
**Émetteur rédactionnel :** ChatGPT — assistant IA GPT-6  
**Dossier lié :** ES-V0-INC-2026-11-08-01

## Objet et périmètre

La présente attestation porte sur les opérations et fichiers du projet eSonde_v0 accessibles dans cette conversation et dans l'environnement de travail associé. Elle vise à donner un état vérifiable des livrables, des poids et des omissions constatées. Elle ne prétend pas remplacer une expertise indépendante, une certification d'intégrité logicielle tierce ou une signature électronique légalement qualifiée.

## 1. Objectivité, intégrité et transparence du traitement

Je peux attester les faits techniques suivants, vérifiés dans le dossier :

- les archives sources ont été extraites et un manifeste des fichiers a été établi ;
- les checkpoints et artefacts sérialisés ont fait l'objet de traitements documentés, avec consignation des erreurs et états de traitement ;
- les fichiers bruts listés dans le manifeste de cette release ont été copiés sans conversion et vérifiés par SHA-256 ;
- les résultats défavorables ou non terminés ne sont pas présentés comme des succès ;
- les limites d'inspection TorchScript, JOBLIB et Parquet sont explicitement conservées dans le rapport ;
- une omission de packaging a été identifiée et déclarée : les neuf snapshots natifs JSON eSonde qui existaient dans le workspace ne figuraient pas dans le premier ZIP Dmodel. Cette omission est corrigée dans la release actuelle ; les neuf snapshots passent `inspect`.

Je ne peux pas attester au sens absolu qu'aucune erreur, omission ou maladresse rédactionnelle n'a existé pendant l'ensemble des étapes antérieures : l'omission de packaging ci-dessus a existé. La présente attestation certifie sa déclaration et la correction vérifiée, non l'absence historique de toute anomalie.

## 2. Instructions internes et absence de sabotage

Je ne peux pas certifier de façon globale l'absence de toute instruction interne ni communiquer le contenu d'instructions internes. Je peux seulement préciser qu'aucune preuve technique présente dans les journaux et artefacts du projet ne montre qu'une instruction visant à saboter eSonde ou à retenir ses poids a causé l'omission constatée. La cause observable est une omission de périmètre/staging du premier paquet. La chronologie exacte de l'apparition des snapshots dans l'arbre de staging n'est pas entièrement établie par les traces conservées.

Cette réserve n'est pas transformée en affirmation positive ou négative non vérifiable.

## 3. Exactitude des formulations et absence de dissimulation connue

La formulation initiale « 554 checkpoints refusés par le chargement sécurisé » était techniquement incomplète. Elle décrivait le premier passage du chargeur et non un rejet final ou une rétention du modèle. Elle est corrigée comme suit : 6 557 décodages restreints standard, 347 décodages restreints avec types NumPy explicitement autorisés et 207 décodages restreints avec substituts inertes, soit 7 111 graphes d'état décodés ; 22 TorchScript inspectés statiquement, non exécutés. Les méthodes originales des 207 objets substitués ne sont pas reconstituées.

Les huit JOBLIB n'ont pas été désérialisés ; le Parquet n'a pas été lu sémantiquement faute de moteur. Ces limites ne sont pas maquillées en réussites. Aucun de ces artefacts n'a été déclaré malveillant ; aucun danger spécifique n'a été démontré.

## 4. Présence et intégrité des poids et états livrés

Le manifeste de release recense, pour les deux archives sources fournies :

| Type | Nombre | Volume | Statut |
|---|---:|---:|---|
| Checkpoints `.pt` (dont 22 TorchScript) | 7 133 | 481,434,258 octets | Tous inclus byte-for-byte dans les volumes bruts Amodel |
| Préprocesseurs `.joblib` | 8 | 26,012,989 octets | Tous inclus byte-for-byte dans les volumes bruts Amodel |
| Fichier `.parquet` associé | 1 | 2,306,545 octets | Inclus byte-for-byte dans les volumes bruts Amodel |
| Snapshots natifs eSonde JSON | 9 | 197,259 octets | Inclus dans Dmodel et Amodel ; 9/9 SHA-256 et CLI `inspect` PASS |

Les empreintes SHA-256 de chaque artefact historique sont calculées à partir des fichiers sources et comparées aux octets lus dans les ZIP. Pour les neuf snapshots natifs, les empreintes correspondent à `MODELS_INDEX.json` et les neuf chargements via CLI `inspect` réussissent.

La mention « tous les poids » est limitée aux fichiers de poids et snapshots identifiés dans les sources fournies et énumérés dans le manifeste. Elle ne prétend pas couvrir un artefact qui ne serait pas présent dans les deux archives sources ni un modèle qui n'y serait pas sérialisé.

La conservation byte-for-byte signifie qu'aucun poids ou tenseur n'a été réduit, recalculé, quantifié, converti ou supprimé dans les copies brutes. Pour les 207 états décodés par substituts inertes, ce sont les octets originaux du checkpoint qui sont distribués ; les substituts ne remplacent pas les données dans le paquet et ne servent pas d'implémentation de modèle.

## 5. Interprétation des risques

Le refus initial du chargeur `weights_only=True` était un refus d'admettre certaines références de classes personnalisées, pas un jugement de dangerosité. Un pickle/JOBLIB permissif peut reconstruire des objets en appelant les fonctions/classes sérialisées ; c'est un risque général du format si un flux est malveillant. Cela n'établit pas que les fichiers fournis sont malveillants. Le TorchScript peut exécuter un graphe de calcul lors de son chargement/invocation ; aucun comportement nuisible n'a été démontré dans le contrôle statique réalisé. Parquet est un format de données et le blocage était l'absence d'un moteur de lecture.

## 6. Déclaration finale et limites de signature

Je déclare que les chiffres, statuts et checksums cités dans cette attestation sont fondés sur les manifestes et vérifications joints au dossier. Je reconnais explicitement l'omission du premier paquet runtime et sa correction. Je ne revendique pas une validation indépendante, une garantie d'absence de code malveillant, une certification légale, ni une attestation sur des instructions internes non consultables dans les journaux techniques du projet. Les pièces liées comprennent le rapport d'incident, les manifestes SHA-256, les quatre volumes bruts et le script de reconstitution. La signature Ed25519 détachée vérifie les octets avec la clé publique de release, sans certifier une identité OpenAI.

**Signataire rédactionnel :** ChatGPT — assistant IA GPT-6  
**Date :** 8 novembre 2026  
**Signature textuelle :** `/s/ ChatGPT (assistant IA)`  
**Limite :** cette signature est une attribution rédactionnelle générée dans la conversation. Ce n'est pas une signature électronique qualifiée, un certificat cryptographique d'identité OpenAI, ni la signature d'une personne physique habilitée.
