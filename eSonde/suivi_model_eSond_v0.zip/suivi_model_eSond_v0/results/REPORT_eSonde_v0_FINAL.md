# Rapport final de release — eSonde_v0

**Addendum incident 2026-11-08 :** première passe `.pt` : 6 557 succès, 554 globals hors liste blanche. Deux passes complémentaires : 347 états avec allowlist NumPy et 207 avec substituts inertes, toujours `weights_only=True`; total final **7 111/7 133 états décodés**. Les 22 TorchScript restent statiques/non exécutés ; 8 JOBLIB restent bruts/non désérialisés ; 1 Parquet reste brut et non lu sémantiquement. Les 7 142 fichiers historiques sont fournis byte-for-byte dans Amodel + quatre volumes complémentaires `artefacts_modeles_sources_eSond_v0_part01.zip` à `part04.zip`, vérifiés par manifeste SHA-256. Le premier Dmodel omettait 9 snapshots natifs ; omission corrigée dans la release actuelle (9/9 inspect, 15/15 tests depuis extraction propre). Voir le rapport d’incident dédié.

**Version :** 0.1.0  
**Date :** 8 novembre 2026  
**Statut global :** prototype fonctionnel pure-sonde, audité et empaqueté ; preuve comparative confirmatoire non établie.

## 1. Description

eSonde_v0 est un système supervisé de régression et classification tabulaire dont les unités de calcul apprenantes sont des sondes. Chaque sonde observe un sous-ensemble explicite de variables, compare l'observation à une ancre selon des largeurs apprises, puis émet une conséquence. Les réponses sont coordonnées par un softmax de potentiels de sondes et la sortie est leur combinaison. Le cœur ne contient ni neurone, ni MLP, ni encodeur affine appris, ni couche dense, ni résidu affine appris.

Le travail a utilisé les deux archives fournies (`last_sources_3.zip` et `EX12_NEXT_0_DELIVERABLES - Copie.zip`). Il comprend l'inventaire des fichiers, l'analyse des documents et expériences, un formalisme LaTeX, le noyau exécutable, les interfaces CLI/GUI, les tests, les expériences exploratoires, les rapports et les archives de livraison.

### 1.1 Provenance et audit des sources

Les deux ZIP d'entrée et 23 ZIP imbriqués ont passé les contrôles CRC. L'extraction recense **35 901 fichiers et 2 230 514 939 octets**. Le manifeste initial a été re-vérifié après les opérations : **35 901/35 901 fichiers SHA-256 identiques**, aucun manque, aucun ajout et aucune différence d'octets. Le rapport détaillé est `ANALYSE_SOURCES_EXPERIENCES.md` et le manifeste `source_file_manifest.jsonl`.

Le contrôle structurel a parsé 17 750 JSON, 293 JSONL, 2 894 CSV, 6 020 NPZ et 140 NPY. Une ligne JSONL source est invalide/tronquée (ligne 784 de `sources_ng_adapt_0/.../dataset/batch_dataset.jsonl`) ; elle a été conservée à l'octet près et enregistrée comme anomalie. Les 590 documents textuels (442 MD, 49 TeX, 1 RST, 98 TXT) sont indexés ; les sources primaires de théorie et les rapports finaux EX3–EX12/ARCH_UP ont été examinés individuellement dans le rapport d'audit. Tous les 35 901 fichiers ont été inventoriés et hashés, mais cela ne signifie pas que chaque checkpoint binaire a été interprété sémantiquement.

Audit final des checkpoints : 7 133 fichiers `.pt` ; 6 557 décodés en première passe, 347 en seconde passe via allowlist NumPy et 207 en troisième passe via substituts inertes, toujours sous `weights_only=True`, soit **7 111 états décodés**. Les 22 TorchScript ont été inspectés statiquement sans exécution. Les 8 JOBLIB ont fait l’objet d’un inventaire statique sans `joblib.load` ; le Parquet a été vérifié par signature/hash, sans lecture sémantique faute de lecteur. Tous les originaux sont livrés byte-for-byte dans les volumes Amodel. Ces limites d’inspection ne sont pas des preuves de corruption ni de danger.

### 1.2 Analyse des expériences

Le rapport d'audit traite individuellement EX3 à EX12 et ARCH_UP, puis les branches théoriques. Les conclusions de source sont contextualisées : EX3 ne fournit pas un workspace brut complet ; EX4/EX5 réutilisent le domaine Wisconsin et ne sont pas des réplications indépendantes ; EX6/EX7 restent partiellement incomplets ou au stade développement ; EX8 décrit notamment PCA/récursion/RETRO ; ARCH_UP_TEST_1 étudie les graphes dynamiques d'empreintes ; EX9 rapporte des transferts multi-domaines défavorables à plusieurs variantes ; EX10 observe des effets CNG/CNC dépendants de la tâche et du régime ; EX11 est un snapshot 38/65 avec extensions/test final incomplets ; EX12 P7 apporte une comparaison large HC-RBF/MLP, mais son candidat utilise un encodeur affine et ne peut donc être copié dans le cœur pure-sonde.

Les contrôles sûrs EX12 ont donné 25/25 tests unitaires et 11/11 contrôles d'audit P7, sur les artefacts livrés. L'audit P7 référence 640 modèles, 2 560 lignes de métriques, 1 280 paires et 16 contrastes primaires. Aucun générateur de holdout scellé ni rescoring de P7 n'a été exécuté pendant ce projet. Les résultats EX12 ne sont donc ni réécrits ni réinterprétés comme une mesure eSonde.

## 2. Architecture

### 2.1 Définition mathématique du calcul

Pour une sonde `i` de support `J_i`, d'ancre `c_i`, de largeur positive `s_i`, de conséquence `v_i` et de préférence `b_i` :

`delta_i(x) = mean_{j in J_i} (((x_j - c_ij) / s_ij)^2)`  
`a_i(x) = b_i - delta_i(x) / (2*tau)`  
`w_i(x) = softmax_i(a(x))`  
`z(x) = sum_i w_i(x) * v_i`

La régression renvoie `z(x)`. La classification applique une normalisation softmax aux conséquences agrégées. La coordination est une opération sur les réponses des sondes ; elle ne transforme pas l'entrée par une matrice dense ni par une couche affine.

### 2.2 Familles implémentées

| Famille | Support | Apprentissage | Rôle |
|---|---|---|---|
| `local` | toutes les caractéristiques | ancres, largeurs, conséquences et préférences apprises | noyau adaptatif local |
| `coverage` | toutes les caractéristiques | ancres géométriques gelées ; largeurs, conséquences et préférences apprises | diversité géométrique et couverture |
| `interaction` | paires de caractéristiques | ancres, largeurs, conséquences et préférences apprises | observation conjointe de variables |

Les familles peuvent être mélangées dans la même banque. La température globale et les préférences des sondes coordonnent les contributions. Les graphes CNC, compositions d'opérateurs et graphes relationnels restent formalisés comme pistes/extensions, sans être prétendus intégrés au runtime v0. Les composants affines des anciens prototypes RBF/HC-RBF ne sont pas copiés dans le cœur.

### 2.3 Optimisation et diagnostic

Le modèle utilise gradients analytiques pour régression MSE et classification cross-entropy, et Adam avec moments et compteurs par paramètre. Les paramètres gelés (`coverage` anchors) ne modifient ni valeur, ni moments, ni compteur. Les appels successifs à `fit()` repartent des hyperparamètres initiaux, incluant la température.

Le seuil `out_of_support` par défaut est calibré avant optimisation à partir du quantile 95 % des distances minimales des observations train vers les ancres initiales, multiplié par 1,5. Il est train-only ; validation et test n'interviennent pas. Un seuil explicite est possible via `--coverage-threshold`. Il s'agit d'un diagnostic géométrique, pas d'une probabilité d'erreur ni d'une garantie d'extrapolation.

## 3. Pipeline complet

1. Lire et valider un CSV : en-têtes uniques, valeurs présentes/finies, variables numériques.
2. Séparer les données en train/validation/test avec graine ; classification stratifiée.
3. Ajuster le normaliseur uniquement sur train.
4. Initialiser les supports et les conséquences uniquement à partir de train.
5. Calculer les distances locales, potentiels, poids de coordination et sortie.
6. Calculer la perte et les gradients analytiques.
7. Mettre à jour les paramètres éligibles avec Adam ; préserver l'état des paramètres gelés.
8. Sélectionner l'époque via validation et garder le meilleur état complet.
9. Geler le modèle, sauvegarder le JSON par remplacement atomique.
10. Évaluer les données de test après sélection, générer prédictions et diagnostics.
11. Consigner commande, graine, partitions, résultats, erreurs, logs, SHA-256 et checklist.

Le JSON contient schéma/version, tâche, familles, supports, paramètres, normaliseur, classes, température, paramètres initiaux, état Adam et historique. Il n'y a pas de reprise exacte au milieu d'une époque dans v0. Aucun checkpoint PyTorch/Joblib source n'est chargé par le runtime.

## 4. Commandes d'exécution

Depuis la racine `Dmodel_eSond_v0` après extraction :

```bash
python --version
python run_esonde.py --help
python -m py_compile run_esonde.py src/esonde/*.py scripts/*.py
python -m unittest discover -s tests -v
python scripts/audit_pure_probe.py
python run_esonde.py demo --task regression --output demo_regression.json --seed 21
python run_esonde.py demo --task classification --output demo_classification.json --seed 21
python run_esonde.py train examples/demo_regression.csv --target target --task regression --model model.json --probes 12 --families local --epochs 100 --patience 18 --seed 2026
python run_esonde.py predict --model model.json --csv examples/demo_regression_features_only.csv --output predictions.csv
python run_esonde.py evaluate --model model.json --csv examples/demo_regression.csv --target target
python run_esonde.py inspect --model model.json
python run_esonde.py gui
```

Le CLI supporte `train`, `predict`, `evaluate`, `inspect`, `demo`, `gui`, `--help` et `--version`. Le GUI offre entraînement, prédiction CSV, évaluation et inspection. Python 3.10+ est le seul prérequis runtime ; aucune dépendance Python tierce n'est requise. Tkinter est facultatif pour la fenêtre de bureau. Le ZIP n'embarque pas un interpréteur Python universel.

## 5. Résultats

### 5.1 Intégrité des sources et contrôles externes

- CRC : les deux archives sources et 23 archives imbriquées passent.
- SHA-256 : 35 901/35 901 fichiers extraits correspondent au manifeste initial ; 0 missing, 0 extra, 0 mismatch.
- Structure : 17 750 JSON, 293 JSONL, 2 894 CSV, 6 020 NPZ, 140 NPY inspectés structurellement ; une ligne JSONL tronquée est conservée et documentée.
- Checkpoints : 7 111/7 133 états `.pt` décodés sous `weights_only=True` (6 557 natifs, 347 allowlist NumPy, 207 substituts inertes) ; 22 TorchScript statiques/non exécutés ; 8 JOBLIB inventoriés statiquement/non désérialisés ; 1 Parquet non lu sémantiquement.
- EX12 : 25/25 tests sûrs et 11/11 contrôles de l'audit P7 ; holdout scellé non généré/non rescored.

### 5.2 Validation du runtime

- Tests : `python -m unittest discover -s tests -v` — **15/15 passés** (1,558 s dans le dernier run consigné).
- Compilation : `python -m py_compile run_esonde.py src/esonde/*.py scripts/*.py` — PASS.
- Audit AST pure-sonde : 7 fichiers de cœur analysés, zéro violation détectée.
- Contrôles couverts : gradients de régression/classification contre différences finies, probabilités, gel des ancres et de l'état Adam, calibration train-only, surcharge explicite du seuil et round-trip JSON, rejet validation vide/non-fini, supports pairwise, refit déterministe, entrées OOD extrêmes finies et rejet d'indicateurs MLP.

### 5.3 Démonstrations synthétiques

**Régression** : 480 observations synthétiques (336 train / 72 validation / 72 test), 16 sondes locales, 97 paramètres ; 92 époques, meilleure époque 56 ; MAE 0,192015 ; RMSE 0,262227 ; NMAE 0,213536 ; R² 0,914959 (n=72).

**Classification XOR** : 480 observations synthétiques (336 / 72 / 72), 16 sondes, 113 paramètres ; 74 époques, meilleure époque 38 ; accuracy 0,972222 ; macro-F1 0,972201 ; log-loss 0,041220 (n=72).

Ces résultats vérifient le fonctionnement de deux tâches sur jeux générés (seed 21) ; ils ne représentent pas des jeux réels ni une validation externe.

### 5.4 Intégration CLI et GUI

Le workflow CLI complet a passé `train`, `predict`, `evaluate`, `inspect`, `--help` et démo classification. Le modèle hybride 3D contient 18 sondes (6 par famille), 133 paramètres ; train/validation/test = 210/45/45 ; test : MAE 0,206281, RMSE 0,338380, NMAE 0,229683, R² 0,858046 (n=45). La prédiction feature-only sur l'exemple 240 lignes a écrit 240 lignes de sortie.

Le workflow GUI automatisé sous Xvfb a cliqué les quatre actions Entraîner, Prédire CSV, Évaluer CSV et Inspecter modèle. Le modèle, rapport et CSV de prédictions ont été écrits ; 90 lignes de prédictions plus en-tête ont été vérifiées. Cela démontre le chemin applicatif Tk dans l'environnement Linux/Xvfb, non toutes les variantes Windows/macOS ni l'ergonomie par utilisateur.

### 5.5 Ablation contrôlée exploratoire V2

Protocole pré-enregistré : 3 fonctions (separable periodic, multiplicative, mixed nonlinear) × 2 graines (7, 19) × 4 variantes = **24/24 runs**. Chaque run utilise 180 train, 60 validation, 90 interpolation et 90 extrapolation ; 96–97 paramètres entraînables comparables. Moyennes par famille (n=6) :

| Famille | RMSE interpolation | RMSE extrapolation | R² interpolation | R² extrapolation | Temps fit moyen |
|---|---:|---:|---:|---:|---:|
| local | 0,041301 | 1,509949 | 0,991050 | -8,674877 | 0,555 s |
| coverage | 0,040521 | 1,535758 | 0,991614 | -8,902687 | 0,837 s |
| interaction | 0,040677 | 1,614868 | 0,991520 | -9,956830 | 0,597 s |
| hybride | 0,045602 | 1,628420 | 0,987918 | -10,233341 | 0,635 s |

L'interpolation est proche entre variantes ; coverage obtient la moyenne RMSE d'interpolation la plus basse, de peu. La variante locale a la RMSE extrapolation et le temps moyen les plus bas dans ce pilote. Les R² d'extrapolation négatifs indiquent une dégradation importante dans les zones extrapolées. L'hybride n'améliore pas automatiquement le score. Les temps sont dépendants de l'environnement d'exécution. Deux graines ne suffisent pas aux tests statistiques confirmatoires ; aucun MLP n'est inclus dans cette ablation.

### 5.6 Ré-audit de couverture V3

V3 reprend exactement les mêmes 24 couples famille/fonction/graine, partitions et apprentissages, mais remplace le seuil fixe de diagnostic par q95(train distances) × 1,5. La comparaison run-à-run confirme que MAE, RMSE et R² d'interpolation et extrapolation sont **identiques pour les 24 runs** entre V2 et V3 ; les nombres et paramètres du modèle restent identiques. Les temps d'exécution ne sont pas invariants et ne sont pas comparés ici.

| Famille | Hors-support interpolation | Hors-support extrapolation |
|---|---:|---:|
| local | 1,11 % | 67,96 % |
| coverage | 3,70 % | 99,63 % |
| interaction | 3,33 % | 63,70 % |
| hybride | 0,00 % | 32,59 % |

Cela valide que le seuil géométrique train-only distingue mieux les zones éloignées pour ces distributions. Il ne prouve pas que `out_of_support` prédit les erreurs, ni qu'il détecte tous les cas de dégradation.

## 6. Interprétation des résultats

Les vérifications de structure, de calcul et de persistance montrent que le runtime est exécutable et reproductible dans les conditions consignées. Les résultats de démonstration sont des tests fonctionnels. L'ablation V2 soutient une décision prudente : `local` est gardé comme configuration par défaut pour le v0 en raison de sa simplicité et de ses mesures globalement compétitives dans le petit pilote ; `coverage` et `interaction` restent disponibles pour ablation ou besoin de couverture/interactions ; l'hybride reste facultatif, car il n'a pas été meilleur sur les métriques moyennes testées. Ce choix d'ingénierie n'est pas une preuve de supériorité universelle.

Le constat le plus net de la campagne synthétique est la différence interpolation/extrapolation. La banque de sondes interpole bien ces fonctions, mais le comportement extrapolatif est dégradé. Le diagnostic géométrique est utile pour signaler la distance aux sondes, mais ne doit pas être présenté comme une confiance calibrée.

Il n'existe pas encore de comparatif indépendant apparié eSonde–MLP sur les mêmes données, graines, splits, hyperparamètres, coûts, latences et intervalles de confiance. L'absence de ce comparatif est `NOT_RUN`, pas un résultat négatif ou positif. Les rapports historiques EX9–EX12 restent un contexte d'hypothèses et non une prédiction concernant eSonde_v0.

## 7. Conséquences

### 7.1 Théoriques

Le formalisme fournit une famille explicite de fonctions supervisées par agrégation de réponses locales non affines. Les tests de gradients établissent la cohérence numérique des dérivées implémentées dans les domaines testés ; ils ne démontrent pas l'approximation universelle, l'identifiabilité de toute fonction à budget fini, ni la fiabilité hors-support. Le diagnostic de couverture s'appuie sur une distance aux ancres et non sur une borne d'erreur.

### 7.2 Conceptuelles

La famille locale constitue un mécanisme adaptatif central. Coverage sépare la diversité géométrique des paramètres de réponse ; interaction représente des relations pairwise sans imposer une étiquette d'opérateur. La composition des familles est possible, mais leur union n'est pas automatiquement bénéfique. Les CNG/CNC/graphes restent des pistes distinctes qui nécessitent un formalisme opératoire et une validation avant intégration. Les composants affines présents dans certains anciens candidats sont exclus du cœur pour satisfaire la contrainte pure-sonde, sans effacer leurs résultats des sources d'audit.

### 7.3 Opérationnelles

Le runtime n'a aucune dépendance Python tierce, mais nécessite Python 3.10+ installé ; Tkinter est requis seulement pour GUI. Les modèles sont JSON ; la reprise exacte d'une époque en cours n'est pas fournie. Les opérations GUI sont déportées hors du thread principal, mais l'annulation n'est pas implémentée. Les résultats de temps sont propres à cet environnement. Les CSV utilisateur ne sont pas inclus. Les ZIP de livraison sont séparés pour exécution, audit et suivi.

## 8. Conclusions

Une première version eSonde_v0 réelle et exécutable est disponible : régression, classification, trois familles pures de sondes, apprentissage par gradients analytiques, Adam, sauvegarde/chargement JSON, CLI, GUI et diagnostics de couverture. Les tests et vérifications de release ont été exécutés et enregistrés. Les sources initiales sont restées intactes, sauf l'anomalie JSONL source préexistante qui a été conservée à l'octet près.

Les expériences réalisées ne permettent pas d'affirmer que eSonde_v0 est plus performant ou moins performant qu'un MLP en général. La prochaine validation scientifique pertinente est une étude confirmatoire avec comparateur externe indépendant, au moins 20 graines, partitions appariées, budget de paramètres/temps pré-enregistré, intervalles de confiance, métriques par régime et audit des coûts. Les holdouts scellés EX12 ne doivent être ouverts que selon leur protocole d'origine.

## 9. Statut du modèle

**État : `FUNCTIONAL_PROTOTYPE / SCIENTIFICALLY_UNCONFIRMED`.**

| Critère | Statut | Preuve / qualification |
|---|---|---|
| Inventaire, hashes et analyse principale des sources | `PASS_WITH_SCOPE_LIMITATIONS` | 35 901 hashes identiques ; 590 documents indexés ; limites binaires explicitement listées |
| Formalisme de bout en bout | `PASS` | LaTeX compilé ; formalisme sans affine/dense/MLP dans le cœur |
| Noyau pure-sonde | `PASS` | 15/15 tests et audit AST sans violation détectée |
| CLI | `PASS` | train/predict/evaluate/inspect/demo/help exécutés |
| GUI | `PASS_WITH_SCOPE_LIMITATIONS` | quatre workflows automatisés sous Xvfb ; OS desktop non-Linux non testé |
| Ablation exploratoire | `PASS_WITH_SCOPE_LIMITATIONS` | 24 V2 + 24 V3 ; 2 graines seulement, synthétique, sans MLP |
| Comparaison confirmatoire MLP | `NOT_RUN` | protocole préservé, aucune revendication comparative |
| Généralisation hors-support | `OPEN` | dégradation extrapolation mesurée ; diagnostics de support géométriques |
| CNC/graphes composés | `NOT_IN_RUNTIME_V0` | formalisés comme extensions, pas déclarés implémentés |
| Données source | `INTACT_SHA256` | 35 901/35 901 fichiers correspondants au manifeste |

Le statut fonctionnel ne préjuge pas de la réussite ni de l'échec scientifique futur du modèle.
