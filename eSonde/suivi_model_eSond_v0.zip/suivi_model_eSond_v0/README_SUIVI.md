# suivi_model_eSond_v0

Ce paquet contient les checklists, preuves, chemins canoniques, historique des exécutions, rapports et le point de sauvegarde `sav_eSond_v0`.

Le runtime est dans `Dmodel_eSond_v0.zip`. L’audit détaillé est dans `Amodel_eSond_v0.zip`. Les artefacts sérialisés historiques originaux sont dans quatre volumes complémentaires `artefacts_modeles_sources_eSond_v0_part01.zip` à `part04.zip`; utiliser `assemble_Amodel_eSond_v0.py` pour les reconstituer et vérifier 7 142 empreintes SHA-256.

Statut incident : les 554 rejets de la première passe sont reclassés comme 347 états décodés via allowlist NumPy et 207 via stubs inertes, toujours sous `weights_only=True`; total 7 111 états `.pt` décodés, plus 22 TorchScript statiques. Les 8 JOBLIB sont statiquement inventoriés sans désérialisation et le Parquet n’est pas lu par colonnes. Les fichiers originaux sont livrés byte-for-byte.
