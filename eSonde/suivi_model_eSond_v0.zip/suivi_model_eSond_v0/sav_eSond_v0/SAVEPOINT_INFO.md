# sav_eSond_v0 — point de sauvegarde synchronisé

Mis à jour le 8 novembre 2026 après l’incident de complétude/inspection des artefacts sérialisés. Contient l’état exact du projet, les neuf snapshots natifs et les checklists actualisées.

Le journal d’exécution et les manifestes détaillés sont référencés dans `audit_reference/`. Les 7 142 artefacts historiques sont livrés byte-for-byte dans les quatre volumes `artefacts_modeles_sources_eSond_v0_part*.zip`; ils ne sont pas dupliqués dans ce savepoint compact.

Statut : runtime eSonde_v0 15/15 tests ; 9/9 snapshots inspect ; 7 142 artefacts bruts vérifiés par SHA-256 lors de la reconstitution ; limites d’inspection TorchScript/JOBLIB/Parquet documentées.
