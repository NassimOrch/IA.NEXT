"""eSonde v0: pure adaptive-probe predictor; Python standard library only."""
from __future__ import annotations

import copy
import json
import math
import random
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence, Any

VERSION = "0.1.0"
_EPS = 1e-12


def _matrix(X: Sequence[Sequence[float]], name: str = "X") -> list[list[float]]:
    rows = [[float(v) for v in row] for row in X]
    if not rows:
        raise ValueError(f"{name} ne peut pas être vide")
    width = len(rows[0])
    if width == 0 or any(len(r) != width for r in rows):
        raise ValueError(f"{name}: matrice vide ou lignes de dimensions différentes")
    if any(not math.isfinite(v) for r in rows for v in r):
        raise ValueError(f"{name}: valeurs NaN ou infinies interdites")
    return rows


def _softmax(values: Sequence[float]) -> list[float]:
    if not values:
        raise ValueError("Softmax vide")
    if any(math.isnan(float(v)) or float(v) == math.inf for v in values):
        raise FloatingPointError("Softmax: NaN ou +inf interdit")
    m = max(values)
    # If every support is beyond representable range, keep a finite neutral
    # coordination. The independent out-of-support diagnostic exposes this case.
    if m == -math.inf:
        return [1.0 / len(values)] * len(values)
    exps = [0.0 if v == -math.inf else math.exp(max(-745.0, min(0.0, v - m))) for v in values]
    total = sum(exps)
    if not math.isfinite(total) or total <= 0:
        raise FloatingPointError("Softmax non fini")
    return [v / total for v in exps]


def _mean(values: Sequence[float]) -> float:
    return sum(values) / max(1, len(values))


def _farthest_indices(X: list[list[float]], features: list[int], count: int, rng: random.Random,
                      residual_scores: Sequence[float] | None = None) -> list[int]:
    """Train-only residual-diverse farthest sampling (or geometric coverage if residuals=None)."""
    n = len(X)
    if count <= 0:
        return []
    if residual_scores is not None:
        max_r = max(residual_scores) if residual_scores else 0.0
        candidates = [i for i, r in enumerate(residual_scores) if r >= max_r - 1e-12]
        first = candidates[rng.randrange(len(candidates))]
    else:
        first = rng.randrange(n)
    selected = [first]
    min_d = [float("inf")] * n
    while len(selected) < min(count, n):
        last = selected[-1]
        for i, x in enumerate(X):
            d = sum((x[j] - X[last][j]) ** 2 for j in features) / max(1, len(features))
            if d < min_d[i]:
                min_d[i] = d
        if residual_scores is None:
            nxt = max((i for i in range(n) if i not in selected), key=lambda i: (min_d[i], -i))
        else:
            nxt = max((i for i in range(n) if i not in selected),
                      key=lambda i: (min_d[i] * (0.25 + float(residual_scores[i])), -i))
        selected.append(nxt)
    while len(selected) < count:
        selected.append(selected[(len(selected)) % len(selected)])
    return selected


@dataclass
class Probe:
    family: str
    features: list[int]
    center: list[float]
    log_width: list[float]
    consequence: list[float]
    log_prior: float
    center_trainable: bool = True


class ESonde:
    """Mixture of local observation probes; no dense/affine/neuron layers."""
    def __init__(self, task: str = "regression", n_probes: int = 12,
                 families: Sequence[str] = ("local",), seed: int = 17,
                 learning_rate: float = 0.025, batch_size: int = 32,
                 epochs: int = 300, patience: int = 35,
                 temperature: float = 1.0, grad_clip: float = 10.0,
                 coverage_threshold: float | None = None,
                 coverage_quantile: float = 0.95, coverage_multiplier: float = 1.5):
        if task not in ("regression", "classification"):
            raise ValueError("task doit être regression ou classification")
        if n_probes < 1:
            raise ValueError("n_probes doit être >= 1")
        fam = tuple(dict.fromkeys(str(x).strip().lower() for x in families if str(x).strip()))
        if not fam or any(x not in ("local", "coverage", "interaction") for x in fam):
            raise ValueError("familles permises: local, coverage, interaction")
        if learning_rate <= 0 or batch_size < 1 or epochs < 1 or patience < 1 or temperature <= 0:
            raise ValueError("hyperparamètres invalides")
        if coverage_threshold is not None and coverage_threshold <= 0:
            raise ValueError("coverage_threshold doit être strictement positif")
        if not (0.5 < coverage_quantile < 1.0) or coverage_multiplier <= 0:
            raise ValueError("calibration de couverture invalide")
        self.task = task
        self.n_probes = int(n_probes)
        self.families = list(fam)
        self.seed = int(seed)
        self.learning_rate = float(learning_rate)
        self.batch_size = int(batch_size)
        self.epochs = int(epochs)
        self.patience = int(patience)
        self.grad_clip = float(grad_clip)
        self.coverage_threshold_override = None if coverage_threshold is None else float(coverage_threshold)
        self.coverage_quantile = float(coverage_quantile)
        self.coverage_multiplier = float(coverage_multiplier)
        self.coverage_threshold = float(coverage_threshold) if coverage_threshold is not None else 3.0
        self.log_temperature = math.log(float(temperature))
        self._initial_log_temperature = self.log_temperature
        self.input_mean: list[float] = []
        self.input_scale: list[float] = []
        self.classes: list[str] = []
        self.feature_names: list[str] = []
        self.probes: list[Probe] = []
        self.output_dim = 1
        self.history: list[dict[str, float]] = []
        self.best_epoch = 0
        self.best_validation_loss: float | None = None
        self.optimizer_m: list[float] = []
        self.optimizer_v: list[float] = []
        self.optimizer_t: list[int] = []
        self.fitted = False
        self._parameter_layout: list[tuple[str, int, int, int]] = []
        self._trainable_mask: list[bool] = []

    @property
    def temperature(self) -> float:
        return math.exp(max(-8.0, min(8.0, self.log_temperature)))

    @property
    def n_features(self) -> int:
        return len(self.input_mean)

    def _standardize_fit(self, X: list[list[float]]) -> list[list[float]]:
        d = len(X[0])
        self.input_mean = [_mean([r[j] for r in X]) for j in range(d)]
        self.input_scale = []
        for j in range(d):
            var = _mean([(r[j] - self.input_mean[j]) ** 2 for r in X])
            self.input_scale.append(max(math.sqrt(var), 1e-8))
        return self._standardize(X)

    def _standardize(self, X: list[list[float]]) -> list[list[float]]:
        if not self.input_mean:
            raise RuntimeError("Normaliseur non initialisé")
        if any(len(r) != len(self.input_mean) for r in X):
            raise ValueError("Nombre de variables différent du modèle")
        out = [[(r[j] - self.input_mean[j]) / self.input_scale[j] for j in range(len(r))] for r in X]
        if any(not math.isfinite(v) for row in out for v in row):
            raise ValueError("Standardisation débordante: valeurs trop extrêmes pour la précision flottante")
        return out

    def _encode_targets(self, y: Sequence[Any]) -> list[list[float]]:
        if len(y) == 0:
            raise ValueError("y vide")
        if self.task == "regression":
            ys = [[float(v)] if not isinstance(v, (list, tuple)) else [float(t) for t in v] for v in y]
            q = len(ys[0])
            if q < 1 or any(len(v) != q for v in ys):
                raise ValueError("Dimensions de cible incohérentes")
            if any(not math.isfinite(v) for row in ys for v in row):
                raise ValueError("Cible non finie")
            self.output_dim = q
            return ys
        labels = [str(v) for v in y]
        self.classes = sorted(set(labels))
        if len(self.classes) < 2:
            raise ValueError("La classification requiert au moins deux classes")
        self.output_dim = len(self.classes)
        index = {c: i for i, c in enumerate(self.classes)}
        return [[1.0 if j == index[label] else 0.0 for j in range(len(self.classes))] for label in labels]

    def _init_probes(self, Xs: list[list[float]], Y: list[list[float]]) -> None:
        rng = random.Random(self.seed)
        d = len(Xs[0])
        pair_features = [(i, j) for i in range(d) for j in range(i + 1, d)]
        by_family: dict[str, list[list[int]]] = {}
        by_family["local"] = [list(range(d))]
        by_family["coverage"] = [list(range(d))]
        by_family["interaction"] = [[a, b] for a, b in pair_features] or [list(range(d))]
        plans: list[tuple[str, list[int]]] = []
        for i in range(self.n_probes):
            f = self.families[i % len(self.families)]
            supports = by_family[f]
            support_i = sum(1 for prior_f, _ in plans if prior_f == f) % len(supports)
            plans.append((f, list(supports[support_i])))
        support_counts: dict[tuple[str, tuple[int, ...]], int] = {}
        support_selections: dict[tuple[str, tuple[int, ...]], list[int]] = {}
        baseline = [_mean([row[o] for row in Y]) for o in range(self.output_dim)]
        residual_norms = [math.sqrt(sum((row[o] - baseline[o]) ** 2 for o in range(self.output_dim))) for row in Y]
        residual_max = max(residual_norms) if residual_norms else 0.0
        residual_scores = [r / max(residual_max, 1e-12) for r in residual_norms]
        for f, features in plans:
            key = (f, tuple(features))
            support_counts[key] = support_counts.get(key, 0) + 1
        for (f, features), count in support_counts.items():
            residual = residual_scores if f in ("local", "interaction") else None
            support_selections[(f, features)] = _farthest_indices(Xs, list(features), count, rng, residual)
        support_seen: dict[tuple[str, tuple[int, ...]], int] = {}
        self.probes = []
        for i, (f, features) in enumerate(plans):
            key = (f, tuple(features))
            occurrence = support_seen.get(key, 0)
            ix = support_selections[key][occurrence]
            support_seen[key] = occurrence + 1
            center = [Xs[ix][j] for j in features]
            distances = []
            for row_idx, x in enumerate(Xs):
                dist = sum((x[j] - center[k]) ** 2 for k, j in enumerate(features)) / len(features)
                distances.append((dist, row_idx))
            neighbours = [idx for _, idx in sorted(distances)[:min(20, len(Xs))]]
            consequence = [_mean([Y[k][o] for k in neighbours]) for o in range(self.output_dim)]
            if self.task == "classification":
                consequence = [math.log(max(1e-5, v)) for v in consequence]
            self.probes.append(Probe(
                family=f, features=features, center=center,
                log_width=[0.0] * len(features), consequence=consequence,
                log_prior=0.0, center_trainable=(f != "coverage")))
        self._build_parameter_layout()

    def _calibrate_coverage_threshold(self, Xs: list[list[float]]) -> float:
        """Train-only support threshold: q-quantile of nearest initial probe distance times margin."""
        nearest = sorted(math.sqrt(max(0.0, min(self._forward_one(x)[2]))) for x in Xs)
        if not nearest:
            raise ValueError("Calibration de couverture impossible sur train vide")
        index = min(len(nearest) - 1, max(0, math.ceil(self.coverage_quantile * len(nearest)) - 1))
        return max(1e-8, nearest[index] * self.coverage_multiplier)

    def _build_parameter_layout(self) -> None:
        self._parameter_layout = []
        self._trainable_mask = []
        offset = 0
        for i, p in enumerate(self.probes):
            for key, n, train in (("center", len(p.center), p.center_trainable),
                                  ("log_width", len(p.log_width), True),
                                  ("consequence", len(p.consequence), True),
                                  ("log_prior", 1, True)):
                self._parameter_layout.append((key, i, offset, offset + n))
                self._trainable_mask.extend([train] * n)
                offset += n
        self._parameter_layout.append(("log_temperature", -1, offset, offset + 1))
        self._trainable_mask.append(True)
        if not self.optimizer_m:
            self.optimizer_m = [0.0] * (offset + 1)
            self.optimizer_v = [0.0] * (offset + 1)
            self.optimizer_t = [0] * (offset + 1)

    def _flatten(self) -> list[float]:
        out: list[float] = []
        for p in self.probes:
            out.extend(p.center); out.extend(p.log_width); out.extend(p.consequence); out.append(p.log_prior)
        out.append(self.log_temperature)
        return out

    def _assign_flat(self, values: Sequence[float]) -> None:
        for key, i, a, b in self._parameter_layout:
            chunk = list(values[a:b])
            if key == "log_temperature": self.log_temperature = chunk[0]
            elif key == "log_prior": self.probes[i].log_prior = chunk[0]
            else: setattr(self.probes[i], key, chunk)

    def _forward_one(self, x: Sequence[float]) -> tuple[list[float], list[float], list[float], list[float]]:
        tau = self.temperature
        distances: list[float] = []
        activations: list[float] = []
        for p in self.probes:
            terms = []
            for k, j in enumerate(p.features):
                width = math.exp(max(-8.0, min(8.0, p.log_width[k])))
                diff = x[j] - p.center[k]
                ratio = diff / width
                if not math.isfinite(ratio):
                    ratio = math.copysign(1e150, diff if diff != 0 else x[j])
                elif abs(ratio) > 1e150:
                    ratio = math.copysign(1e150, ratio)
                terms.append(ratio * ratio)
            d = sum(terms) / len(terms)
            distances.append(min(d, 1e300))
            activations.append(p.log_prior - 0.5 * d / tau)
        weights = _softmax(activations)
        z = [0.0] * self.output_dim
        for i, p in enumerate(self.probes):
            for o in range(self.output_dim): z[o] += weights[i] * p.consequence[o]
        return z, weights, distances, activations

    def _loss_and_grad(self, x: Sequence[float], target: Sequence[float]) -> tuple[float, list[float]]:
        z, weights, distances, _ = self._forward_one(x)
        if self.task == "regression":
            loss = sum((z[o] - target[o]) ** 2 for o in range(self.output_dim)) / self.output_dim
            gz = [2.0 * (z[o] - target[o]) / self.output_dim for o in range(self.output_dim)]
        else:
            probs = _softmax(z)
            loss = -sum(target[o] * math.log(max(probs[o], 1e-15)) for o in range(self.output_dim))
            gz = [probs[o] - target[o] for o in range(self.output_dim)]
        grad = [0.0] * len(self._trainable_mask)
        tau = self.temperature
        off = 0
        for i, p in enumerate(self.probes):
            dot = sum(gz[o] * (p.consequence[o] - z[o]) for o in range(self.output_dim))
            ga = weights[i] * dot
            for k, j in enumerate(p.features):
                diff = x[j] - p.center[k]
                width = math.exp(max(-8.0, min(8.0, p.log_width[k])))
                ratio = diff / width
                if not math.isfinite(ratio) or abs(ratio) > 1e150:
                    ratio = math.copysign(1e150, ratio if math.isfinite(ratio) else diff)
                m = len(p.features)
                grad[off + k] = ga * ratio / (m * tau * width) if p.center_trainable else 0.0
            off += len(p.center)
            for k, j in enumerate(p.features):
                diff = x[j] - p.center[k]
                width = math.exp(max(-8.0, min(8.0, p.log_width[k])))
                ratio = diff / width
                if not math.isfinite(ratio) or abs(ratio) > 1e150:
                    ratio = math.copysign(1e150, ratio if math.isfinite(ratio) else diff)
                grad[off + k] = ga * ratio * ratio / (len(p.features) * tau)
            off += len(p.log_width)
            for o in range(self.output_dim): grad[off + o] = weights[i] * gz[o]
            off += self.output_dim
            grad[off] = ga
            off += 1
        grad[off] = sum(weights[i] * sum(gz[o] * (self.probes[i].consequence[o] - z[o]) for o in range(self.output_dim)) * distances[i] / (2.0 * tau) for i in range(len(self.probes)))
        return loss, grad

    def _evaluate_encoded(self, Xs: list[list[float]], Y: list[list[float]]) -> float:
        losses = [self._loss_and_grad(x, y)[0] for x, y in zip(Xs, Y)]
        return _mean(losses)

    def fit(self, X: Sequence[Sequence[float]], y: Sequence[Any],
            X_valid: Sequence[Sequence[float]] | None = None,
            y_valid: Sequence[Any] | None = None) -> dict[str, Any]:
        raw_X = _matrix(X)
        if len(raw_X) != len(y): raise ValueError("X et y doivent avoir le même nombre de lignes")
        # Calling fit again is a fresh experiment, never an accidental optimizer continuation.
        self.optimizer_m = []; self.optimizer_v = []; self.optimizer_t = []
        self.probes = []; self.history = []; self.classes = []
        self._parameter_layout = []; self._trainable_mask = []
        self.log_temperature = self._initial_log_temperature
        self.fitted = False
        Xs = self._standardize_fit(raw_X)
        Y = self._encode_targets(y)
        if len(Y) != len(Xs): raise ValueError("X et y incompatibles")
        self._init_probes(Xs, Y)
        if self.coverage_threshold_override is None:
            self.coverage_threshold = self._calibrate_coverage_threshold(Xs)
        else:
            self.coverage_threshold = self.coverage_threshold_override
        if X_valid is not None:
            if y_valid is None or len(X_valid) != len(y_valid) or len(X_valid) == 0:
                raise ValueError("Validation X/y incohérente ou vide")
            Xv = self._standardize(_matrix(X_valid, "X_valid"))
            Yv = self._encode_targets_validation(y_valid)
        else:
            Xv, Yv = Xs, Y
        params = self._flatten()
        rng = random.Random(self.seed + 991)
        best_params = list(params); best_m = list(self.optimizer_m); best_v = list(self.optimizer_v); best_t = list(self.optimizer_t)
        best_loss = float("inf"); best_epoch = 0; stale = 0
        self.history = []
        for epoch in range(1, self.epochs + 1):
            order = list(range(len(Xs))); rng.shuffle(order)
            for start in range(0, len(order), self.batch_size):
                batch = order[start:start + self.batch_size]
                grad_sum = [0.0] * len(params)
                for ix in batch:
                    _, g = self._loss_and_grad(Xs[ix], Y[ix])
                    for k, value in enumerate(g): grad_sum[k] += value
                scale = 1.0 / len(batch)
                grad = [v * scale for v in grad_sum]
                norm = math.sqrt(sum(v * v for k, v in enumerate(grad) if self._trainable_mask[k]))
                if self.grad_clip > 0 and norm > self.grad_clip:
                    factor = self.grad_clip / max(norm, _EPS)
                    grad = [v * factor for v in grad]
                for k, g in enumerate(grad):
                    if not self._trainable_mask[k]:
                        continue
                    self.optimizer_t[k] += 1
                    t = self.optimizer_t[k]
                    self.optimizer_m[k] = 0.9 * self.optimizer_m[k] + 0.1 * g
                    self.optimizer_v[k] = 0.999 * self.optimizer_v[k] + 0.001 * g * g
                    mhat = self.optimizer_m[k] / (1.0 - 0.9 ** t)
                    vhat = self.optimizer_v[k] / (1.0 - 0.999 ** t)
                    params[k] -= self.learning_rate * mhat / (math.sqrt(vhat) + 1e-8)
                self._assign_flat(params)
            train_loss = self._evaluate_encoded(Xs, Y)
            val_loss = self._evaluate_encoded(Xv, Yv)
            if not math.isfinite(train_loss) or not math.isfinite(val_loss):
                raise FloatingPointError(f"Perte non finie à l'époque {epoch}")
            self.history.append({"epoch": float(epoch), "train_loss": train_loss, "validation_loss": val_loss})
            if val_loss < best_loss - 1e-10:
                best_loss = val_loss; best_epoch = epoch; best_params = list(params)
                best_m = list(self.optimizer_m); best_v = list(self.optimizer_v); best_t = list(self.optimizer_t); stale = 0
            else:
                stale += 1
            if stale >= self.patience:
                break
        self._assign_flat(best_params)
        self.optimizer_m = best_m; self.optimizer_v = best_v; self.optimizer_t = best_t
        self.best_epoch = best_epoch
        self.best_validation_loss = best_loss
        self.fitted = True
        return {"epochs_run": len(self.history), "best_epoch": best_epoch,
                "best_validation_loss": best_loss,
                "final_train_loss": self.history[-1]["train_loss"],
                "parameter_count": self.parameter_count(),
                "probe_count": len(self.probes)}

    def _encode_targets_validation(self, y: Sequence[Any]) -> list[list[float]]:
        if self.task == "regression":
            result = [[float(v)] if not isinstance(v, (list, tuple)) else [float(t) for t in v] for v in y]
            if any(len(r) != self.output_dim for r in result): raise ValueError("Dimension cible validation incorrecte")
            if any(not math.isfinite(v) for row in result for v in row): raise ValueError("Cible validation non finie")
            return result
        mapping = {c: i for i, c in enumerate(self.classes)}
        result = []
        for label in y:
            s = str(label)
            if s not in mapping: raise ValueError(f"Classe de validation inconnue: {s}")
            result.append([1.0 if j == mapping[s] else 0.0 for j in range(self.output_dim)])
        return result

    def predict_raw(self, X: Sequence[Sequence[float]]) -> list[list[float]]:
        if not self.fitted: raise RuntimeError("Le modèle n'est pas entraîné")
        Xs = self._standardize(_matrix(X))
        return [self._forward_one(x)[0] for x in Xs]

    def predict(self, X: Sequence[Sequence[float]]) -> list[Any]:
        raw = self.predict_raw(X)
        if self.task == "regression": return [r[0] if self.output_dim == 1 else r for r in raw]
        return [self.classes[max(range(len(r)), key=lambda i: r[i])] for r in raw]

    def predict_proba(self, X: Sequence[Sequence[float]]) -> list[list[float]]:
        if self.task != "classification": raise ValueError("predict_proba réservé à la classification")
        return [_softmax(r) for r in self.predict_raw(X)]

    def diagnostics(self, X: Sequence[Sequence[float]]) -> list[dict[str, float | bool]]:
        if not self.fitted: raise RuntimeError("Le modèle n'est pas entraîné")
        Xs = self._standardize(_matrix(X))
        result = []
        for x in Xs:
            _, w, d, _ = self._forward_one(x)
            entropy = -sum(v * math.log(max(v, 1e-15)) for v in w)
            min_distance = math.sqrt(max(0.0, min(d)))
            result.append({"min_probe_distance": min_distance, "max_probe_weight": max(w),
                           "normalized_entropy": entropy / math.log(len(w)) if len(w) > 1 else 0.0,
                           "out_of_support": min_distance > self.coverage_threshold})
        return result

    def parameter_count(self) -> int:
        return sum(len(p.center) + len(p.log_width) + len(p.consequence) + 1 for p in self.probes) + 1

    def trainable_parameter_count(self) -> int:
        return sum(self._trainable_mask)

    def to_dict(self) -> dict[str, Any]:
        if not self.fitted: raise RuntimeError("Modèle non entraîné")
        return {
            "format": "esonde-pure-probe", "version": VERSION,
            "task": self.task, "n_probes": self.n_probes, "families": self.families,
            "seed": self.seed, "learning_rate": self.learning_rate, "batch_size": self.batch_size,
            "epochs": self.epochs, "patience": self.patience, "grad_clip": self.grad_clip,
            "coverage_threshold": self.coverage_threshold,
            "coverage_threshold_override": self.coverage_threshold_override,
            "coverage_quantile": self.coverage_quantile, "coverage_multiplier": self.coverage_multiplier,
            "log_temperature": self.log_temperature,
            "initial_log_temperature": self._initial_log_temperature,
            "input_mean": self.input_mean, "input_scale": self.input_scale,
            "classes": self.classes, "output_dim": self.output_dim, "feature_names": self.feature_names,
            "probes": [p.__dict__ for p in self.probes],
            "history": self.history, "best_epoch": self.best_epoch,
            "best_validation_loss": self.best_validation_loss,
            "optimizer": {"m": self.optimizer_m, "v": self.optimizer_v, "t": self.optimizer_t},
            "parameter_count": self.parameter_count(), "trainable_parameter_count": self.trainable_parameter_count(),
            "architecture_audit": {"uses_affine_layers": False, "uses_dense_layers": False,
                                   "uses_neurons": False, "uses_mlp": False,
                                   "calculation_units": "adaptive_observation_probes"}
        }

    def save(self, path: str | Path) -> None:
        p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(self.to_dict(), ensure_ascii=False, indent=2, allow_nan=False)
        tmp_name = None
        try:
            with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=p.parent,
                                             prefix=p.name + ".", suffix=".tmp", delete=False) as handle:
                tmp_name = handle.name
                handle.write(payload); handle.flush(); os.fsync(handle.fileno())
            os.replace(tmp_name, p)
        finally:
            if tmp_name and os.path.exists(tmp_name):
                os.unlink(tmp_name)

    @classmethod
    def load(cls, path: str | Path) -> "ESonde":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        if data.get("format") != "esonde-pure-probe": raise ValueError("Format de modèle non reconnu")
        audit = data.get("architecture_audit", {})
        if any(audit.get(k) for k in ("uses_affine_layers", "uses_dense_layers", "uses_neurons", "uses_mlp")):
            raise ValueError("Le fichier déclare une opération non pure-sonde")
        obj = cls(task=data["task"], n_probes=data["n_probes"], families=data["families"],
                  seed=data["seed"], learning_rate=data["learning_rate"], batch_size=data["batch_size"],
                  epochs=data["epochs"], patience=data["patience"], grad_clip=data["grad_clip"],
                  coverage_threshold=data.get("coverage_threshold_override", data.get("coverage_threshold")),
                  coverage_quantile=data.get("coverage_quantile", 0.95),
                  coverage_multiplier=data.get("coverage_multiplier", 1.5),
                  temperature=math.exp(data["log_temperature"]))
        obj.coverage_threshold = float(data["coverage_threshold"])
        obj.log_temperature = float(data["log_temperature"])
        obj._initial_log_temperature = float(data.get("initial_log_temperature", data["log_temperature"]))
        if not math.isfinite(obj._initial_log_temperature):
            raise ValueError("Température initiale non finie")
        obj.input_mean = list(map(float, data["input_mean"])); obj.input_scale = list(map(float, data["input_scale"]))
        obj.classes = list(data["classes"]); obj.output_dim = int(data["output_dim"]); obj.feature_names = list(data.get("feature_names", []))
        if obj.feature_names and (len(obj.feature_names) != len(obj.input_mean) or len(set(obj.feature_names)) != len(obj.feature_names)):
            raise ValueError("Manifeste des colonnes invalide")
        if not math.isfinite(obj.log_temperature):
            raise ValueError("Température non finie")
        obj.probes = [Probe(**p) for p in data["probes"]]
        if int(data.get("n_probes", -1)) != len(obj.probes):
            raise ValueError("Nombre de sondes non réconcilié")
        if any(f not in ("local", "coverage", "interaction") for f in data.get("families", [])):
            raise ValueError("Liste de familles invalide")
        if not obj.probes:
            raise ValueError("Le modèle ne contient aucune sonde")
        for index, probe in enumerate(obj.probes):
            if probe.family not in ("local", "coverage", "interaction"):
                raise ValueError(f"Famille de sonde invalide à l'index {index}")
            if not probe.features or len(set(probe.features)) != len(probe.features):
                raise ValueError(f"Support invalide à l'index {index}")
            if any(j < 0 or j >= len(obj.input_mean) for j in probe.features):
                raise ValueError(f"Indice de caractéristique invalide à l'index {index}")
            if len(probe.center) != len(probe.features) or len(probe.log_width) != len(probe.features):
                raise ValueError(f"Dimensions internes incohérentes à l'index {index}")
            if len(probe.consequence) != obj.output_dim:
                raise ValueError(f"Dimension de conséquence invalide à l'index {index}")
            numeric = probe.center + probe.log_width + probe.consequence + [probe.log_prior]
            if any(not math.isfinite(float(v)) for v in numeric):
                raise ValueError(f"Paramètre non fini à l'index {index}")
            if probe.family == "coverage" and probe.center_trainable:
                raise ValueError("Une ancre coverage ne peut pas être marquée entraînable")
        if len(obj.input_mean) == 0 or len(obj.input_scale) != len(obj.input_mean):
            raise ValueError("Normaliseur de dimensions invalides")
        if any(not math.isfinite(v) for v in obj.input_mean + obj.input_scale) or any(v <= 0 for v in obj.input_scale):
            raise ValueError("Statistiques de normalisation invalides")
        if obj.task == "classification" and (obj.output_dim < 2 or len(obj.classes) != obj.output_dim):
            raise ValueError("Registre de classes incompatible")
        if obj.task == "regression" and obj.output_dim < 1:
            raise ValueError("Dimension de régression invalide")
        obj._build_parameter_layout()
        opt = data.get("optimizer", {})
        if not all(key in opt for key in ("m", "v", "t")):
            raise ValueError("État Adam absent ou incomplet")
        obj.optimizer_m = list(map(float, opt["m"])); obj.optimizer_v = list(map(float, opt["v"])); obj.optimizer_t = list(map(int, opt["t"]))
        obj.history = data.get("history", []); obj.best_epoch = int(data.get("best_epoch", 0))
        obj.best_validation_loss = data.get("best_validation_loss")
        obj.fitted = True
        if len(obj.optimizer_m) != len(obj._trainable_mask) or len(obj.optimizer_v) != len(obj._trainable_mask) or len(obj.optimizer_t) != len(obj._trainable_mask):
            raise ValueError("État Adam incomplet ou incompatible")
        if any(not math.isfinite(v) for v in obj.optimizer_m + obj.optimizer_v) or any(v < 0 for v in obj.optimizer_v) or any(v < 0 for v in obj.optimizer_t):
            raise ValueError("État Adam contient des valeurs invalides")
        if obj.parameter_count() != data.get("parameter_count"):
            raise ValueError("Compte de paramètres non réconcilié")
        return obj

    def inspect(self) -> dict[str, Any]:
        return {"format": "esonde-pure-probe", "version": VERSION, "task": self.task,
                "fitted": self.fitted, "n_features": self.n_features, "n_probes": len(self.probes),
                "families": {f: sum(1 for p in self.probes if p.family == f) for f in sorted(set(p.family for p in self.probes))},
                "parameter_count": self.parameter_count(), "trainable_parameter_count": self.trainable_parameter_count(),
                "temperature": self.temperature, "coverage_threshold": self.coverage_threshold,
                "coverage_threshold_source": "explicit" if self.coverage_threshold_override is not None else "train_q95_scaled",
                "best_epoch": self.best_epoch,
                "best_validation_loss": self.best_validation_loss,
                "architecture": "pure probe bank; no affine/dense/neuron/MLP layers"}
