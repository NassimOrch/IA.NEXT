from __future__ import annotations
import argparse, csv, json, sys, time
from pathlib import Path
from .model import ESonde, VERSION
from .data import load_csv, split_indices, subset
from .metrics import regression_metrics, classification_metrics


def _write_json(path, data):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')

def _write_predictions(path, feature_names, rows, preds, probs=None, diagnostics=None):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    headers=list(feature_names)+['prediction']
    if probs is not None: headers += [f'prob_{i}' for i in range(len(probs[0]))]
    if diagnostics: headers += ['min_probe_distance','max_probe_weight','normalized_entropy','out_of_support']
    with p.open('w',encoding='utf-8',newline='') as f:
        w=csv.writer(f);w.writerow(headers)
        for i,row in enumerate(rows):
            values=list(row)+[preds[i]]
            if probs is not None: values += probs[i]
            if diagnostics: values += [diagnostics[i]['min_probe_distance'],diagnostics[i]['max_probe_weight'],diagnostics[i]['normalized_entropy'],diagnostics[i]['out_of_support']]
            w.writerow(values)

def train(args):
    X,y,names=load_csv(args.csv,args.target)
    if args.task=='regression':
        try: y=[float(v) for v in y]
        except ValueError: raise SystemExit('La cible regression doit être numérique')
    tr,va,te=split_indices(y,args.task,args.seed,args.train_fraction,args.valid_fraction)
    model=ESonde(task=args.task,n_probes=args.probes,families=args.families.split(','),seed=args.seed,
                 learning_rate=args.learning_rate,batch_size=args.batch_size,epochs=args.epochs,
                 patience=args.patience,temperature=args.temperature,coverage_threshold=args.coverage_threshold)
    t0=time.perf_counter()
    fit=model.fit(subset(X,tr),subset(y,tr),subset(X,va),subset(y,va))
    train_seconds=time.perf_counter()-t0
    model.feature_names=names
    out=Path(args.model); model.save(out)
    Xtest=subset(X,te); ytest=subset(y,te)
    pred=model.predict(Xtest); diag=model.diagnostics(Xtest)
    if args.task=='regression': metrics=regression_metrics(ytest,pred); probs=None
    else:
        probs=model.predict_proba(Xtest); metrics=classification_metrics(ytest,pred,probs,model.classes)
    report={'format':'esonde-run-report','version':VERSION,'command':'train','task':args.task,
            'source_csv':str(Path(args.csv).resolve()),'target':args.target,'feature_names':names,
            'split_seed':args.seed,'split_counts':{'train':len(tr),'validation':len(va),'test':len(te)},
            'split_indices':{'train':tr,'validation':va,'test':te},'fit':fit,'train_seconds':train_seconds,
            'test_metrics':metrics,'test_support_out_of_support_count':sum(bool(d['out_of_support']) for d in diag),
            'model_path':str(out.resolve()),'test_scored_once_after_fit':True}
    _write_json(out.with_suffix('.report.json'),report)
    _write_predictions(out.with_suffix('.test_predictions.csv'),names,Xtest,pred,probs,diag)
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 0

def _load_for_csv(model_path,csv_path,target=None):
    model=ESonde.load(model_path); X,y,names=load_csv(csv_path,target)
    stored=getattr(model,'feature_names',[])
    if stored and stored!=names: raise ValueError(f'Colonnes incompatibles. Attendu={stored}, reçu={names}')
    return model,X,y,names

def predict(args):
    model,X,y,names=_load_for_csv(args.model,args.csv,None)
    preds=model.predict(X); probs=model.predict_proba(X) if model.task=='classification' else None
    diag=model.diagnostics(X)
    _write_predictions(args.output,names,X,preds,probs,diag)
    print(json.dumps({'rows':len(X),'output':str(Path(args.output).resolve()),'model':model.inspect()},ensure_ascii=False,indent=2))
    return 0

def evaluate(args):
    model,X,y,names=_load_for_csv(args.model,args.csv,args.target)
    preds=model.predict(X); diag=model.diagnostics(X)
    metrics=regression_metrics(y,preds) if model.task=='regression' else classification_metrics(y,preds,model.predict_proba(X),model.classes)
    result={'metrics':metrics,'rows':len(X),'out_of_support_count':sum(bool(d['out_of_support']) for d in diag),'model':model.inspect()}
    print(json.dumps(result,ensure_ascii=False,indent=2)); return 0

def inspect(args):
    print(json.dumps(ESonde.load(args.model).inspect(),ensure_ascii=False,indent=2)); return 0

def demo(args):
    import math, random
    rng=random.Random(args.seed)
    X=[]; y=[]
    for _ in range(480):
        x1=rng.uniform(-3.2,3.2); x2=rng.uniform(-3.2,3.2)
        X.append([x1,x2])
        if args.task=='regression': y.append(math.sin(x1*x2)+0.25*x2)
        else: y.append('1' if (x1*x2)>=0 else '0')
    tr,va,te=split_indices(y,args.task,args.seed)
    model=ESonde(task=args.task,n_probes=args.probes,families=args.families.split(','),seed=args.seed,
                 epochs=args.epochs,patience=max(20,args.epochs//5),batch_size=32,
                 coverage_threshold=args.coverage_threshold)
    fit=model.fit(subset(X,tr),subset(y,tr),subset(X,va),subset(y,va))
    model.feature_names=['x1','x2']; model.save(args.output)
    pred=model.predict(subset(X,te)); diag=model.diagnostics(subset(X,te))
    metrics=regression_metrics(subset(y,te),pred) if args.task=='regression' else classification_metrics(subset(y,te),pred,model.predict_proba(subset(X,te)),model.classes)
    report={'task':args.task,'fit':fit,'test_metrics':metrics,'model':model.inspect(),'note':'Jeu synthétique de démonstration ; ne constitue pas une validation externe.'}
    _write_json(Path(args.output).with_suffix('.report.json'),report)
    print(json.dumps(report,ensure_ascii=False,indent=2)); return 0

def gui(args):
    from .gui import launch
    launch(); return 0

def build_parser():
    p=argparse.ArgumentParser(prog='esonde',description='eSonde v0 — apprentissage par sondes pures, sans MLP/neurones/couches denses')
    p.add_argument('--version',action='version',version=VERSION)
    sp=p.add_subparsers(dest='command',required=True)
    q=sp.add_parser('train',help='entraîner depuis CSV et réserver un test final'); q.add_argument('csv'); q.add_argument('--target',required=True); q.add_argument('--task',choices=['regression','classification'],default='regression'); q.add_argument('--model',default='esonde_model.json'); q.add_argument('--probes',type=int,default=16); q.add_argument('--families',default='local'); q.add_argument('--seed',type=int,default=17); q.add_argument('--epochs',type=int,default=300); q.add_argument('--patience',type=int,default=35); q.add_argument('--batch-size',type=int,default=32); q.add_argument('--learning-rate',type=float,default=.025); q.add_argument('--temperature',type=float,default=1.0); q.add_argument('--coverage-threshold',type=float,default=None); q.add_argument('--train-fraction',type=float,default=.70); q.add_argument('--valid-fraction',type=float,default=.15); q.set_defaults(func=train)
    q=sp.add_parser('predict',help='prédire un CSV sans colonne cible'); q.add_argument('--model',required=True); q.add_argument('--csv',required=True); q.add_argument('--output',default='predictions.csv'); q.set_defaults(func=predict)
    q=sp.add_parser('evaluate',help='évaluer un modèle sur un CSV étiqueté'); q.add_argument('--model',required=True); q.add_argument('--csv',required=True); q.add_argument('--target',required=True); q.set_defaults(func=evaluate)
    q=sp.add_parser('inspect',help='inspecter architecture et état du modèle'); q.add_argument('--model',required=True); q.set_defaults(func=inspect)
    q=sp.add_parser('demo',help='démonstration reproductible sur données synthétiques'); q.add_argument('--task',choices=['regression','classification'],default='regression'); q.add_argument('--output',default='esonde_demo.json'); q.add_argument('--probes',type=int,default=16); q.add_argument('--families',default='local'); q.add_argument('--seed',type=int,default=17); q.add_argument('--epochs',type=int,default=180); q.add_argument('--coverage-threshold',type=float,default=None); q.set_defaults(func=demo)
    q=sp.add_parser('gui',help='ouvrir interface graphique Tkinter'); q.set_defaults(func=gui)
    return p

def main(argv=None):
    parser=build_parser(); args=parser.parse_args(argv)
    try: return args.func(args)
    except Exception as e:
        print(f'ERREUR eSonde: {type(e).__name__}: {e}',file=sys.stderr); return 2

if __name__=='__main__': raise SystemExit(main())
