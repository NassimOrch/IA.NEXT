"""Optional Tk desktop UI for training, prediction, evaluation and inspection.

The GUI calls the same pure-probe implementation as the CLI. Long operations run
in a worker thread; all widget updates remain on Tk's main thread.
"""
from __future__ import annotations

import csv
import json
import queue
import threading
import time
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from .model import ESonde
from .data import load_csv, split_indices, subset
from .metrics import regression_metrics, classification_metrics


def _write_predictions(path: str, feature_names, rows, preds, probabilities=None, diagnostics=None):
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    headers = list(feature_names) + ["prediction"]
    if probabilities is not None:
        headers += [f"prob_{name}" for name in range(len(probabilities[0]))]
    if diagnostics:
        headers += ["min_probe_distance", "max_probe_weight", "normalized_entropy", "out_of_support"]
    with target.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(headers)
        for index, row in enumerate(rows):
            values = list(row) + [preds[index]]
            if probabilities is not None:
                values.extend(probabilities[index])
            if diagnostics:
                diag = diagnostics[index]
                values.extend([diag["min_probe_distance"], diag["max_probe_weight"],
                               diag["normalized_entropy"], diag["out_of_support"]])
            writer.writerow(values)


def launch():
    root = tk.Tk()
    root.title("eSonde v0 — interface graphique")
    root.geometry("980x760")
    root.minsize(820, 640)

    csv_var = tk.StringVar()
    target_var = tk.StringVar()
    task_var = tk.StringVar(value="regression")
    probes_var = tk.StringVar(value="16")
    families_var = tk.StringVar(value="local,coverage,interaction")
    epochs_var = tk.StringVar(value="300")
    patience_var = tk.StringVar(value="35")
    batch_var = tk.StringVar(value="32")
    lr_var = tk.StringVar(value="0.025")
    seed_var = tk.StringVar(value="17")
    model_var = tk.StringVar(value="esonde_model.json")
    output_var = tk.StringVar(value="esonde_predictions.csv")
    status_var = tk.StringVar(value="Prêt — aucune opération en cours.")
    events: queue.Queue = queue.Queue()
    state = {"busy": False}

    outer = ttk.Frame(root, padding=12)
    outer.pack(fill="both", expand=True)
    outer.columnconfigure(1, weight=1)
    outer.rowconfigure(10, weight=1)

    def browse_csv():
        selected = filedialog.askopenfilename(filetypes=[("CSV", "*.csv"), ("Tous fichiers", "*.*")])
        if selected:
            csv_var.set(selected)

    def browse_model():
        selected = filedialog.asksaveasfilename(defaultextension=".json",
                                                filetypes=[("Modèle eSonde", "*.json")])
        if selected:
            model_var.set(selected)

    def browse_output():
        selected = filedialog.asksaveasfilename(defaultextension=".csv",
                                                filetypes=[("CSV", "*.csv")])
        if selected:
            output_var.set(selected)

    ttk.Label(outer, text="Fichier CSV").grid(row=0, column=0, sticky="w", pady=3)
    ttk.Entry(outer, textvariable=csv_var).grid(row=0, column=1, sticky="ew", pady=3)
    ttk.Button(outer, text="Parcourir…", command=browse_csv).grid(row=0, column=2, padx=5)
    ttk.Label(outer, text="Colonne cible (vide pour prédire)").grid(row=1, column=0, sticky="w", pady=3)
    ttk.Entry(outer, textvariable=target_var).grid(row=1, column=1, sticky="ew", pady=3)
    ttk.Label(outer, text="Tâche").grid(row=2, column=0, sticky="w", pady=3)
    ttk.Combobox(outer, textvariable=task_var, values=["regression", "classification"],
                 state="readonly", width=18).grid(row=2, column=1, sticky="w", pady=3)

    settings = ttk.LabelFrame(outer, text="Paramètres d'entraînement", padding=8)
    settings.grid(row=3, column=0, columnspan=3, sticky="ew", pady=8)
    fields = [
        ("Nombre de sondes", probes_var), ("Familles", families_var),
        ("Époques max.", epochs_var), ("Patience", patience_var),
        ("Taille minibatch", batch_var), ("Taux d'apprentissage", lr_var), ("Graine", seed_var),
    ]
    for idx, (label, variable) in enumerate(fields):
        row, col = divmod(idx, 4)
        ttk.Label(settings, text=label).grid(row=row * 2, column=col, sticky="w", padx=4)
        ttk.Entry(settings, textvariable=variable, width=18).grid(row=row * 2 + 1, column=col,
                                                                  sticky="ew", padx=4, pady=(0, 4))
        settings.columnconfigure(col, weight=1)

    ttk.Label(outer, text="Fichier modèle JSON").grid(row=4, column=0, sticky="w", pady=3)
    ttk.Entry(outer, textvariable=model_var).grid(row=4, column=1, sticky="ew", pady=3)
    ttk.Button(outer, text="Choisir…", command=browse_model).grid(row=4, column=2, padx=5)
    ttk.Label(outer, text="Fichier de prédictions CSV").grid(row=5, column=0, sticky="w", pady=3)
    ttk.Entry(outer, textvariable=output_var).grid(row=5, column=1, sticky="ew", pady=3)
    ttk.Button(outer, text="Choisir…", command=browse_output).grid(row=5, column=2, padx=5)

    output = tk.Text(outer, wrap="word", height=20)
    output.grid(row=10, column=0, columnspan=3, sticky="nsew", pady=(8, 4))
    status = ttk.Label(outer, textvariable=status_var)
    status.grid(row=11, column=0, columnspan=3, sticky="w", pady=4)

    buttons = ttk.Frame(outer)
    buttons.grid(row=6, column=0, columnspan=3, sticky="w", pady=8)
    action_buttons = []

    def log(message):
        output.insert("end", str(message) + "\n")
        output.see("end")

    def _run_worker(label, function):
        if state["busy"]:
            return
        # Tk variables are captured on the main thread; worker code sees plain values only.
        config = {"csv": csv_var.get(), "target": target_var.get(), "task": task_var.get(),
                  "probes": probes_var.get(), "families": families_var.get(),
                  "epochs": epochs_var.get(), "patience": patience_var.get(),
                  "batch_size": batch_var.get(), "learning_rate": lr_var.get(),
                  "seed": seed_var.get(), "model": model_var.get(), "output": output_var.get()}
        state["busy"] = True
        status_var.set(f"{label} en cours…")
        for button in action_buttons:
            button.configure(state="disabled")

        def target():
            try:
                result = function(config)
                events.put((True, label, result))
            except Exception as exc:  # surfaced on UI thread
                events.put((False, label, f"{type(exc).__name__}: {exc}"))

        threading.Thread(target=target, daemon=True).start()
        root.after(100, _poll_events)

    def _poll_events():
        try:
            success, label, result = events.get_nowait()
        except queue.Empty:
            if state["busy"]:
                root.after(100, _poll_events)
            return
        state["busy"] = False
        for button in action_buttons:
            button.configure(state="normal")
        if success:
            status_var.set(f"{label} terminé.")
            log(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            status_var.set(f"Erreur pendant : {label}.")
            log(f"ERREUR {label}: {result}")
            messagebox.showerror(f"eSonde — {label}", str(result))

    def do_train(config):
        if not config["csv"] or not config["target"]:
            raise ValueError("Choisir un CSV et saisir la colonne cible.")
        X, y, names = load_csv(config["csv"], config["target"])
        task = config["task"]
        if task == "regression":
            y = [float(value) for value in y]
        seed = int(config["seed"])
        tr, va, te = split_indices(y, task, seed)
        model = ESonde(task=task, n_probes=int(config["probes"]),
                       families=[part.strip() for part in config["families"].split(",") if part.strip()],
                       seed=seed, epochs=int(config["epochs"]), patience=int(config["patience"]),
                       batch_size=int(config["batch_size"]), learning_rate=float(config["learning_rate"]))
        started = time.perf_counter()
        fit = model.fit(subset(X, tr), subset(y, tr), subset(X, va), subset(y, va))
        fit_seconds = time.perf_counter() - started
        model.feature_names = names
        model.save(config["model"])
        X_test, y_test = subset(X, te), subset(y, te)
        predictions = model.predict(X_test)
        diagnostics = model.diagnostics(X_test)
        if task == "regression":
            probabilities = None
            metrics = regression_metrics(y_test, predictions)
        else:
            probabilities = model.predict_proba(X_test)
            metrics = classification_metrics(y_test, predictions, probabilities, model.classes)
        report = {
            "format": "esonde-gui-report", "task": task, "target": config["target"],
            "feature_names": names, "split_seed": seed,
            "split_counts": {"train": len(tr), "validation": len(va), "test": len(te)},
            "fit_seconds": fit_seconds, "fit": fit, "test_metrics": metrics,
            "out_of_support_count": sum(bool(row["out_of_support"]) for row in diagnostics),
            "model": model.inspect(),
            "note": "Le test n'a pas participé à l'optimisation ; rapport descriptif de ce split.",
        }
        report_path = Path(config["model"]).with_suffix(".report.json")
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        return {"model": str(Path(config["model"]).resolve()),
                "report": str(report_path.resolve()), **report}

    def do_predict(config):
        model = ESonde.load(config["model"])
        X, _, names = load_csv(config["csv"], None)
        if model.feature_names and model.feature_names != names:
            raise ValueError(f"Colonnes incompatibles. Attendu={model.feature_names}, reçu={names}")
        predictions = model.predict(X)
        probabilities = model.predict_proba(X) if model.task == "classification" else None
        diagnostics = model.diagnostics(X)
        _write_predictions(config["output"], names, X, predictions, probabilities, diagnostics)
        return {"rows": len(X), "output": str(Path(config["output"]).resolve()),
                "out_of_support_count": sum(bool(row["out_of_support"]) for row in diagnostics),
                "model": model.inspect()}

    def do_evaluate(config):
        model = ESonde.load(config["model"])
        if not config["target"]:
            raise ValueError("Saisir la colonne cible pour évaluer.")
        X, y, names = load_csv(config["csv"], config["target"])
        if model.feature_names and model.feature_names != names:
            raise ValueError(f"Colonnes incompatibles. Attendu={model.feature_names}, reçu={names}")
        if model.task == "regression":
            y = [float(value) for value in y]
            metrics = regression_metrics(y, model.predict(X))
        else:
            metrics = classification_metrics(y, model.predict(X), model.predict_proba(X), model.classes)
        diagnostics = model.diagnostics(X)
        return {"rows": len(X), "metrics": metrics,
                "out_of_support_count": sum(bool(row["out_of_support"]) for row in diagnostics),
                "model": model.inspect()}

    def do_inspect(config):
        return ESonde.load(config["model"]).inspect()

    actions = [
        ("Entraîner", "Entraînement", do_train),
        ("Prédire CSV", "Prédiction", do_predict),
        ("Évaluer CSV", "Évaluation", do_evaluate),
        ("Inspecter modèle", "Inspection", do_inspect),
    ]
    for label, title, function in actions:
        button = ttk.Button(buttons, text=label,
                            command=lambda t=title, fn=function: _run_worker(t, fn))
        button.pack(side="left", padx=4)
        action_buttons.append(button)

    root.mainloop()
