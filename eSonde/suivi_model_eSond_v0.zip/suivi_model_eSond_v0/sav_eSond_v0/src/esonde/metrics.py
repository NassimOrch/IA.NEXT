"""Transparent evaluation metrics; no external numerical packages."""
from __future__ import annotations
import math

def regression_metrics(y_true, y_pred):
    if len(y_true)!=len(y_pred) or not y_true: raise ValueError('Échantillons incompatibles ou vides')
    pairs=[(float(a),float(b)) for a,b in zip(y_true,y_pred)]
    err=[b-a for a,b in pairs]
    mae=sum(abs(e) for e in err)/len(err)
    rmse=math.sqrt(sum(e*e for e in err)/len(err))
    mean=sum(a for a,_ in pairs)/len(pairs)
    sd=math.sqrt(sum((a-mean)**2 for a,_ in pairs)/len(pairs))
    return {'mae':mae,'rmse':rmse,'nmae':mae/max(sd,1e-12),'r2':1-sum(e*e for e in err)/max(sum((a-mean)**2 for a,_ in pairs),1e-12),'n':len(pairs)}

def classification_metrics(y_true, predictions, probabilities, classes):
    if not (len(y_true)==len(predictions)==len(probabilities)) or not y_true: raise ValueError('Échantillons incompatibles ou vides')
    acc=sum(str(a)==str(b) for a,b in zip(y_true,predictions))/len(y_true)
    eps=1e-15; loss=0.0
    for truth, probs in zip(y_true,probabilities):
        idx=classes.index(str(truth)); loss-=math.log(max(eps,float(probs[idx])))
    per={c:{'tp':0,'fp':0,'fn':0} for c in classes}
    for a,b in zip(y_true,predictions):
        for c in classes:
            if str(a)==c and str(b)==c: per[c]['tp']+=1
            elif str(a)!=c and str(b)==c: per[c]['fp']+=1
            elif str(a)==c and str(b)!=c: per[c]['fn']+=1
    f1=[]
    for c in classes:
        v=per[c]; den=2*v['tp']+v['fp']+v['fn']; f1.append(2*v['tp']/den if den else 0.0)
    return {'accuracy':acc,'macro_f1':sum(f1)/len(f1),'log_loss':loss/len(y_true),'n':len(y_true)}
