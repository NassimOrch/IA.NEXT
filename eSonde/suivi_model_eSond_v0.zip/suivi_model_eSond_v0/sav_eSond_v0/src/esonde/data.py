"""CSV and split utilities: stdlib only; splits recorded explicitly."""
from __future__ import annotations
import csv, random
from pathlib import Path
from typing import Any


def load_csv(path: str | Path, target: str | None = None):
    with Path(path).open('r', encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            raise ValueError('CSV sans en-tête')
        names = list(reader.fieldnames)
        if len(set(names)) != len(names): raise ValueError('Colonnes dupliquées dans le CSV')
        if target is not None and target not in names: raise ValueError(f'Cible absente: {target}')
        feature_names = [n for n in names if n != target]
        if not feature_names: raise ValueError('Aucune colonne de caractéristique')
        X, y = [], []
        for line, row in enumerate(reader, 2):
            vals=[]
            for name in feature_names:
                cell=(row.get(name) or '').strip()
                if not cell: raise ValueError(f'Valeur manquante, ligne {line}, colonne {name}')
                try: v=float(cell)
                except ValueError as e: raise ValueError(f'Caractéristique non numérique, ligne {line}, colonne {name}') from e
                vals.append(v)
            X.append(vals)
            if target is not None:
                raw=(row.get(target) or '').strip()
                if not raw: raise ValueError(f'Cible manquante, ligne {line}')
                y.append(raw)
        if not X: raise ValueError('CSV sans lignes de données')
        return X, y if target is not None else None, feature_names


def split_indices(y: list[Any], task: str, seed: int=17, train_fraction: float=.70, valid_fraction: float=.15):
    if not (0.1 <= train_fraction <= .9 and 0.05 <= valid_fraction < .5 and train_fraction+valid_fraction < 1):
        raise ValueError('Fractions train/validation invalides')
    rng=random.Random(seed)
    groups={}
    if task == 'classification':
        for i,label in enumerate(y): groups.setdefault(str(label),[]).append(i)
    else: groups={'__all__':list(range(len(y)))}
    train=[]; valid=[]; test=[]
    for label, ids in sorted(groups.items()):
        rng.shuffle(ids)
        n=len(ids)
        if n < 3 and task == 'classification': raise ValueError(f'Classe {label} trop petite pour split train/validation/test')
        nt=max(1,int(round(n*train_fraction)))
        nv=max(1,int(round(n*valid_fraction)))
        if nt+nv>=n: nv=max(1,n-nt-1)
        if nt+nv>=n: nt=max(1,n-2); nv=1
        train += ids[:nt]; valid += ids[nt:nt+nv]; test += ids[nt+nv:]
    rng.shuffle(train); rng.shuffle(valid); rng.shuffle(test)
    if not train or not valid or not test: raise ValueError('Split vide')
    return train,valid,test


def subset(items, indices): return [items[i] for i in indices]
