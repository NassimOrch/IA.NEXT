# suivi_model_eSond_v0 — suivi, preuves et sauvegarde

Ce paquet contient les registres de phases, chemins canoniques, checklists d'erreurs, preuves, historique, le rapport d'incident signé et le snapshot `sav_eSond_v0`.

- `chemins_eSond_v0.json` : chemins workspace, sources, savepoint, rapports et archives complémentaires.
- `checklist_de_travail_eSond_v0.json` : phases P0–P6 et critères/evidences.
- `checklist_erreurs_no_model.json` : incidents d'accès, intégrité, sérialisation, documentation et packaging.
- `checklist_erreurs_model.json` : pureté architecturale, optimisation, extrapolation et statut comparatif.
- `preuves_eSond_v0.json` : résultats vérifiés et limites ouvertes.
- `execution_history_eSond_v0.json` : journal des commandes, incidents et résultats.
- `incident/` : rapport Markdown/PDF, signatures Ed25519, clé publique et manifestes de vérification.
- `sav_eSond_v0/` : copie actualisée du workspace du modèle et des preuves de suivi.

Les 7 142 artefacts historiques `.pt`/JOBLIB/Parquet sont livrés dans quatre archives complémentaires séparées, chacune sous 200 MiB.

Avant toute nouvelle commande, consulter les quatre registres obligatoires. Après chaque exécution, consigner commande, statut, résultat, erreur et preuves ; mettre à jour les documents et le savepoint. Un PASS d'intégrité n'est pas une revendication de performance scientifique.
