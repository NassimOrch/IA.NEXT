# Rapport eSonde_v0 — [identifiant du run]

## 1. Description
Objectif, question scientifique, domaine, dates, sources, version du code et périmètre.

## 2. Architecture
Familles de sondes, nombre de sondes, supports, état local/global, paramètres entraînables, normalisation, absence ou présence de chaque composant interdit.

## 3. Pipeline complet
Données, provenance, prétraitement, partitions, graine, initialisation, entraînement, validation, gel, test, profilage, sérialisation.

## 4. Commandes d'exécution
Commandes complètes, répertoire courant, version Python, environnement, code retour.

## 5. Résultats
Métriques exactes, métriques par graine, intervalles, temps, latences, mémoire, tailles, erreurs et fichiers produits. Non mesuré = explicitement « non mesuré ».

## 6. Interprétation des résultats
Résultats descriptifs vs confirmatoires, comparaison appariée, dépendance à la tâche/régime, incertitude et limites de portée.

## 7. Conséquences
### 7.1 Théoriques
Propriétés soutenues ou non soutenues par les résultats.
### 7.2 Conceptuelles
Implications sur les familles de sondes et leur composition.
### 7.3 Opérationnelles
Latence, ressources, déploiement, reproductibilité, risques.

## 8. Conclusions
Réponse bornée à la question testée ; aucune extrapolation non soutenue.

## 9. Statut du modèle
`PASS` / `PARTIAL` / `INCOMPLETE` / `NOT_RUN` par critère, avec preuve pointée. Un PASS procédural ne signifie pas supériorité scientifique.
