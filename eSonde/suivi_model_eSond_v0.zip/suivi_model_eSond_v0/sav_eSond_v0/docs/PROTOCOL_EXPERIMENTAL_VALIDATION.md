# Protocole expérimental de validation — eSonde_v0

## 1. Objet et statut

Ce protocole fixe les mesures à exécuter avant toute revendication de généralisation ou de comparaison. Il ne suppose ni réussite ni échec d'eSonde. Le jeu synthétique livré sert uniquement à vérifier le pipeline et à donner des exemples déterministes.

**État :** protocole défini ; une ablation exploratoire v2 (24 runs) et une ré-audit v3 du diagnostic hors-support (24 runs) ont été exécutés sur trois fonctions synthétiques et deux graines. Aucune étude confirmatoire multi-jeu/20 graines avec comparateur MLP n'est déclarée terminée.

## 2. Questions expérimentales

1. Quelle famille de sondes (local, coverage, interaction pairwise) contribue à chaque tâche ?
2. La combinaison hybride apporte-t-elle une qualité supérieure à budget paramétrique égal, ou apporte-t-elle seulement une couverture/coût différents ?
3. Quelles sont les performances sous interpolation, frontière, extrapolation et décalage de distribution ?
4. Quelles sont les relations qualité–nombre de sondes–coût d'entraînement–latence–mémoire ?
5. Les différences sont-elles stables entre graines et jeux, et les intervalles excluent-ils un effet nul ou une marge de non-infériorité pré-déclarée ?

## 3. Protocoles de partition

- Définir les jeux et les fonctions cibles avant les runs.
- Créer un manifeste de données (taille, colonnes, hash, licence, provenance).
- Conserver un test extérieur intouché jusqu'au gel de code, hyperparamètres et variantes.
- Ajuster la standardisation et l'initialisation sur train seulement ; valider les colonnes et classes.
- Utiliser les mêmes indices train/validation/test pour toutes les variantes comparées.
- Pour chaque graine, enregistrer les indices, la commande, la configuration, l'environnement et le SHA-256.
- En validation croisée, les transformations et sélection de supports sont refaites dans le fold train ; aucune information du fold validation/test ne fuit dans le modèle.

## 4. Variantes minimales

| ID | Familles | Rôle |
|---|---|---|
| A | local | cœur adaptatif seul |
| B | coverage | témoin de couverture à ancres fixes |
| C | interaction | paires seulement |
| D | local + coverage | hybridation local/global |
| E | local + interaction | hybridation locale/relationnelle |
| F | local + coverage + interaction | hybride complet v0 |

Pour chaque variante, balayer au moins 4 budgets de sondes. Les budgets de paramètres entraînables doivent être rapportés ; un nombre de sondes égal n'implique pas un nombre de paramètres identique. L'initialisation, la température et la capacité sont des facteurs expérimentaux, pas des constantes à optimiser sur le test.

## 5. Comparateurs

Un MLP peut être utilisé comme comparateur externe uniquement ; il n'est pas importé, lié ou embarqué dans eSonde. Comparaisons distinctes : (i) paramètres entraînables appariés à ±1 % ; (ii) budget temps/latence ; (iii) même pipeline de données et même split. Publier les hyperparamètres et implémentations du comparateur, sans ajustement caché. Ajouter un comparateur non neuronal (p. ex. RBF classique / régression locale) lorsque la question l'exige.

## 6. Graines, taille et inférence

- Phase exploratoire : au moins 5 graines distinctes.
- Phase confirmatoire : au moins 20 graines par tâche/fonction, après gel de l'architecture.
- Publier moyennes, médianes, écarts-types, intervalles de confiance appariés et résultats par graine.
- Pour plusieurs contrastes, corriger la multiplicité (Holm ou méthode pré-déclarée).
- Conserver les échecs, non-convergences et runs incomplets ; ne jamais filtrer après coup selon la métrique.

## 7. Régimes de généralisation

Séparer au minimum :

- interpolation : test pris dans le support de distribution train ;
- frontière : observations proches des limites de support ;
- extrapolation : valeurs hors intervalles train ;
- shift : transformation de marginales ou de dépendance fixée avant exécution ;
- composition : graphes/relations composées qui ne sont pas présents à l'identique au train.

Pour chaque observation test, publier distance minimale aux sondes, poids maximal, entropie de coordination et indicateur hors-support. Ces diagnostics décrivent la couverture ; ils ne sont pas des probabilités calibrées d'erreur.

## 8. Mesures requises

**Qualité :** MAE, RMSE, NMAE, R² (régression) ; accuracy, macro-F1, log-loss, calibration (classification).  
**Coût :** temps d'entraînement, latence p50/p95, batch 1 et batch élevé, débit, mémoire RSS/VRAM, stockage, FLOPs/opérations ou proxy documenté, énergie/joules si instrumentée.  
**Qualité statistique :** intervalles appariés, taille d'effet, non-infériorité/supériorité pré-déclarée, correction des tests multiples.

## 9. Contrôles d'intégrité et de fuite

- Vérifier les hash des données, sources, scripts et checkpoints avant et après run.
- Le test n'intervient ni dans normalisation, initialisation, sélection, early stopping, calibration, ni dans les paramètres.
- Les prédictions test sont écrites une fois pour chaque version gelée ; toute réévaluation de commande sur ce test doit être identifiée comme audit de reproductibilité et ne peut guider aucun nouveau run.
- Les checkpoints historiques `.pt` ne sont jamais chargés dans eSonde_v0 ; la sérialisation native eSonde est JSON.
- Conserver les états Adam, compteurs par paramètre, état aléatoire et checkpoint de meilleure validation.

## 10. Critères de décision

Aucune variante n'est promue comme meilleure sur une seule métrique. Un choix de modèle doit considérer (a) qualité par régime, (b) incertitude entre graines, (c) coût total, (d) pureté architecturale, (e) stabilité et (f) simplicité de réplication. Les marges de non-infériorité et critères de supériorité sont fixés avant le test. Une absence de preuve est rapportée comme « indéterminé / non mesuré », pas comme zéro ou échec.

## 11. Exécution actuelle

### 11.1 Ablation exploratoire V2

24 runs : 3 fonctions synthétiques × 2 graines (7, 19) × 4 configurations (`local`, `coverage`, `interaction`, hybride complet). Les partitions sont partagées entre familles ; 180 observations train, 60 validation, 90 interpolation et 90 extrapolation. Les budgets entraînables sont appariés à 96–97 paramètres. Protocole : `../../audit/ablation_v0/PRE_REGISTRATION_V2.md`; données ligne par ligne : `../../audit/ablation_v0/ablation_runs_v2.jsonl` et CSV ; synthèse : `../../audit/ablation_v0/ablation_summary_v2.json`.

Les RMSE moyennes interpolation/extrapolation sont respectivement : local 0,04130 / 1,50995 ; coverage 0,04052 / 1,53576 ; interaction 0,04068 / 1,61487 ; hybride 0,04560 / 1,62842. Les R² d'extrapolation moyens sont négatifs pour les quatre familles. Ce pilote descriptif à deux graines ne classe pas les familles universellement et ne constitue pas une comparaison MLP.

### 11.2 Ré-audit V3 du diagnostic de support

24 mêmes configurations, fonctions, graines et partitions, avec seuil train-only q95 × 1,5. Les mesures prédictives par run (MAE, RMSE, R²) sont identiques à V2 ; seuls le diagnostic `out_of_support` et les temps d'exécution observés changent. Fractions extrapolation signalées en moyenne : local 0,67963 ; coverage 0,99630 ; interaction 0,63704 ; hybride 0,32593. Le diagnostic géométrique n'est pas une probabilité d'erreur. Protocole : `../../audit/ablation_v0/PRE_REGISTRATION_V3.md`; synthèse : `../../audit/ablation_v0/ablation_summary_v3.json` et comparaison V2/V3 : `../../audit/ablation_v0/v2_v3_comparison.json`.

### 11.3 Portée scientifique restante

Les exécutions CLI/tests et données synthétiques sont des validations de fonctionnement et des pilotes locaux. Elles ne constituent pas une expérience confirmatoire, une démonstration de généralisation réelle ou une comparaison appariée avec un MLP. Le protocole confirmatoire (au moins 20 graines après gel du code, comparateur externe pré-enregistré, métriques/coûts complets et intervalles appariés) reste ouvert.
