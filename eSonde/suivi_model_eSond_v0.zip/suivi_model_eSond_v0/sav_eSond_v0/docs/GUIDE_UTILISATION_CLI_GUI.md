# Guide complet CLI et interface graphique — eSonde_v0

## 1. Prérequis et installation

- Python 3.10 ou plus récent.
- Aucune dépendance Python tierce.
- Tkinter est facultatif et nécessaire uniquement pour l'interface desktop.

Décompresser `Dmodel_eSond_v0.zip`. Aucun environnement virtuel, paquet pip ou accès réseau n'est nécessaire. Le runtime Python lui-même doit être installé par le système ; il n'est pas embarqué dans ce ZIP multi-plateforme.

Vérifier :

```bash
python --version
python run_esonde.py --version
```

Sous Windows, utiliser `py` si nécessaire. Sur POSIX, le lanceur est `./run_esonde.sh`.

## 2. Données CSV

Le fichier doit avoir une seule ligne d'en-tête, des noms de colonnes uniques, des variables numériques, finies et sans cellules manquantes. Pour l'entraînement/évaluation, la cible est explicitement indiquée. Les cibles de régression sont numériques ; les labels de classification sont des chaînes. Aucune imputation ni conversion catégorielle silencieuse n'est effectuée.

Exemple de régression :

```csv
age,temperature,cible
20,18.2,0.35
32,21.1,0.71
41,19.4,0.62
```

Exemple de classification :

```csv
mesure_a,mesure_b,classe
0.12,0.83,normal
0.91,0.14,anomalie
```

## 3. CLI — aide et démonstration

```bash
python run_esonde.py --help
python run_esonde.py --version
python run_esonde.py demo --task regression --output demo_reg.json --seed 21
python run_esonde.py demo --task classification --output demo_cls.json --seed 21
```

Les démos génèrent elles-mêmes des données synthétiques ; elles testent le chemin d'exécution et ne constituent pas une validation externe.

## 4. CLI — entraîner

```bash
python run_esonde.py train donnees.csv --target cible --task regression \
  --model modele.json --probes 18 --families local,coverage,interaction \
  --epochs 300 --patience 35 --batch-size 32 --learning-rate 0.025 \
  --temperature 1.0 --seed 17
```

Paramètres :

- `--task` : `regression` ou `classification`.
- `--probes` : nombre total de sondes.
- `--families` : familles séparées par virgule : `local`, `coverage`, `interaction`.
- `--epochs`, `--patience`, `--batch-size`, `--learning-rate`, `--temperature`, `--coverage-threshold` (override facultatif ; sinon calibration q95 train-only × 1,5), `--seed`.
- `--train-fraction`, `--valid-fraction` : train et validation ; le reste est test.

Le split par défaut est 70 % / 15 % / 15 %. Le normaliseur et les sondes sont initialisés à partir du train uniquement. La validation sélectionne l'époque ; le test est réservé au score après entraînement.

Fichiers produits : modèle JSON, rapport JSON, prédictions test CSV. Le rapport documente commandes, seed, dimensions et mesures.

## 5. CLI — prédire, évaluer et inspecter

Prédiction sur des variables sans cible :

```bash
python run_esonde.py predict --model modele.json --csv nouveaux.csv --output predictions.csv
```

Évaluer un jeu étiqueté, sans mise à jour des poids :

```bash
python run_esonde.py evaluate --model modele.json --csv verification.csv --target cible
```

Inspection :

```bash
python run_esonde.py inspect --model modele.json
```

Les colonnes doivent avoir les mêmes noms et le même ordre que pendant l'entraînement, sauf modèle sauvegardé sans manifeste de colonnes via l'API Python directe.

## 6. Interface graphique

Démarrer :

```bash
python run_esonde.py gui
```

### Entraînement

1. Choisir le CSV avec **Parcourir…**.
2. Entrer la colonne cible.
3. Sélectionner `regression` ou `classification`.
4. Régler sondes, familles, époques, patience, minibatch, taux d'apprentissage et graine.
5. Définir le chemin du modèle JSON.
6. Cliquer **Entraîner**.
7. Lire le rapport dans la zone de sortie ; modèle et rapport sont enregistrés.

### Prédiction

1. Choisir un CSV sans la colonne cible.
2. Sélectionner le modèle JSON entraîné.
3. Définir le chemin de sortie CSV.
4. Cliquer **Prédire CSV**.
5. La sortie contient colonnes d'entrée, prédiction, probabilités (classification) et diagnostics de couverture.

### Évaluation

1. Choisir un CSV étiqueté et renseigner la cible.
2. Sélectionner le modèle JSON.
3. Cliquer **Évaluer CSV**.
4. Les métriques sont calculées sans réentraînement.

### Inspection

Choisir un modèle et cliquer **Inspecter modèle** pour obtenir tâche, dimensions, familles, paramètres, température et époque validée.

Les opérations sont exécutées dans un thread de travail pour préserver la boucle graphique. L'annulation d'une opération en cours et la modification d'un entraînement existant ne sont pas incluses en v0. Tkinter nécessite un bureau local ; sur machine headless, le CLI fonctionne.

## 7. Familles et ablations

Exécuter séparément les familles sur le même CSV, même partition et même graine :

```bash
python run_esonde.py train donnees.csv --target cible --task regression --families local --model local.json --seed 17
python run_esonde.py train donnees.csv --target cible --task regression --families coverage --model coverage.json --seed 17
python run_esonde.py train donnees.csv --target cible --task regression --families interaction --model interaction.json --seed 17
python run_esonde.py train donnees.csv --target cible --task regression --families local,coverage,interaction --model hybrid.json --seed 17
```

Les nombres de paramètres peuvent différer selon la dimension des supports et la famille. Les comparer à budgets appariés ou publier explicitement les différences. Un seul seed n'est pas une conclusion générale.

## 8. Diagnostics

- Distance minimale et seuil `out_of_support` : proximité du support des sondes.
- Poids maximal : concentration sur la sonde dominante.
- Entropie normalisée : répartition des poids.

Ces grandeurs ne sont pas calibrées comme confiance prédictive et ne modifient jamais automatiquement la sortie.

## 9. Tests et contrôle

```bash
python -m unittest discover -s tests -v
python -m py_compile run_esonde.py src/esonde/*.py scripts/*.py
python scripts/audit_pure_probe.py
```

La suite incluse valide notamment gradients numériques/analytique, probabilités, gel de paramètres, standardisation train-only, sauvegarde/relecture, nouvel entraînement indépendant, données extrêmes et refus de drapeau MLP. L'audit AST signale modules/couches interdits dans le runtime.

## 10. Dépannage

- Python introuvable : installer Python 3.10+ dans l'OS et vérifier `PATH`.
- Tkinter absent / `TclError` : installer le module Tk de la distribution Python ou continuer avec le CLI.
- CSV mal formé : vérifier en-têtes uniques, séparateur virgule, cellules numériques présentes et finies.
- Colonnes incompatibles : préserver les noms et l'ordre des variables enregistrés.
- Classe inconnue en validation/test : vérifier le protocole de partition et les effectifs, ne pas filtrer silencieusement les échantillons.
- `out_of_support=true` : examiner le domaine d'entrée ; la prédiction existe mais sa fiabilité n'est pas garantie par ce drapeau.
- Perte non finie : garder les logs, identifier le run, puis créer un nouveau run contrôlé avec paramètres modifiés ; ne jamais remplacer l'ancien rapport.

## 11. Reproductibilité et modèle JSON

Le JSON sauvegarde l'architecture, les paramètres, les classes, la normalisation, les paramètres initiaux de température et l'état Adam du meilleur checkpoint de validation. Le rechargement vérifie format, pureté déclarée, dimensions, supports, paramètres finis et taille de l'état optimiseur. La reprise exacte d'une époque interrompue n'est pas une fonction v0.
