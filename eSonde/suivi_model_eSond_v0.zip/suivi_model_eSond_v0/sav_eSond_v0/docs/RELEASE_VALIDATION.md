# Vérification de release — eSonde_v0 0.1.0

Date : 8 novembre 2026.

## Matrice d'exécution

| Contrôle | Résultat | Preuve |
|---|---|---|
| Compilation Python | PASS | `logs/py_compile_release_final_20261108.log` |
| Tests unitaires | 15/15 PASS | `logs/unit_tests_release_final_20261108.log` |
| Audit AST pure-sonde | 7 fichiers, 0 violation | `results/audit_pure_probe_release_final.json` |
| CLI train/predict/evaluate/inspect | PASS | `logs/cli_*_release_final_20261108.log` |
| Prédiction CSV feature-only | 240 lignes | `results/release_final_predictions.csv` |
| GUI train/predict/evaluate/inspect | PASS sous Linux/Xvfb | `logs/gui_full_workflow_release_final_20261108.log` |
| Formalisme TeX | 7 pages, compilé et rendu | `formalism/formalisme_eSond_v0.tex` et `.pdf` |

## Architecture vérifiée

Le runtime contient uniquement les familles de sondes `local`, `coverage` et `interaction` (supports par paires pour cette dernière). Pas de module/layer affine, dense, neurone ou MLP détecté dans le cœur par l'audit AST. La sélection du cœur `local` est un choix par défaut du prototype, pas une revendication de supériorité.

## Dépendances et compatibilité

Python 3.10+ et bibliothèque standard uniquement. Tkinter est facultatif, requis pour le GUI desktop. Le ZIP ne contient pas l'interpréteur Python du système. Aucune connexion réseau ni paquet tiers n'est requis à l'exécution.

## Limites

Les valeurs des démos sont synthétiques. Aucune comparaison confirmatoire appariée contre un MLP n'est incluse. L'extrapolation et l'identifiabilité sont ouvertes. Le drapeau `out_of_support` est géométrique et ne constitue pas une probabilité calibrée d'erreur. Les tests GUI ont été automatisés sous Xvfb sur Linux ; autres OS non testés.
