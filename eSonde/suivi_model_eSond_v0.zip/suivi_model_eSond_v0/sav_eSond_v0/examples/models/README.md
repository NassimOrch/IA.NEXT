# eSonde_v0 — états entraînés JSON d’exemple

Ce répertoire contient les neuf états de modèle eSonde_v0 trouvés dans l’espace de travail et vérifiés par la commande `inspect`. Le format natif est JSON (pas `.pt`, pas pickle, pas TorchScript).

Les fichiers couvrent la régression, la classification, des variantes locales et des configurations mixtes. Ils ont été entraînés sur des jeux de démonstration ou de vérification synthétiques/locaux propres à ces runs. Ils ne constituent pas un modèle pré-entraîné universel pour un jeu de données arbitraire. Les colonnes, la dimension, la tâche et les familles attendues sont enregistrées dans chaque JSON et résumées dans `MODELS_INDEX.json`.

## Inspection

Depuis la racine du package Dmodel :

```bash
python run_esonde.py inspect --model examples/models/release_final_model.json
python run_esonde.py inspect --model examples/models/release_cli_model.json
python run_esonde.py inspect --model examples/models/demo_classification.json
````

## Prédiction

Choisir un fichier de données ayant exactement les colonnes et l’ordre attendus par le modèle, puis :

```bash
python run_esonde.py predict --model examples/models/release_final_model.json --csv nouveaux.csv --output predictions.csv
```

Les états JSON sont directement lisibles par le runtime eSonde_v0 sans désérialisation pickle.

## Verification release 2026-11-08

Nine JSON snapshots are included. Their SHA-256 values match `MODELS_INDEX.json`, and `run_esonde.py inspect --model` completed successfully for all nine. These are trained demonstration/verification snapshots, not a universal pretrained model for arbitrary data. The native runtime format is JSON; these files are the complete saved eSonde states produced by the recorded runs.
