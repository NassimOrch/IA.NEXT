#!/usr/bin/env python3
"""Static architecture check for forbidden learned dense/neural dependencies."""
from pathlib import Path
import ast, json, sys
ROOT=Path(__file__).resolve().parents[1]
CORE=ROOT/'src'/'esonde'
FORBIDDEN_MODULES={'torch','tensorflow','keras','numpy','sklearn','scipy','jax','flax'}
FORBIDDEN_ATTRS={'Linear','Dense','Conv1d','Conv2d','LSTM','GRU','Embedding','MultiheadAttention'}
violations=[]; parsed=0
for path in sorted(CORE.glob('*.py')):
    tree=ast.parse(path.read_text(encoding='utf-8'))
    parsed+=1
    for node in ast.walk(tree):
        if isinstance(node,ast.Import):
            for n in node.names:
                root=n.name.split('.')[0]
                if root in FORBIDDEN_MODULES: violations.append({'file':str(path.relative_to(ROOT)),'line':node.lineno,'kind':'forbidden_import','name':n.name})
        elif isinstance(node,ast.ImportFrom):
            root=(node.module or '').split('.')[0]
            if root in FORBIDDEN_MODULES: violations.append({'file':str(path.relative_to(ROOT)),'line':node.lineno,'kind':'forbidden_import','name':node.module})
        elif isinstance(node,ast.Attribute) and node.attr in FORBIDDEN_ATTRS:
            violations.append({'file':str(path.relative_to(ROOT)),'line':getattr(node,'lineno',0),'kind':'forbidden_layer_attribute','name':node.attr})
        elif isinstance(node,ast.Name) and node.id in {'nn','Sequential','ModuleList'}:
            violations.append({'file':str(path.relative_to(ROOT)),'line':getattr(node,'lineno',0),'kind':'forbidden_nn_symbol','name':node.id})
result={'check':'pure_probe_static_architecture','files_parsed':parsed,'forbidden_modules':sorted(FORBIDDEN_MODULES),'forbidden_layer_attributes':sorted(FORBIDDEN_ATTRS),'violations':violations,'status':'PASS' if not violations else 'FAIL','scope_note':'Static source audit only; runtime graph behavior and mathematical conformance are also covered by tests and code review.'}
out=ROOT/'results'/'audit_pure_probe.json'; out.parent.mkdir(exist_ok=True); out.write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2)); sys.exit(0 if not violations else 1)
