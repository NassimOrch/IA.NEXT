@echo off
setlocal
set "HERE=%~dp0"
where py >nul 2>nul
if %ERRORLEVEL%==0 (
  py -3 "%HERE%run_esonde.py" %*
) else (
  python "%HERE%run_esonde.py" %*
)
exit /b %ERRORLEVEL%
