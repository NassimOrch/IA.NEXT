import math, random, tempfile, unittest
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from esonde.model import ESonde

class ESondeTests(unittest.TestCase):
    def make_data(self, task, n=160, seed=9):
        rng=random.Random(seed); X=[]; y=[]
        for _ in range(n):
            a=rng.uniform(-2.5,2.5); b=rng.uniform(-2.5,2.5); X.append([a,b])
            y.append((math.sin(a*b)+0.2*a) if task=='regression' else ('1' if a*b>0 else '0'))
        return X,y

    def test_regression_train_and_roundtrip(self):
        X,y=self.make_data('regression')
        model=ESonde(task='regression',n_probes=10,seed=2,epochs=90,patience=18,batch_size=24)
        info=model.fit(X[:120],y[:120],X[120:],y[120:])
        self.assertTrue(math.isfinite(info['best_validation_loss']))
        self.assertGreaterEqual(info['best_epoch'],1)
        pred=model.predict(X[:8]); self.assertEqual(len(pred),8)
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'m.json'; model.feature_names=['a','b']; model.save(p)
            restored=ESonde.load(p)
            self.assertEqual(pred,restored.predict(X[:8]))
            self.assertEqual(model.parameter_count(),restored.parameter_count())

    def test_classification_outputs_probabilities(self):
        X,y=self.make_data('classification')
        model=ESonde(task='classification',n_probes=12,seed=4,epochs=100,patience=20,batch_size=24)
        model.fit(X[:120],y[:120],X[120:],y[120:])
        probs=model.predict_proba(X[120:])
        self.assertEqual(len(probs),40)
        for row in probs:
            self.assertAlmostEqual(sum(row),1.0,places=10)
            self.assertTrue(all(math.isfinite(v) and 0<=v<=1 for v in row))

    def test_coverage_centers_are_frozen_in_optimizer(self):
        X,y=self.make_data('regression',80)
        model=ESonde(task='regression',n_probes=4,families=('coverage',),epochs=3,patience=3)
        model.fit(X,y)
        # coverage centers are the first contiguous parameter block for each probe
        for p in model.probes:
            self.assertFalse(p.center_trainable)
        for key,i,a,b in model._parameter_layout:
            if key=='center':
                self.assertEqual(model.optimizer_t[a:b],[0]*(b-a))
                self.assertEqual(model.optimizer_m[a:b],[0.0]*(b-a))
                self.assertEqual(model.optimizer_v[a:b],[0.0]*(b-a))

    def test_interaction_supports_are_pairs(self):
        X,y=self.make_data('regression',40)
        model=ESonde(task='regression',n_probes=5,families=('interaction',),epochs=2,patience=2)
        model.fit(X,y)
        self.assertTrue(all(len(p.features)==2 for p in model.probes))

    def test_interaction_family_cycles_over_feature_pairs(self):
        rng=random.Random(14)
        X=[[rng.uniform(-1,1) for _ in range(3)] for _ in range(60)]
        y=[row[0]*row[1]+row[1]*row[2] for row in X]
        model=ESonde(task='regression',n_probes=6,families=('interaction',),epochs=2,patience=2)
        model.fit(X,y)
        self.assertGreater(len({tuple(p.features) for p in model.probes}),1)

    def test_analytic_gradient_matches_central_finite_difference(self):
        X,y=self.make_data('regression',80,seed=23)
        model=ESonde(task='regression',n_probes=4,seed=7,epochs=1,patience=1,batch_size=80)
        model.fit(X[:60],y[:60],X[60:],y[60:])
        x=model._standardize([X[3]])[0]
        target=[float(y[3])]
        base=model._flatten()
        _,analytic=model._loss_and_grad(x,target)
        numeric=[]; h=1e-6
        for i,value in enumerate(base):
            plus=list(base); minus=list(base)
            plus[i]=value+h; minus[i]=value-h
            model._assign_flat(plus); lp=model._loss_and_grad(x,target)[0]
            model._assign_flat(minus); lm=model._loss_and_grad(x,target)[0]
            numeric.append((lp-lm)/(2*h))
        model._assign_flat(base)
        for i,(a,n) in enumerate(zip(analytic,numeric)):
            self.assertAlmostEqual(a,n,delta=2e-5,msg=f'gradient index {i}: analytic={a}, numeric={n}')

    def test_classification_analytic_gradient_matches_finite_difference(self):
        X,y=self.make_data('classification',90,seed=24)
        model=ESonde(task='classification',n_probes=4,seed=8,epochs=1,patience=1,batch_size=90)
        model.fit(X[:70],y[:70],X[70:],y[70:])
        x=model._standardize([X[5]])[0]
        target=model._encode_targets_validation([y[5]])[0]
        base=model._flatten(); _,analytic=model._loss_and_grad(x,target)
        numeric=[]; h=1e-6
        for i,value in enumerate(base):
            plus=list(base); minus=list(base); plus[i]=value+h; minus[i]=value-h
            model._assign_flat(plus); lp=model._loss_and_grad(x,target)[0]
            model._assign_flat(minus); lm=model._loss_and_grad(x,target)[0]
            numeric.append((lp-lm)/(2*h))
        model._assign_flat(base)
        for i,(a,n) in enumerate(zip(analytic,numeric)):
            self.assertAlmostEqual(a,n,delta=2e-5,msg=f'gradient index {i}: analytic={a}, numeric={n}')

    def test_standardization_uses_train_only(self):
        model=ESonde(task='regression',n_probes=2,seed=1,epochs=1,patience=1)
        model.fit([[0.0],[2.0],[4.0]],[0.0,1.0,2.0],[[10000.0]],[3.0])
        self.assertAlmostEqual(model.input_mean[0],2.0,places=12)
        self.assertAlmostEqual(model.input_scale[0],(8.0/3.0)**0.5,places=12)

    def test_invalid_nonfinite_input_rejected(self):
        model=ESonde()
        with self.assertRaises(ValueError): model.fit([[0.0,float('nan')],[1.0,2.0]],[0.0,1.0])


    def test_refit_resets_optimizer_and_is_reproducible(self):
        X,y=self.make_data('regression',100,seed=31)
        reused=ESonde(task='regression',n_probes=6,seed=13,epochs=12,patience=5,batch_size=20)
        reused.fit(X[:80],y[:80],X[80:],y[80:])
        reused.fit(X[:80],y[:80],X[80:],y[80:])
        fresh=ESonde(task='regression',n_probes=6,seed=13,epochs=12,patience=5,batch_size=20)
        fresh.fit(X[:80],y[:80],X[80:],y[80:])
        self.assertEqual(reused.predict(X[80:]),fresh.predict(X[80:]))
        self.assertEqual(reused.optimizer_t,fresh.optimizer_t)

    def test_empty_validation_is_rejected(self):
        model=ESonde(task='regression',n_probes=2,epochs=1,patience=1)
        with self.assertRaises(ValueError): model.fit([[0.0],[1.0]],[0.0,1.0],[],[])

    def test_extreme_out_of_support_prediction_remains_finite(self):
        X,y=self.make_data('regression',60,seed=51)
        model=ESonde(task='regression',n_probes=4,seed=3,epochs=5,patience=3)
        model.fit(X,y)
        diag=model.diagnostics([[1e308,-1e308]])[0]
        self.assertTrue(math.isfinite(diag['min_probe_distance']))
        self.assertTrue(math.isfinite(diag['max_probe_weight']))
        self.assertTrue(diag['out_of_support'])
        pred=model.predict([[1e308,-1e308]])[0]
        self.assertTrue(math.isfinite(pred))

    def test_load_rejects_non_probe_architecture_flag(self):
        import json
        X,y=self.make_data('regression',60,seed=12)
        model=ESonde(task='regression',n_probes=3,epochs=3,patience=2)
        model.fit(X,y)
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'model.json'; model.save(path)
            data=json.loads(path.read_text())
            data['architecture_audit']['uses_mlp']=True
            path.write_text(json.dumps(data))
            with self.assertRaises(ValueError): ESonde.load(path)


    def test_coverage_threshold_calibration_uses_train_only(self):
        X,y=self.make_data('regression',90,seed=63)
        model_a=ESonde(task='regression',n_probes=5,seed=8,epochs=2,patience=2)
        model_b=ESonde(task='regression',n_probes=5,seed=8,epochs=2,patience=2)
        model_a.fit(X[:70],y[:70])
        model_b.fit(X[:70],y[:70],[[1e5,1e5],[2e5,-2e5]],[10.0,20.0])
        self.assertAlmostEqual(model_a.coverage_threshold,model_b.coverage_threshold,places=12)
        self.assertIsNone(model_a.coverage_threshold_override)

    def test_explicit_coverage_threshold_override_and_roundtrip(self):
        X,y=self.make_data('regression',70,seed=64)
        model=ESonde(task='regression',n_probes=4,seed=4,epochs=2,patience=2,coverage_threshold=2.25)
        model.fit(X,y)
        self.assertEqual(model.coverage_threshold,2.25)
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'model.json'; model.save(path); loaded=ESonde.load(path)
            self.assertEqual(loaded.coverage_threshold,2.25)
            self.assertEqual(loaded.coverage_threshold_override,2.25)

if __name__=='__main__': unittest.main(verbosity=2)
