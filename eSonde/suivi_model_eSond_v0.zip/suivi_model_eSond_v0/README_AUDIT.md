# Amodel_eSond_v0 — audit, sources, checkpoints et preuves

Date : 8 novembre 2026. Runtime audité : eSonde_v0 0.1.0.

## Contenu

- `ANALYSE_SOURCES_EXPERIENCES.md` : analyse des sources théoriques et expériences EX3–EX12 et ARCH_UP, décisions de sélection, limites et résultats.
- `source_file_manifest.jsonl` / CSV et `source_integrity_recheck_20261108.json` : 35 901 fichiers source inventoriés, 35 901/35 901 empreintes identiques au contrôle final.
- `document_index/` : 590 documents textuels indexés.
- `selected_sources/` : sources primaires retenues pour l'audit.
- `deep_structure_audit*` : validation de structures JSON/JSONL/CSV/NPZ/NPY/ZIP. Une ligne JSONL tronquée demeure identifiée et non modifiée.
- `ablation_v0/` : pré-enregistrements, tous les logs, V1 interrompue, résultats V2/V3 et comparaison run-à-run.
- `serialized_artifact_incident/` : rapport d'incident et attestation PDF/Markdown, signatures Ed25519 détachées, clé publique de vérification, manifestes des 7 142 artefacts sérialisés et preuve des neuf snapshots natifs.
- Journaux EX12 de contrôle des checksums, tests sûrs et audit P7 ; les holdouts scellés n'ont pas été générés ni rescored.

## Bilan final des artefacts sérialisés

- 7 133 fichiers `.pt` : 6 557 états décodés lors de la première passe `weights_only=True`, 347 états décodés avec allowlist NumPy ciblée, 207 avec substituts inertes toujours sous `weights_only=True`, soit **7 111 états décodés**. Les 22 TorchScript restants ont été inspectés statiquement, sans `torch.jit.load` ni exécution.
- 8 fichiers `.joblib` : analyse statique partielle des opcodes/marqueurs, sans `joblib.load`.
- 1 Parquet : taille, signature `PAR1` et SHA-256 vérifiés ; lecture sémantique par colonnes non effectuée faute de moteur compatible installé.
- Les 7 142 originaux (509 753 792 octets) sont livrés à l'identique dans quatre volumes complémentaires : `artefacts_modeles_sources_eSond_v0_part01.zip` à `artefacts_modeles_sources_eSond_v0_part04.zip`. La reconstruction et la vérification 7 142/7 142 sont démontrées par `assemble_Amodel_eSond_v0.py`.
- Les neuf snapshots natifs JSON eSonde sont inclus dans Dmodel et Amodel ; 9/9 `inspect` PASS et SHA-256 PASS.

## Intégrité et validation

Les deux archives utilisateur et 23 archives imbriquées ont passé les CRC. Le manifeste source recense 35 901 fichiers et 2 230 514 939 octets ; contrôle final : zéro manque, zéro ajout, zéro différence SHA-256. Les ablations eSonde V2/V3 sont synthétiques et exploratoires (24 runs chacune, 2 graines), sans MLP confirmatoire ; aucune revendication de supériorité générale n'est formulée. Le runtime a passé 15/15 tests, compilation, audit AST pure-sonde (7 fichiers, 0 violation), commandes CLI et workflow GUI automatisé sous Linux/Xvfb (limites OS documentées).

## Reconstituer les artefacts bruts

Placer `Amodel_eSond_v0.zip`, les quatre volumes `artefacts_modeles_sources_eSond_v0_part01.zip` à `part04.zip` et `assemble_Amodel_eSond_v0.py` dans le même répertoire. Exécuter :

```bash
python assemble_Amodel_eSond_v0.py --archives-dir . --output ./Amodel_eSond_v0_complete
```

Le script vérifie CRC, chemins sûrs, tailles et SHA-256 des 7 142 originaux. Les originaux restent byte-for-byte ; aucun chargement pickle/TorchScript n'est déclenché par le script de reconstitution.

## Vérifier les signatures des documents

Depuis `audit/serialized_artifact_incident/` :

```bash
./verify_incident_signature.sh
```

La signature détachée établit l'intégrité des octets vis-à-vis de la clé publique fournie ; cette clé de release n'est pas un certificat d'identité OpenAI ni une signature électronique qualifiée.
