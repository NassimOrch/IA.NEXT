# Release eSonde_v0 — registre de livraison

Date : 8 novembre 2026. Version : 0.1.0.

## Paquets principaux

- `Dmodel_eSond_v0.zip` : runtime pur-sonde Python autonome côté dépendances, sources, CLI, GUI Tk, tests, exemples, formalisation compilée, guides et **neuf snapshots JSON eSonde inspectés**.
- `Amodel_eSond_v0.zip` : audit fichier-par-fichier, analyse EX3–EX12/ARCH_UP, manifestes, preuves, ablations, audit de sérialisation consolidé et rapport d'incident signé.
- `suivi_model_eSond_v0.zip` : chemins canoniques, checklists, preuves, historique, incident et snapshot `sav_eSond_v0`.

## Complément : artefacts historiques source

Pour ne retenir aucun checkpoint historique dans l'accès utilisateur, les originaux bruts sont aussi fournis dans :
- `artefacts_modeles_sources_eSond_v0_part01.zip`
- `artefacts_modeles_sources_eSond_v0_part02.zip`
- `artefacts_modeles_sources_eSond_v0_part03.zip`
- `artefacts_modeles_sources_eSond_v0_part04.zip`

Ces quatre archives contiennent 7 133 `.pt`, 8 `.joblib` et 1 `.parquet`, soit 7 142 fichiers inchangés, avec manifests par partie et SHA-256. Les fichiers `.pt` sont des checkpoints d'expériences historiques hétérogènes (y compris MLP/RBF/CNG/CNC), pas des dépendances du runtime pure-sonde JSON.

## Installation et vérification du runtime

```bash
unzip Dmodel_eSond_v0.zip
cd Dmodel_eSond_v0
python --version              # Python 3.10+
python run_esonde.py --help
python -m py_compile run_esonde.py src/esonde/*.py scripts/*.py
python -m unittest discover -s tests -v
python scripts/audit_pure_probe.py
python run_esonde.py inspect --model examples/models/release_final_model.json
```

Windows : utiliser `py` si `python` n'est pas sur PATH. GUI : `python run_esonde.py gui` avec Tkinter et une session graphique.

## Contrôles de release

- 15/15 tests runtime depuis extraction propre ; 9/9 snapshots inspectés.
- Compilation Python et audit AST : 7 fichiers cœur, zéro violation détectée.
- CLI train/predict/evaluate/inspect/demo ; GUI testée sous Xvfb pour entraîner/prédire/évaluer/inspecter.
- Formalisme LaTeX compilé, 7 pages.
- Sources : 35 901/35 901 hachages identiques au manifeste initial.
- EX12 : 25/25 tests et 11/11 contrôles d'audit P7 ; aucun holdout scellé généré ou rescored.
- Ablations : 24 runs V2 et 24 ré-audits V3, synthétiques et exploratoires, sans baseline MLP confirmatoire.
- Checkpoints : 7 111 états `.pt` décodés en `weights_only=True`, 22 TorchScript statiques ; 8 JOBLIB statiques, Parquet non décodé sémantiquement. Voir rapport d'incident signé.

## Statut et limites

Prototype fonctionnel pure-sonde de régression/classification tabulaire. Python 3.10+ requis ; aucune dépendance Python tierce, Tkinter facultatif. L'archive n'embarque pas l'interpréteur Python. Aucune supériorité MLP ni extrapolation robuste universelle revendiquée.


## Rectification d’incident et volumes de poids bruts (2026-11-08)

La release corrigée inclut les neuf snapshots natifs `examples/models/*.json` dans Dmodel. Ils passent tous `run_esonde.py inspect` et leurs SHA-256 correspondent à `MODELS_INDEX.json`.

Amodel contient l’audit complet et le rapport d’incident signé Ed25519. Les 7 133 checkpoints `.pt`, les 8 `.joblib` et le fichier Parquet sont distribués à l’identique dans quatre volumes `artefacts_modeles_sources_eSond_v0_part01.zip` à `part04.zip`, chacun inférieur à 200 MiB. Pour extraire et vérifier le tout :

```bash
python assemble_Amodel_eSond_v0.py --archives-dir . --output ./Amodel_eSond_v0_complete
```

Le script valide les CRC, tailles et SHA-256 de chacun des 7 142 artefacts historiques. Voir `raw_model_artifacts_manifest.json` dans `Amodel_eSond_v0/audit/serialized_artifact_incident/`. Les 22 TorchScript restent fournis à l’identique mais inspectés statiquement seulement ; les huit JOBLIB restent fournis à l’identique mais non désérialisés ; le Parquet est fourni à l’identique mais non lu sémantiquement.


## Supplément incident — vérification des artefacts sérialisés

Les artefacts `.pt`, `.joblib` et Parquet des sources sont fournis byte-for-byte dans quatre volumes complémentaires `artefacts_modeles_sources_eSond_v0_part01.zip` à `artefacts_modeles_sources_eSond_v0_part04.zip`, chacun inférieur à 200 MiB. Total : 7 142 fichiers et 509 753 792 octets. Le script `assemble_Amodel_eSond_v0.py` reconstruit l’archive d’audit et compare chaque taille/SHA-256. Bilan `.pt` : 6 557 première passe + 347 allowlist NumPy + 207 stubs inertes = 7 111 états décodés sous `weights_only=True`; 22 TorchScript statiques. 8 JOBLIB inventoriés statiquement, sans désérialisation ; le Parquet est préservé et hashé, mais non lu par colonnes. Les rapports d’incident et attestation signés par signature Ed25519 détachée se trouvent dans Amodel. La clé publique vérifie l’intégrité des fichiers, sans certifier une identité OpenAI.
