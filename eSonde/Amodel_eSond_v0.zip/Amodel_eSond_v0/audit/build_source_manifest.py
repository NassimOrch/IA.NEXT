from pathlib import Path
import hashlib, json, csv, ast, zipfile, sys, time
ROOTS=[Path('/mnt/data/esonde_work/input_sources'),Path('/mnt/data/esonde_work/input_ex12')]
OUT=Path('/mnt/data/esonde_work/audit'); OUT.mkdir(parents=True,exist_ok=True)
start=time.time(); records=[]; errors=[]; counts={}; bytes_total=0
for root in ROOTS:
  for p in sorted(root.rglob('*')):
    if not p.is_file(): continue
    rel=str(p.relative_to(root)); size=p.stat().st_size; bytes_total+=size
    ext=p.suffix.lower() or '[sans extension]'; counts[ext]=counts.get(ext,0)+1
    h=hashlib.sha256()
    with p.open('rb') as f:
      for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    rec={'root':root.name,'path':rel,'extension':ext,'size_bytes':size,'sha256':h.hexdigest(),'validation':'HASHED'}
    # Strict parsers are applied to every textual structured document.
    if ext=='.json':
      try: json.loads(p.read_text(encoding='utf-8-sig')); rec['validation']='JSON_OK'
      except Exception as e: rec['validation']='JSON_ERROR'; errors.append({'path':f'{root.name}/{rel}','kind':'json','error':str(e)[:500]})
    elif ext=='.jsonl':
      bad=[]
      try:
        for n,line in enumerate(p.read_text(encoding='utf-8-sig').splitlines(),1):
          if line.strip():
            try: json.loads(line)
            except Exception as e: bad.append((n,str(e)))
        rec['validation']='JSONL_OK' if not bad else 'JSONL_ERROR'
        if bad: errors.append({'path':f'{root.name}/{rel}','kind':'jsonl','bad_lines':bad[:10]})
      except Exception as e: rec['validation']='JSONL_READ_ERROR'; errors.append({'path':f'{root.name}/{rel}','kind':'jsonl_read','error':str(e)[:500]})
    elif ext=='.py':
      try: ast.parse(p.read_text(encoding='utf-8-sig')); rec['validation']='PY_AST_OK'
      except Exception as e: rec['validation']='PY_AST_ERROR'; errors.append({'path':f'{root.name}/{rel}','kind':'python_ast','error':str(e)[:500]})
    elif ext=='.csv':
      try:
        with p.open('r',encoding='utf-8-sig',newline='') as f:
          reader=csv.reader(f); header=next(reader,None); rec['columns']=len(header or []); rec['validation']='CSV_READ_OK'
      except Exception as e: rec['validation']='CSV_ERROR'; errors.append({'path':f'{root.name}/{rel}','kind':'csv','error':str(e)[:500]})
    elif ext=='.tex':
      try:
        txt=p.read_text(encoding='utf-8-sig'); rec['lines']=txt.count('\n')+1; rec['sections']=sum(1 for l in txt.splitlines() if l.lstrip().startswith(('\\section','\\chapter','\\title'))); rec['validation']='TEX_UTF8_OK'
      except Exception as e: rec['validation']='TEX_READ_ERROR'; errors.append({'path':f'{root.name}/{rel}','kind':'tex','error':str(e)[:500]})
    records.append(rec)
with (OUT/'source_file_manifest.jsonl').open('w',encoding='utf-8') as f:
  for r in records: f.write(json.dumps(r,ensure_ascii=False)+'\n')
with (OUT/'source_file_manifest.csv').open('w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['root','path','extension','size_bytes','sha256','validation','columns','lines','sections']);w.writeheader();w.writerows(records)
summary={'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'roots':[str(x) for x in ROOTS],'file_count':len(records),'total_bytes':bytes_total,'extension_counts':dict(sorted(counts.items())),'validation_error_count':len(errors),'validation_errors':errors[:1000],'duration_seconds':round(time.time()-start,3)}
(OUT/'source_manifest_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ('validation_errors','extension_counts')},indent=2)); print('EXTENSIONS',summary['extension_counts']); print('ERRORS',len(errors))
