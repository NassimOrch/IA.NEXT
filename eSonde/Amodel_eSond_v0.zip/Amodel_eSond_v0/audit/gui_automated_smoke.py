import csv, math, random, sys, tempfile, time
from pathlib import Path
import tkinter as tk
from tkinter import messagebox
sys.path.insert(0, '/mnt/data/esonde_work/eSonde_v0/src')
import esonde.gui as gui

work=Path('/mnt/data/esonde_work/audit/gui_smoke_data'); work.mkdir(exist_ok=True)
rng=random.Random(42); data=work/'gui_train.csv'; features=work/'gui_features.csv'
with data.open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['a','b','target'])
    for _ in range(90):
        a=rng.uniform(-2,2); b=rng.uniform(-2,2); w.writerow([a,b,math.sin(a*b)+.1*a])
with data.open(newline='',encoding='utf-8') as f, features.open('w',newline='',encoding='utf-8') as g:
    r=csv.reader(f); w=csv.writer(g); w.writerow(next(r)[:-1]); w.writerows([row[:-1] for row in r])
model=work/'gui_model.json'; pred=work/'gui_predictions.csv'
messagebox.showerror=lambda *a,**k: print('GUI_ERROR_DIALOG',a)
orig=tk.Tk.mainloop

def walk(widget):
    result=[widget]
    for child in widget.winfo_children(): result.extend(walk(child))
    return result

def patched_mainloop(self, *a, **kw):
    root=self; state={'step':0,'failed':False}
    widgets=walk(root)
    entries=[w for w in widgets if isinstance(w,tk.Entry) or w.winfo_class()=='TEntry']
    # Fill all path/config entries on the Tk thread.
    for e in entries:
        info=e.grid_info(); row=int(info.get('row',-1)); col=int(info.get('column',-1))
        parent=e.master
        val=None
        if parent is root.winfo_children()[0]:
            val={0:str(data),1:'target',4:str(model),5:str(pred)}.get(row)
        else:
            val={(1,0):'6',(1,1):'local,coverage,interaction',(1,2):'3',(1,3):'2',
                 (3,0):'16',(3,1):'0.025',(3,2):'5'}.get((row,col))
        if val is not None:
            e.delete(0,'end'); e.insert(0,val)
    def find_button(text):
        for w in walk(root):
            if w.winfo_class()=='TButton' and w.cget('text')==text: return w
        raise RuntimeError('Button not found: '+text)
    def status_text():
        for w in walk(root):
            if w.winfo_class()=='TLabel' and w.cget('textvariable'):
                name=w.cget('textvariable')
                try:
                    value=str(root.getvar(name))
                    if value.startswith(('Prêt','Entraînement','Prédiction','Évaluation','Inspection','Erreur')):
                        return value
                except Exception: pass
        return ''
    def set_outer_entry(row,value):
        for e in entries:
            if e.master is root.winfo_children()[0] and int(e.grid_info().get('row',-1))==row:
                e.delete(0,'end'); e.insert(0,value); return
        raise RuntimeError('Entry row not found '+str(row))
    def tick():
        try:
            status=status_text()
            if state['step']==0:
                state['step']=1; find_button('Entraîner').invoke()
            elif state['step']==1 and status=='Entraînement terminé.':
                set_outer_entry(0,str(features)); state['step']=2; find_button('Prédire CSV').invoke()
            elif state['step']==2 and status=='Prédiction terminé.':
                set_outer_entry(0,str(data)); state['step']=3; find_button('Évaluer CSV').invoke()
            elif state['step']==3 and status=='Évaluation terminé.':
                state['step']=4; find_button('Inspecter modèle').invoke()
            elif state['step']==4 and status=='Inspection terminé.':
                state['step']=5
                assert model.exists() and model.stat().st_size>0
                assert model.with_suffix('.report.json').exists()
                assert pred.exists() and sum(1 for _ in pred.open(encoding='utf-8'))==91
                print('GUI_FULL_WORKFLOW_PASS', status, 'steps=4')
                root.after(50,root.destroy); return
            elif status.startswith('Erreur'):
                raise RuntimeError('GUI operation failed: '+status)
            if state['step']<5: root.after(150,tick)
        except Exception as exc:
            state['failed']=True; print('GUI_FULL_WORKFLOW_FAIL',repr(exc)); root.after(50,root.destroy)
    root.after(100,tick)
    return orig(root,*a,**kw)

tk.Tk.mainloop=patched_mainloop
gui.launch()
if not model.exists() or not pred.exists(): raise SystemExit(1)
