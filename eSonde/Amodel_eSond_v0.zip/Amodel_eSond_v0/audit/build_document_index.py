from pathlib import Path
import hashlib, json, re, csv
roots=[Path('/mnt/data/esonde_work/input_sources'),Path('/mnt/data/esonde_work/input_ex12')]
rows=[]
for root in roots:
 for p in sorted(root.rglob('*')):
  if not p.is_file() or p.suffix.lower() not in {'.md','.tex','.rst','.txt'}: continue
  try:
   data=p.read_bytes(); txt=data.decode('utf-8',errors='replace')
  except Exception: continue
  heads=[]
  for line in txt.splitlines():
   s=line.strip()
   if re.match(r'^(#{1,6}\s|\\(?:section|subsection|subsubsection|chapter|part)\{)',s):
    heads.append(s[:260])
    if len(heads)>=20: break
  first=''
  for line in txt.splitlines():
   s=line.strip().lstrip('#').strip()
   if s and not s.startswith('```'):
    first=s[:300]; break
  rel=str(p.relative_to(root))
  rows.append({'root':str(root),'path':rel,'suffix':p.suffix.lower(),'size_bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'heading_count_sampled':len(heads),'headings_sampled':heads,'first_nonempty_line':first,'content_decoded_utf8_replacement': '\ufffd' in txt})
out=Path('/mnt/data/esonde_work/audit/document_index')
out.mkdir(exist_ok=True)
with (out/'text_document_index.jsonl').open('w',encoding='utf-8') as f:
 for r in rows: f.write(json.dumps(r,ensure_ascii=False)+'\n')
with (out/'text_document_index.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['root','path','suffix','size_bytes','sha256','heading_count_sampled','first_nonempty_line','headings_sampled','content_decoded_utf8_replacement'])
 w.writeheader()
 for r in rows: w.writerow({**r,'headings_sampled':' | '.join(r['headings_sampled'])})
summary={'text_documents_indexed':len(rows),'markdown':sum(r['suffix']=='.md' for r in rows),'tex':sum(r['suffix']=='.tex' for r in rows),'rst':sum(r['suffix']=='.rst' for r in rows),'txt':sum(r['suffix']=='.txt' for r in rows),'decoded_with_replacement':sum(r['content_decoded_utf8_replacement'] for r in rows)}
(out/'text_document_index_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False))
