#!/usr/bin/env python3
from __future__ import annotations
import csv, json, math, random, statistics, sys, time
from pathlib import Path
ROOT=Path('/mnt/data/esonde_work/eSonde_v0')
sys.path.insert(0,str(ROOT/'src'))
from esonde.model import ESonde
from esonde.metrics import regression_metrics
OUT=Path(__file__).resolve().parent
VARIANTS={
    'local': {'n_probes':12,'families':['local']},
    'coverage': {'n_probes':19,'families':['coverage']},
    'interaction': {'n_probes':16,'families':['interaction']},
    'hybrid': {'n_probes':15,'families':['local','coverage','interaction']},
}
FUNCTIONS={
    'separable_periodic': lambda x: math.sin(2.1*x[0]) + 0.25*x[1] - 0.15*x[2],
    'multiplicative': lambda x: x[0]*x[1] + 0.4*x[1]*x[2],
    'mixed_nonlinear': lambda x: math.sin(x[0]*x[1]) + 0.2*x[2]*x[2] - 0.3*x[0],
}
def sample(rng,n,low,high,fn):
    X=[[rng.uniform(low,high) for _ in range(3)] for _ in range(n)]
    return X,[fn(x) for x in X]
def score(model,X,y):
    pred=model.predict(X); m=regression_metrics(y,pred); d=model.diagnostics(X)
    return {**m,'out_of_support_fraction':sum(bool(x['out_of_support']) for x in d)/len(d),
            'median_min_probe_distance':statistics.median(x['min_probe_distance'] for x in d)}
rows=[]
for fname,fn in FUNCTIONS.items():
  for seed in (11,29):
    rng=random.Random(seed*1000+len(fname))
    Xtr,ytr=sample(rng,300,-1.0,1.0,fn)
    Xv,yv=sample(rng,100,-1.0,1.0,fn)
    Xi,yi=sample(rng,160,-1.0,1.0,fn)
    lo,hi=((-2.0,-1.25) if seed==11 else (1.25,2.0))
    Xo,yo=sample(rng,160,lo,hi,fn)
    for vname,cfg in VARIANTS.items():
      model=ESonde(task='regression',n_probes=cfg['n_probes'],families=cfg['families'],seed=seed,
                   learning_rate=0.025,batch_size=32,epochs=70,patience=14,temperature=1.0)
      t0=time.perf_counter(); fit=model.fit(Xtr,ytr,Xv,yv); elapsed=time.perf_counter()-t0
      row={'function':fname,'seed':seed,'variant':vname,'probes':len(model.probes),
           'parameters_total':model.parameter_count(),'parameters_trainable':model.trainable_parameter_count(),
           'best_epoch':fit['best_epoch'],'best_validation_loss':fit['best_validation_loss'],
           'fit_seconds':elapsed}
      for regime,X,y in [('interpolation',Xi,yi),('extrapolation',Xo,yo)]:
        metrics=score(model,X,y)
        for key,value in metrics.items(): row[f'{regime}_{key}']=value
      rows.append(row)
      print(json.dumps({'function':fname,'seed':seed,'variant':vname,'fit_seconds':round(elapsed,3),
                        'trainable':row['parameters_trainable'],'interpolation_RMSE':row['interpolation_rmse'],
                        'extrapolation_RMSE':row['extrapolation_rmse']},ensure_ascii=False),flush=True)

with (OUT/'ablation_runs.jsonl').open('w',encoding='utf-8') as f:
    for row in rows: f.write(json.dumps(row,ensure_ascii=False,allow_nan=False)+'\n')
with (OUT/'ablation_runs.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
summary={}
for variant in VARIANTS:
    subset=[r for r in rows if r['variant']==variant]
    summary[variant]={}
    for metric in ('interpolation_rmse','interpolation_mae','interpolation_r2','extrapolation_rmse','extrapolation_mae','extrapolation_r2','interpolation_out_of_support_fraction','extrapolation_out_of_support_fraction','fit_seconds','parameters_total','parameters_trainable'):
        vals=[float(r[metric]) for r in subset]
        summary[variant][metric]={'mean':statistics.mean(vals),'stdev':statistics.stdev(vals) if len(vals)>1 else 0.0,'n':len(vals)}
result={'protocol':'PRE_REGISTRATION.md','runs':len(rows),'functions':list(FUNCTIONS),'seeds':[11,29],
        'variants':VARIANTS,'summary':summary,'note':'Synthetic exploratory ablation only; no MLP baseline; two seeds are descriptive, not inferential.'}
(OUT/'ablation_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print('ABLATION_COMPLETE',len(rows),'runs',flush=True)
