# Protocole v3 — ré-audit du diagnostic de couverture calibré

Cette exécution conserve exactement les fonctions, graines, tailles de jeu, partitions générées par graines, hyperparamètres et nombres de paramètres de PRE_REGISTRATION_V2.md. Seul le diagnostic géométrique est révisé : son seuil par défaut est désormais déterminé à partir des distances minimales d'entraînement (quantile 95 % × 1,5), sans voir validation ni test. Un override explicite reste disponible.

L'objectif de cette reprise ciblée est de vérifier la sensibilité du drapeau `out_of_support` sur les mêmes distributions synthétiques ; les prédictions, pertes, gradients et paramètres entraînés ne dépendent pas du seuil. Les résultats v2 restent archivés tels quels comme mesure du seuil fixe antérieur.

## Pipeline, résultats, interprétation
24 runs (3 fonctions × 2 graines × 4 variantes), avec sauvegarde incrémentale. Les métriques prédictives sont reproduites ; la fraction hors-support est réévaluée avec seuil train-only. Cette ré-audit ne devient pas une calibration de probabilité d'erreur et n'autorise aucune conclusion sur des données réelles.
