# Protocole pré-enregistré v2 — ablation eSonde_v0 (budget exécutable)

## Description
Révision du protocole exploratoire après interruption de v1 par limite d'exécution. Le journal v1 demeure conservé et n'entre pas dans les agrégats. Cette version conserve 3 fonctions, 2 graines et les 4 variantes, avec moins d'époques et une écriture persistante après chaque run.

## Architecture
Même cœur pure-sonde. Budget entraînable apparié à 96–97 paramètres : local 12 sondes (97), coverage 19 (96), interaction 16 (97), hybride 15 (96). Nombre total de paramètres, incluant les ancres gelées, reporté séparément.

## Pipeline complet
Pour chaque fonction et graine (7, 19) : 180 train, 60 validation, 90 interpolation-test et 90 extrapolation-test. Train/validation/interpolation sont tirés de [-1,1]^3. L'extrapolation est tirée de [-2,-1.25]^3 pour seed 7 et [1.25,2]^3 pour seed 19. Les fonctions, graines, partitions et variantes sont identiques à l'intérieur d'une paire domaine/graine.

Hyperparamètres : learning rate 0,025 ; batch 32 ; maximum 25 époques ; patience 6 ; température initiale 1 ; graine déclarée. Validation sélectionne l'état ; test uniquement après gel. Aucune baseline externe ni donnée scellée n'est utilisée.

## Commandes d'exécution
```bash
python3 /mnt/data/esonde_work/audit/ablation_v0/run_ablation_v2.py
```

Le fichier `ablation_runs_v2.jsonl` est append/flush après chaque run. Le script reprend les clés déjà présentes et non dupliquées en cas de nouvelle interruption.

## Résultats et interprétation
Le rapport final décrit les résultats par famille et régime. Deux graines ne permettent qu'une comparaison descriptive ; pas de p-value, d'intervalle confirmatoire ou de conclusion universelle. La précision d'apprentissage courte ne remplace pas un réglage de convergence complet.

## Conséquences
Théoriques : observer l'effet de supports locaux, géométriques et pairwise. Conceptuelles : tester une banque hybride à budget entraînable proche. Opérationnelles : établir un premier profil de qualité et de coût sans modifier les données des sources.

## Conclusion / statut
Étude exploratoire synthétique, aucune comparaison MLP et aucune validation réelle. Résultats informatifs mais non confirmatoires.
