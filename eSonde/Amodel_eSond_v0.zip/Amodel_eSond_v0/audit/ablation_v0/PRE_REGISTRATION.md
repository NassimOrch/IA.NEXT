# Protocole pré-enregistré — ablation initiale des familles eSonde_v0

## Description
Étudier, sans présupposer de classement, les contributions des familles `local`, `coverage`, `interaction` et de leur hybride sur trois fonctions de régression à 3 variables. Les fonctions sont générées par ce script ; aucun holdout utilisateur/EX n'est consommé.

## Architecture
Le cœur eSonde_v0 strictement pur-sonde est testé tel quel. Les variantes ne changent que les familles et le nombre de sondes. Le budget de paramètres entraînables est apparié à ±1 paramètre (environ 96–97) : local=12 sondes, coverage=19, interaction=16, hybride=15 (5 par famille). Les paramètres gelés et le nombre total de paramètres sont reportés séparément.

## Pipeline complet
- 3 fonctions : séparable périodique, multiplicative, mixte non linéaire.
- 2 graines indépendantes (11, 29) par fonction.
- Pour chaque paire fonction/graine : 300 train, 100 validation, 160 test interpolation et 160 test extrapolation générés indépendamment.
- Les domaines train/validation/interpolation sont uniformes sur [-1,1]^3. L'extrapolation utilise des entrées uniformes sur [1.25,2]^3 ou [-2,-1.25]^3, alternées par graine.
- Les mêmes données sont fournies à toutes les variantes d'une paire.
- Normaliseur, supports et apprentissage voient exclusivement train ; validation sert à l'early stopping ; les deux tests sont scorés après gel.
- Paramètres communs : graine enregistrée, Adam, 70 époques maximum, patience 14, minibatch 32, learning rate 0,025.
- Aucune sélection post-hoc de famille ; résultats individuels et agrégats gardés.

## Commandes d'exécution
Depuis le workspace :

```bash
python3 /mnt/data/esonde_work/audit/ablation_v0/run_ablation.py
```

## Résultats pré-déclarés
Rapport par run : MAE, RMSE, NMAE, R², distance minimale médiane, part hors-support, nombre de paramètres total/entraînable, époque optimale et temps d'entraînement. Agrégats : moyenne et écart-type descriptif par famille et régime. Aucun intervalle inferentiel ou p-value ne sera prétendu pour seulement deux graines.

## Interprétation
Cette expérience est une ablation synthétique exploratoire, non une validation externe ni une comparaison MLP. Les familles seront conservées comme choix disponibles même si leurs résultats sont variables ; aucun résultat isolé ne détermine le classement général.

## Conséquences
- Théoriques : vérifier le fonctionnement des biais inductifs sur quelques fonctions connues.
- Conceptuelles : séparer contribution d'une famille et capacité totale.
- Opérationnelles : informer la conception des tests futurs et mesurer le coût.

## Conclusion / statut du modèle
À compléter automatiquement avec les mesures. La performance générale d'eSonde et sa comparaison à des architectures externes restent ouvertes.
