#!/usr/bin/env python3
from __future__ import annotations
import csv,json,math,random,statistics,sys,time
from pathlib import Path
ROOT=Path('/mnt/data/esonde_work/eSonde_v0'); sys.path.insert(0,str(ROOT/'src'))
from esonde.model import ESonde
from esonde.metrics import regression_metrics
OUT=Path(__file__).resolve().parent; JSONL=OUT/'ablation_runs_v3.jsonl'
VARIANTS={'local':(12,['local']),'coverage':(19,['coverage']),'interaction':(16,['interaction']),'hybrid':(15,['local','coverage','interaction'])}
FUNCTIONS={
 'separable_periodic':lambda x: math.sin(2.1*x[0])+0.25*x[1]-0.15*x[2],
 'multiplicative':lambda x: x[0]*x[1]+0.4*x[1]*x[2],
 'mixed_nonlinear':lambda x: math.sin(x[0]*x[1])+0.2*x[2]*x[2]-0.3*x[0],}
def sample(rng,n,low,high,fn):
 X=[[rng.uniform(low,high) for _ in range(3)] for _ in range(n)]; return X,[fn(x) for x in X]
def score(model,X,y):
 m=regression_metrics(y,model.predict(X)); d=model.diagnostics(X)
 return {**m,'out_of_support_fraction':sum(bool(v['out_of_support']) for v in d)/len(d),
         'median_min_probe_distance':statistics.median(v['min_probe_distance'] for v in d)}
existing={}
if JSONL.exists():
 for line in JSONL.read_text(encoding='utf-8').splitlines():
  if line.strip():
   r=json.loads(line); existing[(r['function'],r['seed'],r['variant'])]=r
fields=['function','seed','variant']
for fname,fn in FUNCTIONS.items():
 for seed in (7,19):
  rng=random.Random(seed*1000+len(fname))
  Xtr,ytr=sample(rng,180,-1,1,fn); Xv,yv=sample(rng,60,-1,1,fn)
  Xi,yi=sample(rng,90,-1,1,fn); lo,hi=((-2,-1.25) if seed==7 else (1.25,2))
  Xo,yo=sample(rng,90,lo,hi,fn)
  for vname,(nprobes,families) in VARIANTS.items():
   key=(fname,seed,vname)
   if key in existing: continue
   model=ESonde(task='regression',n_probes=nprobes,families=families,seed=seed,learning_rate=.025,
                batch_size=32,epochs=25,patience=6,temperature=1.0)
   t0=time.perf_counter(); fit=model.fit(Xtr,ytr,Xv,yv); elapsed=time.perf_counter()-t0
   row={'function':fname,'seed':seed,'variant':vname,'probe_count':len(model.probes),
        'parameters_total':model.parameter_count(),'parameters_trainable':model.trainable_parameter_count(),
        'best_epoch':fit['best_epoch'],'best_validation_loss':fit['best_validation_loss'],'fit_seconds':elapsed}
   for name,X,y in [('interpolation',Xi,yi),('extrapolation',Xo,yo)]:
    for k,v in score(model,X,y).items(): row[f'{name}_{k}']=v
   with JSONL.open('a',encoding='utf-8') as f: f.write(json.dumps(row,allow_nan=False)+'\n'); f.flush()
   existing[key]=row
   print(json.dumps({'run':len(existing),'key':key,'fit_s':round(elapsed,3),
        'trainable':row['parameters_trainable'],'interp_rmse':row['interpolation_rmse'],
        'extra_rmse':row['extrapolation_rmse']}),flush=True)
rows=list(existing.values())
if len(rows)!=len(FUNCTIONS)*2*len(VARIANTS):
 print('ABLATION_PARTIAL',len(rows),flush=True); sys.exit(2)
with (OUT/'ablation_runs_v3.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
summary={}
for variant in VARIANTS:
 sub=[r for r in rows if r['variant']==variant]; summary[variant]={}
 for metric in ['interpolation_rmse','interpolation_mae','interpolation_r2','extrapolation_rmse','extrapolation_mae','extrapolation_r2','interpolation_out_of_support_fraction','extrapolation_out_of_support_fraction','fit_seconds','parameters_total','parameters_trainable']:
  vals=[float(r[metric]) for r in sub]; summary[variant][metric]={'mean':statistics.mean(vals),'stdev':statistics.stdev(vals),'n':len(vals)}
result={'protocol':'PRE_REGISTRATION_V2.md','runs':len(rows),'functions':list(FUNCTIONS),'seeds':[7,19],
 'variants':VARIANTS,'summary':summary,'note':'Synthetic exploratory results; 2 seeds; no MLP baseline; no inferential claims.'}
(OUT/'ablation_summary_v3.json').write_text(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
print('ABLATION_V2_COMPLETE',len(rows),flush=True)
