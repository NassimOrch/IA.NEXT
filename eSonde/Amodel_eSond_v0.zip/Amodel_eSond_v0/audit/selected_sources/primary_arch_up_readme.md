# ARCH_UP_TEST_1 — AdaptiveRBF avec communication dynamique entre centres

**Statut : expérience terminée — 3 variantes, 60 entraînements, 60 scores.**

## Question

Une coordination des centres AdaptiveRBF, recalculée pour chaque entrée et exécutée par plusieurs tours d'échange de messages pendant le forward, améliore-t-elle le modèle classique ? La topologie du graphe relationnel apporte-t-elle quelque chose au-delà d'une communication de même capacité sur un graphe aléatoire de même densité et de même degré par centre ?

## Les trois branches

```text
                         AdaptiveRBF
                              |
                +-------------+-------------+
                |             |             |
                v             v             v
             B0_CLASSIC  B4_DYNAMIC_GRAPH  B4_RANDOM_GRAPH
             aucun       graphe réel        graphe réécrit
             message     d'empreintes       aléatoirement
```

- **B0_CLASSIC** : encodeur latent, 8 centres RBF adaptatifs et readout linéaire ; aucune communication entre centres.
- **B4_DYNAMIC_GRAPH** : même base, mais chaque centre construit un état conditionné par l'entrée. Les états échangent des messages par attention sur le graphe réel pendant trois tours successifs. Les messages modifient ensuite le centre effectif, la largeur et la porte de chaque unité avant la prédiction.
- **B4_RANDOM_GRAPH** : même architecture, même initialisation, même nombre de paramètres, même graphe de référence, mais les liens utilisés pour la communication sont réécrits par échanges d'arêtes en conservant exactement le degré de chaque centre et le nombre total d'arêtes.

**Distinction importante :** la topologie du graphe reste fixe pour une paire fonction/graine. La coordination, les poids d'attention, les messages, les corrections de centre et les largeurs effectives sont recalculés pour chaque entrée. Il s'agit de trois tours discrets et séquentiels par appel `forward`, pas d'une dynamique continue en temps physique ni d'un état persistant entre deux entrées.

## Périmètre réellement exécuté

- 4 fonctions synthétiques : `sin(x)`, `x1*x2`, `x1**2+x2`, `sin(x1*x2)+x3`.
- 5 graines : `13007`, `14009`, `15013`, `16001`, `17011`.
- 20 jeux appariés, chacun avec 630 exemples train, 135 validation, 135 test et 250 points extrapolés.
- 3 variantes × 20 jeux = **60 entraînements** et **60 évaluations**.
- Les données sont synthétiques, sans données tabulaires ou externes réelles.

## Résultat en bref

B4 bat B0 sur 19/20 tests appariés ; B4-Random bat B0 sur 20/20. Mais B4 ne bat B4-Random que sur 11/20 comparaisons. Par fonction, le graphe réel est meilleur sur la fonction composée `sin(x1*x2)+x3`, tandis que le graphe aléatoire est meilleur sur `x1**2+x2`. Les deux sont presque équivalents sur le sinus et la multiplication.

Le coût est important : les modèles interactifs possèdent environ **20 fois** le nombre de paramètres de B0 (même nombre entre B4 et B4-Random), environ 4,7 fois le temps d'entraînement médian apparié, 9,4 fois la latence p50 en batch 1 et 21,8 fois en batch 64. Ce résultat interdit de conclure à un gain d'efficacité.

Lire `reports/RESULTS_FR.md` avant toute interprétation. Les moyennes par fonction, les différences appariées et les intervalles exploratoires sont dans `reports/aggregate_summary.json`, `reports/per_function_summary.csv` et `reports/paired_comparisons.csv`.

## Vérifications

- 60/60 runs entraînés et verrouillés avant scoring.
- 60 fichiers de données contrôlés par SHA-256 avant scoring.
- Les holdouts ont été ouverts une seule fois, après verrouillage des checkpoints.
- 60/60 prédictions sauvegardées ; toutes les métriques ont été recalculées depuis ces prédictions avec un écart maximal de `0.0`.
- 40/40 runs interactifs ont des diagnostics d'attention, de déplacements de centres, de largeurs et de portes dépendants de l'entrée ; les messages passent bien par les voisins.
- Un audit train-only additionnel confirme la normalisation de l'attention, le masque du graphe et l'indépendance des exemples dans un batch (écart numérique maximal `7,15e-7`).
- 40/40 contrôles de graphes vérifient la symétrie, le nombre d'arêtes et la séquence exacte des degrés ; 40/40 buffers de graphes des checkpoints concordent avec les graphes exportés.
- Métadonnées rectifiées : B4 réel rapporte 0 % de réécriture appliquée ; les 63,59 % moyens concernent uniquement le graphe contrôle B4-Random. Les checkpoints sont conservés bit à bit ; le sidecar `reports/checkpoint_graph_metadata_correction.json` documente l'ancien champ informatif.
- 6 tests unitaires réussis.
- Audit final : `PASS`.

Le fichier `manifests/HOLDOUT_SCORING_STARTED.json` et la protection dans `src/score_holdout.py` empêchent une réouverture accidentelle du test. **Ne relancez pas les scripts de préparation, entraînement ou scoring dans ce dossier terminé.** Pour une nouvelle campagne, partir d'un répertoire propre et de nouveaux identifiants d'expérience.

## Arborescence

- `configs/` : configuration utilisée.
- `protocol/` : spécification, équations et règles de décision.
- `src/` : modèle, préparation, entraînement, scoring, agrégation et audit.
- `tests/` : tests structurels et d'inférence.
- `data/` : train/validation, holdout et extrapolation avec hashes dans le manifeste.
- `results/runs/` : checkpoints, historiques, prédictions, graphes et métriques par run.
- `manifests/` : hashes, verrou d'entraînement, verrou de scoring et informations d'environnement.
- `reports/` : résultats agrégés, diagnostics, comparaisons appariées et audits.
- `logs/` : traces de l'entraînement, du scoring, de l'agrégation et de l'audit.

## Reproductibilité

Une nouvelle expérience doit être créée dans un nouveau répertoire. Les commandes séquentielles sont listées dans `run.sh`. Dans cette archive terminée, les verrous de sécurité empêchent expressément de répéter la génération des données, l'entraînement ou l'ouverture du holdout.
