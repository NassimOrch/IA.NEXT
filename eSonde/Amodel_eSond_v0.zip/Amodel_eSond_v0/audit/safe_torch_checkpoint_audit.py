from pathlib import Path
import json, time, gc
import torch
ROOTS=[Path('/mnt/data/esonde_work/input_sources'),Path('/mnt/data/esonde_work/input_ex12')]
records=[]; start=time.time()
def walk(x, out, prefix=''):
    if torch.is_tensor(x): out.append({'key':prefix,'shape':list(x.shape),'dtype':str(x.dtype),'numel':x.numel()})
    elif isinstance(x,dict):
        for k,v in x.items(): walk(v,out,(prefix+'.' if prefix else '')+str(k))
    elif isinstance(x,(list,tuple)):
        for i,v in enumerate(x[:100]): walk(v,out,f'{prefix}[{i}]')
for root in ROOTS:
    for p in root.rglob('*.pt'):
        rel=f'{root.name}/{p.relative_to(root)}'
        rec={'path':rel,'size_bytes':p.stat().st_size}
        try:
            obj=torch.load(p,map_location='cpu',weights_only=True)
            tensors=[]; walk(obj,tensors)
            rec.update({'status':'SAFE_WEIGHTS_ONLY_OK','object_type':type(obj).__name__,'tensor_count':len(tensors),'tensor_summary':tensors[:100]})
        except Exception as e:
            rec.update({'status':'SAFE_WEIGHTS_ONLY_REJECTED','error_type':type(e).__name__,'reason':str(e).splitlines()[0][:300]})
        records.append(rec)
        if 'obj' in locals(): del obj
        if len(records)%1000==0: gc.collect()
out=Path('/mnt/data/esonde_work/audit/checkpoint_safe_load_audit.jsonl')
out.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in records),encoding='utf-8')
summary={'count':len(records),'safe_weights_only_ok':sum(r['status']=='SAFE_WEIGHTS_ONLY_OK' for r in records),'safe_mode_rejected':sum(r['status']=='SAFE_WEIGHTS_ONLY_REJECTED' for r in records),'total_bytes':sum(r['size_bytes'] for r in records),'duration_seconds':round(time.time()-start,2),'policy':'No unsafe pickle loading was attempted.'}
Path('/mnt/data/esonde_work/audit/checkpoint_safe_load_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
