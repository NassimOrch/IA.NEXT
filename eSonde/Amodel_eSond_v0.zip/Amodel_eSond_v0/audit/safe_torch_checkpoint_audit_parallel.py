from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import torch, json, time, collections
ROOTS=[Path('/mnt/data/esonde_work/input_sources'),Path('/mnt/data/esonde_work/input_ex12')]
paths=[]
for root in ROOTS:
    paths.extend((root, p) for p in root.rglob('*.pt') if p.is_file())
paths.sort(key=lambda rp:(str(rp[0]),str(rp[1])))
out=Path('/mnt/data/esonde_work/audit/checkpoint_safe_load_audit.jsonl')
start=time.time(); counts=collections.Counter(); total_bytes=0

def one(item):
    root,p=item; size=p.stat().st_size
    rec={'path':f'{root.name}/{p.relative_to(root)}','size_bytes':size}
    try:
        obj=torch.load(p,map_location='cpu',weights_only=True)
        tensors=[]
        def walk(x):
            if torch.is_tensor(x): tensors.append((tuple(x.shape),str(x.dtype),int(x.numel())))
            elif isinstance(x,dict):
                for v in x.values(): walk(v)
            elif isinstance(x,(list,tuple)):
                for v in x[:100]: walk(v)
        walk(obj)
        rec.update({'status':'SAFE_WEIGHTS_ONLY_OK','object_type':type(obj).__name__,'tensor_count':len(tensors),
                    'tensor_meta':[{'shape':list(s),'dtype':d,'numel':n} for s,d,n in tensors[:20]]})
        del obj
    except Exception as e:
        rec.update({'status':'SAFE_WEIGHTS_ONLY_REJECTED','error_type':type(e).__name__,'reason':str(e).splitlines()[0][:260]})
    return rec
with out.open('w',encoding='utf-8') as f:
    with ThreadPoolExecutor(max_workers=8) as pool:
        futures=[pool.submit(one,x) for x in paths]
        for i,fut in enumerate(as_completed(futures),1):
            try: rec=fut.result()
            except Exception as e: rec={'status':'AUDIT_TOOL_ERROR','error_type':type(e).__name__,'reason':str(e)[:260]}
            f.write(json.dumps(rec,ensure_ascii=False)+'\n')
            if i%100==0: f.flush()
            if i%1000==0: print(f'progress {i}/{len(paths)} elapsed={time.time()-start:.1f}s',flush=True)
            counts[rec['status']]+=1; total_bytes+=rec.get('size_bytes',0)
summary={'count':len(paths),'results':dict(counts),'total_bytes':total_bytes,'duration_seconds':round(time.time()-start,2),
         'policy':'torch.load(weights_only=True), no unsafe pickle loading; records streamed in completion order.'}
Path('/mnt/data/esonde_work/audit/checkpoint_safe_load_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
