from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import torch, json, time, zipfile, collections
roots=[Path('/mnt/data/esonde_work/input_sources'),Path('/mnt/data/esonde_work/input_ex12')]
allp={f'{r.name}/{p.relative_to(r)}':(r,p) for r in roots for p in r.rglob('*.pt') if p.is_file()}
out=Path('/mnt/data/esonde_work/audit/checkpoint_safe_load_audit.jsonl')
processed={json.loads(line)['path'] for line in out.open('r',encoding='utf-8')}
missing=[(k,*allp[k]) for k in sorted(set(allp)-processed)]
excluded=[]; todo=[]
for key,root,p in missing:
    if 'torchscript' in p.name.lower():
        try:
            with zipfile.ZipFile(p) as z: members=len(z.namelist())
        except Exception: members=None
        excluded.append({'path':key,'size_bytes':p.stat().st_size,'status':'TORCHSCRIPT_NOT_DESERIALIZED','members':members})
        continue
    try:
        with zipfile.ZipFile(p) as z:
            names=z.namelist()
            if any(n.endswith('constants.pkl') or '/code/' in n for n in names):
                excluded.append({'path':key,'size_bytes':p.stat().st_size,'status':'TORCHSCRIPT_NOT_DESERIALIZED','members':len(names)})
                continue
    except zipfile.BadZipFile:
        excluded.append({'path':key,'size_bytes':p.stat().st_size,'status':'NON_ZIP_PT_NOT_DESERIALIZED'})
        continue
    todo.append((key,p))

def load(item):
    key,p=item; rec={'path':key,'size_bytes':p.stat().st_size}
    try:
        obj=torch.load(p,map_location='cpu',weights_only=True)
        tensors=[]
        def walk(x):
            if torch.is_tensor(x): tensors.append({'shape':list(x.shape),'dtype':str(x.dtype),'numel':int(x.numel())})
            elif isinstance(x,dict):
                for v in x.values(): walk(v)
            elif isinstance(x,(list,tuple)):
                for v in x[:100]: walk(v)
        walk(obj); rec.update({'status':'SAFE_WEIGHTS_ONLY_OK','object_type':type(obj).__name__,'tensor_count':len(tensors),'tensor_meta':tensors[:20]}); del obj
    except Exception as e: rec.update({'status':'SAFE_WEIGHTS_ONLY_REJECTED','error_type':type(e).__name__,'reason':str(e).splitlines()[0][:260]})
    return rec
start=time.time(); counts=collections.Counter()
with out.open('a',encoding='utf-8') as f:
    with ThreadPoolExecutor(max_workers=4) as ex:
        futures=[ex.submit(load,x) for x in todo]
        for i,fut in enumerate(as_completed(futures),1):
            rec=fut.result(); f.write(json.dumps(rec,ensure_ascii=False)+'\n'); counts[rec['status']]+=1
            if i%100==0: f.flush()
summary={'total_pt_files':len(allp),'previously_processed':len(processed),'remaining_candidates':len(missing),'remaining_safe_scan':len(todo),'new_results':dict(counts),'intentionally_not_deserialized':excluded,'record_count':sum(1 for _ in out.open('r',encoding='utf-8')),'duration_seconds':round(time.time()-start,2),'policy':'Only torch.load(weights_only=True) for standard checkpoint archives; TorchScript graph archives and non-ZIP files not executed/deserialized.'}
Path('/mnt/data/esonde_work/audit/checkpoint_safe_load_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
