# Artefacts bruts des expériences — complément Amodel

Le corpus comprend **7 133 checkpoints `.pt`**, **8 fichiers `.joblib`** et **1 fichier `.parquet`**, soit **7 142 artefacts**. Les originaux sont restitués octet pour octet dans quatre archives :

- `artefacts_modeles_sources_eSond_v0_part01.zip`
- `artefacts_modeles_sources_eSond_v0_part02.zip`
- `artefacts_modeles_sources_eSond_v0_part03.zip`
- `artefacts_modeles_sources_eSond_v0_part04.zip`

Chaque volume contient `PART_MANIFEST.csv` (chemin d'origine, taille, SHA-256), et chaque archive reste inférieure à 200 MiB.

Placer `Amodel_eSond_v0.zip`, les quatre volumes et `assemble_Amodel_eSond_v0.py` dans le même répertoire, puis exécuter :

```bash
python assemble_Amodel_eSond_v0.py --archives-dir . --output ./Amodel_eSond_v0_complete
```

Le script extrait l'audit et les originaux sous `originals/`, puis vérifie les 7 142 fichiers contre `serialized_artifact_raw_manifest.json`. Il ne désérialise pas les checkpoints et n'exécute pas TorchScript.
