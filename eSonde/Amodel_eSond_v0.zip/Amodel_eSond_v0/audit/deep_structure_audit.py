from pathlib import Path
import csv,json,zipfile,struct,hashlib,sys,time
import numpy as np
ROOTS=[Path('/mnt/data/esonde_work/input_sources'),Path('/mnt/data/esonde_work/input_ex12')]
report={'zip_archives':[],'npz_archives':[],'npy_files':[],'csv_files':[],'errors':[],'counts':{}}
for root in ROOTS:
 for p in root.rglob('*'):
  if not p.is_file(): continue
  ext=p.suffix.lower(); report['counts'][ext]=report['counts'].get(ext,0)+1
  rel=f'{root.name}/{p.relative_to(root)}'
  if ext=='.zip':
   try:
    with zipfile.ZipFile(p) as z:
     bad=z.testzip(); report['zip_archives'].append({'path':rel,'entries':len(z.infolist()),'crc':'PASS' if bad is None else 'FAIL','bad_member':bad})
     if bad: report['errors'].append({'path':rel,'type':'zip_crc','member':bad})
   except Exception as e: report['errors'].append({'path':rel,'type':'zip_open','error':str(e)[:500]})
  elif ext=='.npz':
   try:
    with zipfile.ZipFile(p) as z:
     bad=z.testzip(); members=[]
     if bad: raise ValueError(f'CRC error: {bad}')
     for name in z.namelist():
      if not name.endswith('.npy'): continue
      with z.open(name) as f:
       version=np.lib.format.read_magic(f)
       shape,fortran,dtype=(np.lib.format.read_array_header_1_0(f,max_header_size=100000) if version==(1,0) else np.lib.format.read_array_header_2_0(f,max_header_size=100000))
       if dtype.hasobject: raise ValueError(f'Object dtype interdit: {name}')
       members.append({'array':name,'shape':list(shape),'dtype':str(dtype),'fortran_order':bool(fortran)})
     report['npz_archives'].append({'path':rel,'arrays':members,'status':'PASS'})
   except Exception as e:
    report['npz_archives'].append({'path':rel,'status':'ERROR','error':str(e)[:500]})
    report['errors'].append({'path':rel,'type':'npz_structure','error':str(e)[:500]})
  elif ext=='.npy':
   try:
    with p.open('rb') as f:
     version=np.lib.format.read_magic(f); shape,fortran,dtype=(np.lib.format.read_array_header_1_0(f,max_header_size=100000) if version==(1,0) else np.lib.format.read_array_header_2_0(f,max_header_size=100000))
     if dtype.hasobject: raise ValueError('Object dtype interdit')
    report['npy_files'].append({'path':rel,'shape':list(shape),'dtype':str(dtype),'status':'PASS'})
   except Exception as e:
    report['npy_files'].append({'path':rel,'status':'ERROR','error':str(e)[:500]});report['errors'].append({'path':rel,'type':'npy_structure','error':str(e)[:500]})
  elif ext=='.csv':
   try:
    with p.open(encoding='utf-8-sig',newline='') as f:
     reader=csv.reader(f); header=next(reader,None); n=0
     if header is None: raise ValueError('CSV vide')
     for row in reader:
      n+=1
      if len(row)!=len(header): raise ValueError(f'ligne {n+1}: {len(row)} champs vs {len(header)}')
    report['csv_files'].append({'path':rel,'columns':len(header),'data_rows':n,'status':'PASS'})
   except Exception as e:
    report['csv_files'].append({'path':rel,'status':'ERROR','error':str(e)[:500]});report['errors'].append({'path':rel,'type':'csv_shape','error':str(e)[:500]})
report['summary']={'zip_tested':len(report['zip_archives']),'zip_crc_fail':sum(x['crc']!='PASS' for x in report['zip_archives']),'npz_tested':len(report['npz_archives']),'npz_fail':sum(x['status']!='PASS' for x in report['npz_archives']),'npy_tested':len(report['npy_files']),'npy_fail':sum(x['status']!='PASS' for x in report['npy_files']),'csv_tested':len(report['csv_files']),'csv_fail':sum(x['status']!='PASS' for x in report['csv_files']),'errors':len(report['errors'])}
out=Path('/mnt/data/esonde_work/audit/deep_structure_audit.json');out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report['summary'],indent=2));
for e in report['errors'][:30]: print('ERROR',e)
