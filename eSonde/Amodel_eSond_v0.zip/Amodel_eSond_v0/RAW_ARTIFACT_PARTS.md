# Artefacts bruts Amodel — quatre volumes complémentaires

Le corpus comprend 7 133 checkpoints `.pt` (dont 22 TorchScript), 8 fichiers `.joblib` et 1 Parquet : 7 142 artefacts, 509 753 792 octets. Les octets originaux sont répartis dans quatre archives : `artefacts_modeles_sources_eSond_v0_part01.zip` à `artefacts_modeles_sources_eSond_v0_part04.zip`. Chaque volume est inférieur à 200 MiB.

Placer `Amodel_eSond_v0.zip`, les quatre volumes et `assemble_Amodel_eSond_v0.py` dans le même répertoire, puis exécuter :

```bash
python assemble_Amodel_eSond_v0.py --archives-dir . --output ./Amodel_eSond_v0_complete
```

Le script vérifie CRC, chemins d’extraction sûrs, taille et SHA-256 de chacun des 7 142 originaux contre `serialized_artifact_raw_manifest.json`. La reconstitution indépendante a passé 7 142/7 142 vérifications, sans manque, doublon ni divergence. Les originaux restent byte-for-byte ; le script ne désérialise aucun pickle et n’exécute pas TorchScript.
