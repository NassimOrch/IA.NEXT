#!/usr/bin/env python3
"""Safely assemble Amodel audit and all original serialized artifacts.

Place Amodel_eSond_v0.zip and the four artefacts_modeles_sources...partNN.zip
archives beside this script. Extraction copies bytes only; it does not
unpickle JOBLIB/.pt files or load/execute TorchScript graphs.
"""
from __future__ import annotations
import argparse, hashlib, json, shutil, zipfile
from pathlib import Path

PARTS = [f"artefacts_modeles_sources_eSond_v0_part{i:02d}.zip" for i in range(1, 5)]
AUDIT = "Amodel_eSond_v0.zip"

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def safe_extract(zf: zipfile.ZipFile, root: Path) -> None:
    root = root.resolve()
    for info in zf.infolist():
        dest = (root / info.filename).resolve()
        if dest != root and root not in dest.parents:
            raise RuntimeError(f"Archive path escapes destination: {info.filename}")
    zf.extractall(root)

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--archives-dir", default=".", help="directory containing the five ZIP archives")
    ap.add_argument("--output", default="./Amodel_eSond_v0_complete", help="output directory")
    args = ap.parse_args()
    archive_dir, out = Path(args.archives_dir).resolve(), Path(args.output).resolve()
    names = [AUDIT, *PARTS]
    for name in names:
        p = archive_dir / name
        if not p.is_file(): raise SystemExit(f"Missing archive: {p}")
        with zipfile.ZipFile(p) as zf:
            bad = zf.testzip()
            if bad: raise SystemExit(f"CRC failure: {name}: {bad}")
    if out.exists(): shutil.rmtree(out)
    out.mkdir(parents=True)
    for name in names:
        with zipfile.ZipFile(archive_dir / name) as zf: safe_extract(zf, out)
    manifest_path = out / "Amodel_eSond_v0" / "audit" / "serialized_artifact_incident" / "serialized_artifact_raw_manifest.json"
    if not manifest_path.is_file(): raise SystemExit(f"Raw artifact manifest missing: {manifest_path}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    failures = []
    for rec in manifest["artifacts"]:
        p = out / rec["archive_path"]
        if not p.is_file(): failures.append((rec["archive_path"], "MISSING")); continue
        if p.stat().st_size != rec["size_bytes"] or sha256(p) != rec["sha256"]:
            failures.append((rec["archive_path"], "SIZE_OR_SHA256_MISMATCH"))
    if failures:
        for row in failures[:30]: print(*row, sep=" | ")
        raise SystemExit(f"FAIL: {len(failures)} artifact(s) did not match the source manifest")
    counts = {}
    for rec in manifest["artifacts"]:
        ext = Path(rec["path"]).suffix.lower(); counts[ext] = counts.get(ext, 0) + 1
    print(json.dumps({"status":"PASS","output":str(out),"verified_artifacts":len(manifest["artifacts"]),"counts_by_extension":counts,"verified_bytes":sum(r["size_bytes"] for r in manifest["artifacts"]),"archives":names,"deserialization_or_execution":"NOT_PERFORMED"},ensure_ascii=False,indent=2))
    return 0

if __name__ == "__main__": raise SystemExit(main())
