# eSonde_v0 — paquet des essais comparatifs

Date du rapport : 08 novembre 2026 (Africa/Algiers)

## Contenu

- `benchmark/PRE_REGISTRATION.md` : protocole défini avant les essais.
- `benchmark/results/benchmark_runs.jsonl` : 200 ajustements principaux (5 jeux × 10 graines × 4 modèles).
- `benchmark/results/hybrid_benchmark_runs.jsonl` : 50 ajustements multi-familles (5 jeux × 5 graines × 2 modèles).
- `benchmark/results/extrapolation_stress_runs.jsonl` : 80 lignes de scores issues de 40 ajustements de stress sur 10 graines et 2 régimes.
- `benchmark/models/` : 50 états eSonde local et 25 états hybrides, sauvegardés en JSON.
- `benchmark/results/` : résumés, comparaisons appariées, audits de roundtrip, hachages de jeux et contrôles d'intégrité.
- `benchmark/scripts/` : scripts de benchmark, d'audit et de génération des rapports.
- `benchmark/plots_final/` et `rapport_testes_assets/` : figures utilisées dans le rapport.
- `runtime/Dmodel_eSond_v0/` : copie du runtime livré pour rendre les commandes et tests reproductibles.
- `reports/` : rapport scientifique et attestation, en PDF, TeX et Markdown, avec signatures Ed25519 détachées.

Le journal d'une première tentative principale interrompue (36 lignes) est préservé à part dans `benchmark/results/benchmark_interrupted_attempt1.jsonl` et exclu des résultats définitifs.

## Résultats essentiels

| Jeu | eSonde local | MLP apparié | SVM RBF | ExtraTrees |
|---|---:|---:|---:|---:|
| Diabetes — RMSE (↓) | 55.287 | 55.936 | 65.581 | 56.692 |
| Friedman-1 — RMSE (↓) | 1.757 | 2.102 | 2.125 | 2.304 |
| Breast Cancer — F1 macro (↑) | 0.9704 | 0.9800 | 0.9715 | 0.9646 |
| Two-Moons — F1 macro (↑) | 0.9283 | 0.8996 | 0.9229 | 0.9300 |
| 40D bruité — F1 macro (↑) | 0.8795 | 0.8879 | 0.9037 | 0.8950 |

Le résultat est dépendant du jeu. eSonde n'est pas le meilleur partout. Le rapport complet décrit les intervalles appariés, résultats hybrides, coûts, latences, stress d'extrapolation et limites de comparaison.

## Environnement mesuré

- Python 3.13.5
- NumPy 2.3.5
- SciPy 1.17.0
- scikit-learn 1.8.0
- Matplotlib 3.10.8
- Plateforme de référence : Linux x86_64 (glibc 2.41)

Le runtime importe son code depuis `runtime/Dmodel_eSond_v0/src`. Les scripts du benchmark nécessitent aussi SciPy, scikit-learn et Matplotlib pour les graphes.

## Reproduction

Créer un environnement isolé puis installer les versions consignées dans `requirements-benchmark.txt`. Depuis la racine de ce paquet :

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-benchmark.txt
export ESONDE_RUNTIME="$PWD/runtime/Dmodel_eSond_v0"
export PYTHONPATH="$ESONDE_RUNTIME/src"
cd benchmark

python scripts/run_benchmark.py --datasets all --seeds 11,23,37,53,71,89,101,131,151,173 --verify-snapshots
python scripts/run_hybrid_benchmark.py --datasets all --seeds 11,37,71,101,151
python scripts/run_extrapolation_stress.py --seeds 11,23,37,53,71,89,101,131,151,173
python scripts/summarize_results.py
python scripts/verify_model_roundtrip.py
python scripts/verify_hybrid_roundtrip.py
python scripts/final_integrity_audit.py
cd "$ESONDE_RUNTIME"
python -m unittest discover -s tests -v
```

**Attention :** les commandes de benchmark réentraînent les modèles et écrivent dans `benchmark/results`, `benchmark/models` et `benchmark/logs`. Pour préserver les résultats livrés, effectuer une copie de travail du répertoire `benchmark` avant de les relancer. Ne pas réutiliser les résultats scellés comme répertoire de sortie d'une nouvelle exécution.

L'audit final exécuté sur l'ensemble livré a obtenu : 200/200 lignes principales, 50/50 hybrides, 80/80 mesures de stress, 75/75 états eSonde hachés et rechargés, 9/9 snapshots vérifiés, 15/15 tests unitaires, zéro erreur d'intégrité relevée.

## Signatures

Les signatures `.sig` sont Ed25519 et détachées. La clé publique est `ESONDE_V0_RELEASE_PUBLIC_KEY.pem`. Elle vérifie l'intégrité des octets signés ; elle n'est ni une identité OpenAI ni une signature électronique qualifiée. La clé privée n'est pas distribuée.

Lancer `sh ./verify_test_signatures.sh` depuis la racine du paquet pour vérifier les six fichiers de rapport et attestation.
