#!/bin/sh
set -eu
PUB="$(dirname "$0")/ESONDE_V0_RELEASE_PUBLIC_KEY.pem"
verify_one() {
  file="$1"
  openssl pkeyutl -verify -pubin -inkey "$PUB" -rawin -in "$file" -sigfile "$file.sig" >/dev/null
  printf 'PASS %s\n' "$file"
}
verify_one reports/rapport_testes_eSonde_v0.pdf
verify_one reports/rapport_testes_eSonde_v0.tex
verify_one reports/rapport_testes_eSonde_v0.md
verify_one reports/integrite_chatgpt_testes_eSonde_v0.pdf
verify_one reports/integrite_chatgpt_testes_eSonde_v0.tex
verify_one reports/integrite_chatgpt_testes_eSonde_v0.md
