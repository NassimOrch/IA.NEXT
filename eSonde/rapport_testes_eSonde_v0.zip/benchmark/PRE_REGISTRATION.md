# Pré-enregistrement — Benchmark indépendant eSonde_v0 / références standards

Date de gel du protocole : 2026-11-08 (Africa/Algiers)

## Questions
1. Quel niveau de qualité prédictive eSonde_v0 obtient-il sur des tâches tabulaires réelles et synthétiques difficiles ?
2. Comment se compare-t-il à un MLP à une couche cachée et à budget de paramètres entraînables apparié, un SVM à noyau RBF et ExtraTrees ?
3. Comment varient les résultats selon les découpages, les familles de tâches, les coûts d'apprentissage et les latences ?

## Données
- Diabetes (scikit-learn, réel, régression, 442 x 10)
- Friedman-1 (synthétique, régression non linéaire, 1000 x 10, bruit 1.5)
- Wisconsin breast cancer diagnostic (scikit-learn, réel, binaire, 569 x 30)
- Two-moons (synthétique non linéaire bruité, 1200 x 2, bruit 0.28)
- Classification 40D synthétique (1200 x 40, 10 informatives, 8 redondantes, 22 bruit, flip_y 0.07)

Les sources des jeux réels sont les fonctions publiques `sklearn.datasets.load_diabetes` et `load_breast_cancer`. Les jeux synthétiques sont générés avec des seeds fixes (314159, 271828, 161803 respectivement). Hachages exacts consignés dans `results/dataset_manifest.json`.

## Découpage et prévention des fuites
Pour chacun des seeds 11, 23, 37, 53, 71, 89, 101, 131, 151, 173 : 20% test externe, puis 25% du reste en validation, soit 60/20/20. Pour la classification, les deux découpages sont stratifiés. Toute normalisation des entrées/cibles est ajustée sur train seulement. Le test extérieur n'intervient ni dans l'entraînement, ni dans l'early stopping, ni dans le choix d'hyperparamètres. Chaque modèle ne score le test qu'une fois par split.

## Modèles et réglages gelés
- eSonde_v0 local : 16 sondes, `families=('local',)`, lr 0.025, batch 32, max 100 epochs, patience 15, seed égal au seed de split. Le normaliseur interne est train-only.
- MLP : une couche cachée ReLU; largeur choisie pour minimiser l'écart entre son nombre exact de paramètres entraînables et celui d'eSonde. Adam, lr 0.001, alpha 1e-4, batch 32, max 100 epochs, early stopping sur la validation commune. Les entrées sont normalisées par un `StandardScaler` entraîné uniquement sur train.
- SVR/SVC RBF : SVR(C=10, epsilon=0.1, gamma=scale), SVC(C=2, gamma=scale, probability=True). StandardScaler train-only.
- ExtraTrees : 250 arbres, `min_samples_leaf=2`, `max_features=1.0` en régression et `sqrt` en classification. Paramètres fixés avant les runs, seed apparié.

Aucun des modèles standard n'est un composant interne d'eSonde. Les comparateurs sont des exécutables indépendants. Aucun hyperparamètre ne sera choisi à partir du test.

## Critères et mesures
Régression : MAE, RMSE, R². Classification : accuracy, balanced accuracy, macro-F1, log-loss, ROC-AUC, Brier. Coût : durée d'entraînement et latence de prédiction batch p50/p95 (25 répétitions). Les tailles des modèles non paramétriques sont rapportées par proxies explicites (support vectors, nœuds d'arbres), et ne sont pas faussement comparées comme nombre de paramètres entraînables.

## Interprétation statistique
Dix splits par jeu donnent une estimation de stabilité dépendante des découpages, pas dix échantillons indépendants de la population. Les moyennes, écarts-types et IC t à 95% sont descriptifs. Aucune conclusion de supériorité générale ne sera tirée d'un benchmark de cinq datasets. Les différences sont rapportées par dataset et métrique, sans agrégation arbitraire entre tâches de nature différente.

## Snapshots existants
Les neuf snapshots JSON livrés restent immuables : SHA-256 avant inférence, `inspect` et test de prédiction. Ils ne sont pas ré-entraînés ni modifiés. Les comparaisons appariées entraînent de nouveaux modèles sur les splits pré-définis, car ces snapshots sont des démonstrations sur d'autres données et ne sont pas des modèles pré-entraînés universels.

## Conservation
Chaque run complet est ajouté au JSONL immédiatement après son achèvement. Les scripts, manifests, sorties, modèles eSonde et versions des bibliothèques sont conservés. Aucun échec n'est supprimé.

## Journal d'exécution / première interruption
Une première tentative technique a été interrompue après neuf splits du seul jeu diabetes. Elle est conservée séparément sous `results/benchmark_interrupted_attempt1.jsonl` et n'entre pas dans les tableaux finaux : le lancement parallèle (`n_jobs=-1`) rendait les timings dépendants du nombre de workers disponibles et l'outil a interrompu le processus avant la fin du lot. La campagne finale utilise `n_jobs=1` et des lots append-only afin de stabiliser et préserver les mesures.
