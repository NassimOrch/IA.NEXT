#!/usr/bin/env python3
"""Audit saved eSonde JSON models by reproducing held-out metrics after reload."""
import json, hashlib
from pathlib import Path
import numpy as np
from sklearn.datasets import load_diabetes,load_breast_cancer,make_friedman1,make_moons,make_classification
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error,mean_squared_error,r2_score,accuracy_score,balanced_accuracy_score,f1_score,log_loss,roc_auc_score,brier_score_loss
from esonde.model import ESonde
ROOT=Path(__file__).resolve().parents[1]; MODELS=ROOT/'models'; OUT=ROOT/'results'
SEEDS=[11,23,37,53,71,89,101,131,151,173]
def ds():
 d={}
 x=load_diabetes(); d['diabetes_real_regression']=(x.data,x.target,'regression')
 x,y=make_friedman1(n_samples=1000,n_features=10,noise=1.5,random_state=314159); d['friedman1_nonlinear_regression']=(x,y,'regression')
 x=load_breast_cancer(); d['breast_cancer_real_binary']=(x.data,x.target,'classification')
 x,y=make_moons(n_samples=1200,noise=.28,random_state=271828); d['moons_noisy_nonlinear_binary']=(x,y,'classification')
 x,y=make_classification(n_samples=1200,n_features=40,n_informative=10,n_redundant=8,n_repeated=0,n_classes=2,n_clusters_per_class=2,class_sep=.85,flip_y=.07,random_state=161803); d['highdim_noisy_40d_binary']=(x,y,'classification')
 return d
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 runs=[json.loads(l) for l in (OUT/'benchmark_runs.jsonl').read_text().splitlines() if l.strip()]
 es_runs=[r for r in runs if r['model']=='eSonde_local']; datasets=ds(); checks=[]
 for r in es_runs:
  X,y,task=datasets[r['dataset']]; idx=np.arange(len(y)); strat=y if task=='classification' else None
  trv,te=train_test_split(idx,test_size=.2,random_state=r['seed'],stratify=strat)
  tr,va=train_test_split(trv,test_size=.25,random_state=r['seed']+1000,stratify=np.asarray(y)[trv] if task=='classification' else None)
  p=MODELS/f"{r['dataset']}__seed{r['seed']}__esonde.json"
  model=ESonde.load(p)
  if task=='regression':
   ym=float(np.mean(np.asarray(y)[tr])); ys=max(float(np.std(np.asarray(y)[tr])),1e-12)
   pred=np.asarray(model.predict(np.asarray(X)[te].tolist()))*ys+ym
   yt=np.asarray(y)[te]
   m={'mae':float(mean_absolute_error(yt,pred)),'rmse':float(mean_squared_error(yt,pred)**.5),'r2':float(r2_score(yt,pred))}
  else:
   yt=np.asarray(y)[te]; pred=np.asarray(model.predict(np.asarray(X)[te].tolist()),dtype=int); proba=np.asarray(model.predict_proba(np.asarray(X)[te].tolist()))
   m={'accuracy':float(accuracy_score(yt,pred)),'balanced_accuracy':float(balanced_accuracy_score(yt,pred)),
      'f1_macro':float(f1_score(yt,pred,average='macro')),'log_loss':float(log_loss(yt,proba,labels=[0,1])),
      'roc_auc':float(roc_auc_score(yt,proba[:,1])),'brier':float(brier_score_loss(yt,proba[:,1]))}
  maxdiff=max(abs(m[k]-r['metrics'][k]) for k in m)
  checks.append({'dataset':r['dataset'],'seed':r['seed'],'model_sha256':sha(p),'max_metric_abs_difference':maxdiff,'reload_metrics_match':maxdiff<1e-9})
 if len(checks)!=50 or not all(x['reload_metrics_match'] for x in checks): raise SystemExit('Round-trip audit failed')
 (OUT/'model_roundtrip_audit.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
 print(json.dumps({'models_reloaded':len(checks),'pass':sum(x['reload_metrics_match'] for x in checks),'max_abs_metric_difference':max(x['max_metric_abs_difference'] for x in checks)},indent=2))
if __name__=='__main__': main()
