#!/usr/bin/env python3
import json,csv,math
from pathlib import Path
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'results'; PLOTS=ROOT/'plots'; PLOTS.mkdir(exist_ok=True)
rows=[json.loads(x) for x in (OUT/'benchmark_runs.jsonl').read_text().splitlines() if x.strip()]
expect={'diabetes_real_regression','friedman1_nonlinear_regression','breast_cancer_real_binary','moons_noisy_nonlinear_binary','highdim_noisy_40d_binary'}
assert len(rows)==200, len(rows)
assert len({(r['dataset'],r['seed']) for r in rows})==50
assert all(sum(1 for x in rows if x['dataset']==ds and x['seed']==seed)==4 for ds in expect for seed in [11,23,37,53,71,89,101,131,151,173])
comparisons=[]
for ds in sorted(expect):
 group=[r for r in rows if r['dataset']==ds]
 task=group[0]['task']; primary='rmse' if task=='regression' else 'f1_macro'
 by={(r['seed'],r['model']):r for r in group}
 for baseline in ['MLP_param_matched','RBF_SVM','ExtraTrees']:
  e=np.array([by[(s,'eSonde_local')]['metrics'][primary] for s in [11,23,37,53,71,89,101,131,151,173]])
  b=np.array([by[(s,baseline)]['metrics'][primary] for s in [11,23,37,53,71,89,101,131,151,173]])
  delta=e-b; mean=float(delta.mean()); sd=float(delta.std(ddof=1)); half=float(stats.t.ppf(.975,9)*stats.sem(delta))
  wins=int(np.sum(e<b)) if task=='regression' else int(np.sum(e>b))
  ties=int(np.sum(np.isclose(e,b,rtol=0,atol=1e-12)))
  et=np.mean([by[(s,'eSonde_local')]['train_seconds'] for s in [11,23,37,53,71,89,101,131,151,173]])
  bt=np.mean([by[(s,baseline)]['train_seconds'] for s in [11,23,37,53,71,89,101,131,151,173]])
  ep=np.mean([by[(s,'eSonde_local')]['timing']['batch_p50_seconds'] for s in [11,23,37,53,71,89,101,131,151,173]])
  bp=np.mean([by[(s,baseline)]['timing']['batch_p50_seconds'] for s in [11,23,37,53,71,89,101,131,151,173]])
  comparisons.append({'dataset':ds,'task':task,'primary_metric':primary,'contrast':f'eSonde_local - {baseline}',
   'delta_mean':mean,'delta_sd':sd,'delta_ci95_low':mean-half,'delta_ci95_high':mean+half,
   'eSonde_wins':wins,'ties':ties,'baseline_wins':10-wins-ties,
   'mean_train_time_ratio_eSonde_over_baseline':float(et/max(bt,1e-12)),
   'mean_batch_p50_ratio_eSonde_over_baseline':float(ep/max(bp,1e-12)),
   'interpretation_rule':'negative delta favors eSonde for RMSE; positive delta favors eSonde for macro-F1'})
with (OUT/'paired_comparisons.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(comparisons[0]));w.writeheader();w.writerows(comparisons)
(OUT/'paired_comparisons.json').write_text(json.dumps(comparisons,indent=2),encoding='utf-8')
# Main metric plots
summ=json.loads((OUT/'benchmark_summary.json').read_text())
models=['eSonde_local','MLP_param_matched','RBF_SVM','ExtraTrees']
for task,metric,title,dslist in [
 ('regression','rmse','Regression RMSE (lower is better)',['diabetes_real_regression','friedman1_nonlinear_regression']),
 ('classification','f1_macro','Classification macro-F1 (higher is better)',['breast_cancer_real_binary','moons_noisy_nonlinear_binary','highdim_noisy_40d_binary'])]:
 fig,ax=plt.subplots(figsize=(11,5.6)); x=np.arange(len(dslist)); width=.18
 for j,m in enumerate(models):
  means=[];sds=[]
  for ds in dslist:
   r=next(q for q in summ if q['dataset']==ds and q['model']==m)
   means.append(r[metric+'_mean']);sds.append(r[metric+'_sd'])
  ax.bar(x+(j-1.5)*width,means,width,label=m,yerr=sds,capsize=3)
 ax.set_xticks(x);ax.set_xticklabels(dslist,rotation=13,ha='right');ax.set_ylabel(metric);ax.set_title(title);ax.legend();ax.grid(axis='y',alpha=.25);fig.tight_layout()
 fig.savefig(PLOTS / f'{task}_metrics.png',dpi=180);plt.close(fig)
# training time log chart
fig,ax=plt.subplots(figsize=(11,5.6)); dslist=sorted(expect); x=np.arange(len(dslist));width=.18
for j,m in enumerate(models):
 vals=[next(q for q in summ if q['dataset']==ds and q['model']==m)['train_seconds_mean'] for ds in dslist]
 ax.bar(x+(j-1.5)*width,vals,width,label=m)
ax.set_yscale('log');ax.set_xticks(x);ax.set_xticklabels(dslist,rotation=13,ha='right');ax.set_ylabel('Mean training seconds (log scale)');ax.set_title('Training cost per fit');ax.legend();ax.grid(axis='y',alpha=.25);fig.tight_layout();fig.savefig(PLOTS/'training_time.png',dpi=180);plt.close(fig)
# Extrapolation graph
ex=json.loads((OUT/'extrapolation_stress_summary.json').read_text())
fig,ax=plt.subplots(figsize=(8.5,5.2)); names=['eSonde_local','MLP_param_matched','RBF_SVR','ExtraTrees'];xx=np.arange(2);ww=.18
for j,m in enumerate(names):
 vals=[next(q for q in ex if q['model']==m and q['regime']==reg)['rmse_mean'] for reg in ['interpolation','extrapolation']]
 sds=[next(q for q in ex if q['model']==m and q['regime']==reg)['rmse_sd'] for reg in ['interpolation','extrapolation']]
 ax.bar(xx+(j-1.5)*ww,vals,ww,label=m,yerr=sds,capsize=3)
ax.set_xticks(xx);ax.set_xticklabels(['Interpolation','Extrapolation']);ax.set_ylabel('RMSE');ax.set_title('Controlled 1-D extrapolation stress');ax.legend();ax.grid(axis='y',alpha=.25);fig.tight_layout();fig.savefig(PLOTS/'extrapolation_stress.png',dpi=180);plt.close(fig)
# training parameter match audit
match=[]
for ds in sorted(expect):
 rr=[r for r in rows if r['dataset']==ds and r['model'] in ('eSonde_local','MLP_param_matched')]
 es={r['seed']:r['parameter_count'] for r in rr if r['model']=='eSonde_local'}
 ml={r['seed']:r['parameter_count'] for r in rr if r['model']=='MLP_param_matched'}
 for s in sorted(es): match.append({'dataset':ds,'seed':s,'eSonde_trainable_parameters':es[s],'MLP_trainable_parameters':ml[s],
  'absolute_relative_difference_percent':abs(es[s]-ml[s])/es[s]*100})
with (OUT/'parameter_match_audit.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(match[0]));w.writeheader();w.writerows(match)
# final invariants
assert all(abs(x['absolute_relative_difference_percent'])<=2 for x in match)
assert all(r['n_splits']==10 for r in summ)
print(json.dumps({'run_rows':len(rows),'splits':50,'models_per_split':4,'paired_contrasts':len(comparisons),
 'max_mlp_parameter_mismatch_percent':max(x['absolute_relative_difference_percent'] for x in match),
 'figures':sorted(p.name for p in PLOTS.glob('*.png'))},indent=2))
