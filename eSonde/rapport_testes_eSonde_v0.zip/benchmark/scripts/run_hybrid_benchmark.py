#!/usr/bin/env python3
"""Secondary 3-family eSonde benchmark; MLP parameter-matched to hybrid state."""
import sys,json,time,argparse
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'results'; MODELS=ROOT/'models'
sys.path.insert(0,str(ROOT/'scripts'))
from run_benchmark import make_datasets,matched_hidden_width,train_mlp,predict_timing,metric_dict,sha256
from esonde.model import ESonde
SEEDS=[11,37,71,101,151]

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--datasets',default='all');ap.add_argument('--seeds',default=','.join(map(str,SEEDS)));ap.add_argument('--append',action='store_true');args=ap.parse_args()
 path=OUT/'hybrid_benchmark_runs.jsonl'
 if not args.append and path.exists():path.unlink()
 datasets=make_datasets();names=list(datasets) if args.datasets=='all' else args.datasets.split(',')
 rows=[]
 for name in names:
  X,y,task,desc=datasets[name]
  for seed in [int(s) for s in args.seeds.split(',') if s]:
   idx=np.arange(len(y));strat=y if task=='classification' else None
   trv,te=__import__('sklearn.model_selection').model_selection.train_test_split(idx,test_size=.2,random_state=seed,stratify=strat)
   strat2=np.asarray(y)[trv] if task=='classification' else None
   tr,va=__import__('sklearn.model_selection').model_selection.train_test_split(trv,test_size=.25,random_state=seed+1000,stratify=strat2)
   Xtr,Xv,Xte=X[tr],X[va],X[te];ytr,yv,yte=np.asarray(y)[tr],np.asarray(y)[va],np.asarray(y)[te]
   if task=='regression':ym=float(np.mean(ytr));ys=max(float(np.std(ytr)),1e-12);ytr_s=(ytr-ym)/ys;yv_s=(yv-ym)/ys
   else:ym,ys=0.0,1.0;ytr_s=ytr;yv_s=yv
   base={'dataset':name,'description':desc,'task':task,'seed':seed,'n_train':len(tr),'n_validation':len(va),'n_test':len(te),'n_features':X.shape[1]}
   es=ESonde(task=task,n_probes=16,families=('local','coverage','interaction'),seed=seed,learning_rate=.025,batch_size=32,epochs=100,patience=15)
   t=time.perf_counter();fit=es.fit(Xtr.tolist(),ytr_s.tolist() if task=='regression' else ytr.tolist(),Xv.tolist(),yv_s.tolist() if task=='regression' else yv.tolist());train_s=time.perf_counter()-t
   p=MODELS/f'{name}__seed{seed}__esonde_hybrid.json';es.save(p)
   if task=='regression':
    fn=lambda xx:np.asarray(es.predict(np.asarray(xx).tolist()))*ys+ym;pred=fn(Xte);metrics=metric_dict(task,yte,pred)
   else:
    fn=lambda xx:np.asarray(es.predict_proba(np.asarray(xx).tolist()));proba=fn(Xte);pred=np.asarray(es.predict(np.asarray(Xte).tolist()),dtype=int);metrics=metric_dict(task,yte,pred,proba)
   er={**base,'model':'eSonde_hybrid','families':es.families,'n_probes':es.n_probes,'fit':fit,'parameter_count':es.trainable_parameter_count(),
      'train_seconds':train_s,'metrics':metrics,'timing':predict_timing(fn,Xte),'model_sha256':sha256(p)}
   rows.append(er)
   width,mp=matched_hidden_width(X.shape[1],1 if task=='regression' else len(np.unique(ytr)),es.trainable_parameter_count())
   t=time.perf_counter();mlp,sc,info=train_mlp(Xtr,ytr,Xv,yv,task,seed,width,ym,ys);mts=time.perf_counter()-t
   if task=='regression':
    fn=lambda xx:mlp.predict(sc.transform(xx))*ys+ym;pred=fn(Xte);metrics=metric_dict(task,yte,pred)
   else:
    fn=lambda xx:mlp.predict_proba(sc.transform(xx));proba=fn(Xte);pred=mlp.predict(sc.transform(Xte));metrics=metric_dict(task,yte,pred,proba)
   rows.append({**base,'model':'MLP_param_matched_to_hybrid','hidden_width':width,'parameter_count':mp,'fit':info,
      'train_seconds':mts,'metrics':metrics,'timing':predict_timing(fn,Xte),'parameter_delta':int(mp-es.trainable_parameter_count())})
   with path.open('a',encoding='utf-8') as f:
    f.write(json.dumps(er,allow_nan=False)+'\n');f.write(json.dumps(rows[-1],allow_nan=False)+'\n')
   print('completed',name,'seed',seed,'params',er['parameter_count'],mp,flush=True)
 # summary all records after chunk
 allrows=[json.loads(x) for x in path.read_text().splitlines() if x.strip()]
 summary=[]
 for name in sorted(set(r['dataset'] for r in allrows)):
  for model in ['eSonde_hybrid','MLP_param_matched_to_hybrid']:
   rr=[r for r in allrows if r['dataset']==name and r['model']==model];task=rr[0]['task'];metric='rmse' if task=='regression' else 'f1_macro'
   vals=np.asarray([r['metrics'][metric] for r in rr]);summary.append({'dataset':name,'task':task,'model':model,'n':len(rr),metric+'_mean':float(vals.mean()),metric+'_sd':float(vals.std(ddof=1)) if len(vals)>1 else None,
     'train_seconds_mean':float(np.mean([r['train_seconds'] for r in rr])),'parameter_count_mean':float(np.mean([r['parameter_count'] for r in rr]))})
 (OUT/'hybrid_benchmark_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
 print(json.dumps({'completed_rows':len(allrows),'completed_splits':len(allrows)//2,'summary':summary},indent=2))
if __name__=='__main__':main()
