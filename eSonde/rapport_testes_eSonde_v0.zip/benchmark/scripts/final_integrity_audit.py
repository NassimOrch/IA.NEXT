#!/usr/bin/env python3
"""Independent verification of the eSonde_v0 benchmark artifacts.
Recomputes dataset hashes, pairing, metrics summaries, model-file hashes,
round-trip checks, snapshot integrity and row coverage from raw run logs.
"""
from __future__ import annotations
import json, hashlib, collections, platform, sys, os, csv, math
from pathlib import Path
import numpy as np
import scipy, sklearn
from scipy import stats
from sklearn.datasets import load_diabetes, load_breast_cancer, make_friedman1, make_moons, make_classification

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results'; MODELS=ROOT/'models'
SEEDS=[11,23,37,53,71,89,101,131,151,173]
HYBRID_SEEDS=[11,37,71,101,151]
DATASETS=['diabetes_real_regression','friedman1_nonlinear_regression','breast_cancer_real_binary','moons_noisy_nonlinear_binary','highdim_noisy_40d_binary']
EXPECTED_MAIN={'eSonde_local','MLP_param_matched','RBF_SVM','ExtraTrees'}
EXPECTED_HYBRID={'eSonde_hybrid','MLP_param_matched_to_hybrid'}

def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def read_jsonl(p):
 rows=[]
 for no,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
  if line.strip():
   try: rows.append(json.loads(line))
   except Exception as e: raise RuntimeError(f'{p}:{no}: {e}')
 return rows
def datasets():
 out={}
 d=load_diabetes();out['diabetes_real_regression']=(d.data.astype(float),d.target.astype(float),'regression')
 X,y=make_friedman1(n_samples=1000,n_features=10,noise=1.5,random_state=314159);out['friedman1_nonlinear_regression']=(X.astype(float),y.astype(float),'regression')
 d=load_breast_cancer();out['breast_cancer_real_binary']=(d.data.astype(float),d.target.astype(int),'classification')
 X,y=make_moons(n_samples=1200,noise=.28,random_state=271828);out['moons_noisy_nonlinear_binary']=(X.astype(float),y.astype(int),'classification')
 X,y=make_classification(n_samples=1200,n_features=40,n_informative=10,n_redundant=8,n_repeated=0,n_classes=2,n_clusters_per_class=2,class_sep=.85,flip_y=.07,random_state=161803);out['highdim_noisy_40d_binary']=(X.astype(float),y.astype(int),'classification')
 return out

def ci(a):
 a=np.asarray(a,float); m=float(a.mean()); sd=float(a.std(ddof=1)); half=float(stats.t.ppf(.975,len(a)-1)*stats.sem(a)) if len(a)>1 else None
 return {'n':len(a),'mean':m,'sd':sd,'ci95_low':m-half if half is not None else None,'ci95_high':m+half if half is not None else None}

def main():
 errors=[]; checks={}
 ds=datasets(); manifest=json.loads((OUT/'dataset_manifest.json').read_text())
 md={x['name']:x for x in manifest}; dataset_rows=[]
 for name,(X,y,task) in ds.items():
  hx=sha_bytes(np.ascontiguousarray(X).tobytes());hy=sha_bytes(np.ascontiguousarray(y).tobytes())
  ok=hx==md[name]['X_sha256'] and hy==md[name]['y_sha256'] and len(y)==md[name]['n'] and X.shape[1]==md[name]['d']
  checks[f'dataset_hash:{name}']='PASS' if ok else 'FAIL'
  dataset_rows.append({'name':name,'task':task,'n':int(len(y)),'d':int(X.shape[1]),'X_sha256':hx,'y_sha256':hy,'manifest_match':ok})
  if not ok: errors.append(f'Dataset hash/dimension mismatch: {name}')
 main=read_jsonl(OUT/'benchmark_runs.jsonl'); checks['main_jsonl_parse']='PASS'
 key=lambda r:(r['dataset'],r['seed'],r['model'])
 counts=collections.Counter(key(r) for r in main)
 main_cov=(len(main)==200 and len(counts)==200 and set(r['dataset'] for r in main)==set(DATASETS)
  and set(r['seed'] for r in main)==set(SEEDS) and set(r['model'] for r in main)==EXPECTED_MAIN
  and all(counts[(d,s,m)]==1 for d in DATASETS for s in SEEDS for m in EXPECTED_MAIN))
 checks['main_coverage']='PASS' if main_cov else 'FAIL'
 if not main_cov: errors.append('Main coverage/duplicate check failed')
 if any(not r.get('test_scored_once_after_fit') for r in main): errors.append('Main row lacks test_scored_once_after_fit marker')
 checks['main_test_eval_marker']='PASS' if not any(not r.get('test_scored_once_after_fit') for r in main) else 'FAIL'
 # Summary recomputation and model integrity
 roundtrip=json.loads((OUT/'model_roundtrip_audit.json').read_text())
 roundmap={(r['dataset'],r['seed']):r for r in roundtrip}
 e_rows=[r for r in main if r['model']=='eSonde_local']
 file_ok=True
 for r in e_rows:
  p=MODELS/f"{r['dataset']}__seed{r['seed']}__esonde.json"
  if not p.is_file() or sha_file(p)!=r['model_sha256']: file_ok=False
 checks['main_model_hashes']='PASS' if file_ok and len(e_rows)==50 else 'FAIL'
 if not file_ok: errors.append('Main eSonde saved model hash mismatch/missing')
 rt_ok=(len(roundtrip)==50 and all(x.get('reload_metrics_match') and x.get('max_metric_abs_difference')==0.0 for x in roundtrip))
 checks['main_roundtrip']='PASS' if rt_ok else 'FAIL'
 if not rt_ok: errors.append('Main model roundtrip audit incomplete or failed')
 summary=[]
 metric_names={'regression':['rmse','mae','r2'],'classification':['accuracy','balanced_accuracy','f1_macro','log_loss','roc_auc','brier']}
 for d in DATASETS:
  for model in sorted(EXPECTED_MAIN):
   rr=[r for r in main if r['dataset']==d and r['model']==model]
   task=rr[0]['task']; metric='rmse' if task=='regression' else 'f1_macro'
   rsum={'dataset':d,'task':task,'model':model,'n_splits':len(rr),'primary_metric':metric,'primary':ci([r['metrics'][metric] for r in rr]),
    'train_seconds':ci([r['train_seconds'] for r in rr]),'batch_p50_seconds':ci([r['timing']['batch_p50_seconds'] for r in rr]),
    'batch_p95_seconds':ci([r['timing']['batch_p95_seconds'] for r in rr])}
   for m in metric_names[task]: rsum[m]=ci([r['metrics'][m] for r in rr])
   summary.append(rsum)
 # recompute main paired CIs
 paired=[]
 for d in DATASETS:
  task=next(r['task'] for r in main if r['dataset']==d); metric='rmse' if task=='regression' else 'f1_macro'
  lookup={(r['seed'],r['model']):r for r in main if r['dataset']==d}
  for base in ['MLP_param_matched','RBF_SVM','ExtraTrees']:
   delta=np.array([lookup[(s,'eSonde_local')]['metrics'][metric]-lookup[(s,base)]['metrics'][metric] for s in SEEDS])
   win=(delta<0) if task=='regression' else (delta>0)
   rr=ci(delta);paired.append({'dataset':d,'task':task,'metric':metric,'contrast':f'eSonde_local - {base}',**rr,
    'esonde_wins':int(win.sum()),'baseline_wins':int((~win & ~np.isclose(delta,0)).sum()),
    'mean_train_time_ratio':float(np.mean([lookup[(s,'eSonde_local')]['train_seconds']/lookup[(s,base)]['train_seconds'] for s in SEEDS]))})
 # MLP parameter matching
 match_rows=[r for r in csv.DictReader((OUT/'parameter_match_audit.csv').open())]
 mism=[float(r['absolute_relative_difference_percent']) for r in match_rows]
 checks['main_mlp_parameter_match']='PASS' if len(match_rows)==50 and max(mism)<2.0 else 'FAIL'
 if len(match_rows)!=50 or max(mism)>=2: errors.append('Main parameter matching outside expected tolerance')
 # Hybrid
 hybrid=read_jsonl(OUT/'hybrid_benchmark_runs.jsonl')
 hc=collections.Counter(key(r) for r in hybrid)
 hyb_cov=(len(hybrid)==50 and len(hc)==50 and set(r['dataset'] for r in hybrid)==set(DATASETS)
  and set(r['seed'] for r in hybrid)==set(HYBRID_SEEDS) and set(r['model'] for r in hybrid)==EXPECTED_HYBRID
  and all(hc[(d,s,m)]==1 for d in DATASETS for s in HYBRID_SEEDS for m in EXPECTED_HYBRID))
 checks['hybrid_coverage']='PASS' if hyb_cov else 'FAIL'
 if not hyb_cov: errors.append('Hybrid coverage/duplicate check failed')
 hyb_rt=json.loads((OUT/'hybrid_model_roundtrip_audit.json').read_text())
 hyb_rt_ok=(len(hyb_rt)==25 and all(x.get('pass') and x.get('max_metric_abs_difference')==0.0 for x in hyb_rt))
 checks['hybrid_roundtrip']='PASS' if hyb_rt_ok else 'FAIL'
 if not hyb_rt_ok: errors.append('Hybrid roundtrip incomplete or failed')
 hfiles_ok=True
 for r in [x for x in hybrid if x['model']=='eSonde_hybrid']:
  p=MODELS/f"{r['dataset']}__seed{r['seed']}__esonde_hybrid.json"
  if not p.is_file() or sha_file(p)!=r['model_sha256']: hfiles_ok=False
 checks['hybrid_model_hashes']='PASS' if hfiles_ok else 'FAIL'
 if not hfiles_ok: errors.append('Hybrid model file hash mismatch/missing')
 hybrid_summary=[]
 for d in DATASETS:
  for model in sorted(EXPECTED_HYBRID):
   rr=[r for r in hybrid if r['dataset']==d and r['model']==model]
   task=rr[0]['task'];metric='rmse' if task=='regression' else 'f1_macro'
   hybrid_summary.append({'dataset':d,'task':task,'model':model,'n_splits':len(rr),'primary_metric':metric,
    'primary':ci([r['metrics'][metric] for r in rr]),'train_seconds':ci([r['train_seconds'] for r in rr]),
    'parameter_count_mean':float(np.mean([r['parameter_count'] for r in rr]))})
 # paired hybrid vs same seed subset of main standard models
 hybrid_paired=[]
 for d in DATASETS:
  task=next(r['task'] for r in hybrid if r['dataset']==d); metric='rmse' if task=='regression' else 'f1_macro'
  hl={(r['seed'],r['model']):r for r in hybrid if r['dataset']==d}
  ml={(r['seed'],r['model']):r for r in main if r['dataset']==d}
  for base in ['MLP_param_matched_to_hybrid','RBF_SVM','ExtraTrees']:
   vals=[]
   for s in HYBRID_SEEDS:
    e=hl[(s,'eSonde_hybrid')]['metrics'][metric]
    b=hl[(s,'MLP_param_matched_to_hybrid')]['metrics'][metric] if base=='MLP_param_matched_to_hybrid' else ml[(s,base)]['metrics'][metric]
    vals.append(e-b)
   a=np.asarray(vals); st=ci(a); win=int(np.sum(a<0)) if task=='regression' else int(np.sum(a>0))
   hybrid_paired.append({'dataset':d,'task':task,'metric':metric,'contrast':f'eSonde_hybrid - {base}',**st,'esonde_wins':win,
    'baseline_wins':int(len(a)-win)})
 # Extrapolation
 stress=read_jsonl(OUT/'extrapolation_stress_runs.jsonl')
 scov=(len(stress)==80 and set(r['seed'] for r in stress)==set(SEEDS)
   and set(r['model'] for r in stress)=={'eSonde_local','MLP_param_matched','RBF_SVR','ExtraTrees'}
   and set(r['regime'] for r in stress)=={'interpolation','extrapolation'})
 checks['extrapolation_stress_coverage']='PASS' if scov else 'FAIL'
 if not scov: errors.append('Extrapolation stress coverage failed')
 stress_summary=[]
 for model in sorted(set(r['model'] for r in stress)):
  for regime in ['interpolation','extrapolation']:
   rr=[r for r in stress if r['model']==model and r['regime']==regime]
   stress_summary.append({'model':model,'regime':regime,'rmse':ci([r['metrics']['rmse'] for r in rr]),
    'mae_mean':float(np.mean([r['metrics']['mae'] for r in rr])),'r2_mean':float(np.mean([r['metrics']['r2'] for r in rr])),
    'train_seconds_mean':float(np.mean([r['train_seconds'] for r in rr])),
    'out_of_support_fraction_mean':float(np.mean([r.get('out_of_support_fraction') for r in rr if r.get('out_of_support_fraction') is not None])) if any(r.get('out_of_support_fraction') is not None for r in rr) else None})
 # Snapshot audit
 snaps=json.loads((OUT/'snapshot_integrity_and_inference.json').read_text())
 snaps_ok=len(snaps)==9 and all(x['inspect']=='PASS' and x['inference']=='PASS' for x in snaps)
 checks['delivered_snapshots']='PASS' if snaps_ok else 'FAIL'
 if not snaps_ok: errors.append('Snapshot integrity/inference failure')
 # Initial interrupted attempt logged separately
 interrupted=read_jsonl(OUT/'benchmark_interrupted_attempt1.jsonl')
 checks['interrupted_attempt_preserved']='PASS' if len(interrupted)==36 else 'FAIL'
 # overall
 final={'audit_version':'1.0','created_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),
  'python':sys.version.split()[0],'platform':platform.platform(),'numpy':np.__version__,'scipy':scipy.__version__,'sklearn':sklearn.__version__,
  'seed_sets':{'main':SEEDS,'hybrid':HYBRID_SEEDS,'extrapolation_stress':SEEDS},
  'counts':{'datasets':len(ds),'main_rows':len(main),'main_splits':50,'models_per_main_split':4,'hybrid_rows':len(hybrid),'hybrid_splits':25,
    'stress_rows':len(stress),'stress_seed_regime_model_combinations':40,'eSonde_saved_models':len(e_rows)+sum(1 for r in hybrid if r['model']=='eSonde_hybrid'),
    'snapshots':len(snaps),'main_roundtrips':len(roundtrip),'hybrid_roundtrips':len(hyb_rt),'interrupted_attempt_rows':len(interrupted)},
  'parameter_matching':{'main_rows':len(match_rows),'mean_relative_difference_percent':float(np.mean(mism)),'max_relative_difference_percent':float(np.max(mism)),
    'hybrid_parameter_counts_by_dataset':{d:{m:float(np.mean([r['parameter_count'] for r in hybrid if r['dataset']==d and r['model']==m])) for m in sorted(EXPECTED_HYBRID)} for d in DATASETS}},
  'checks':checks,'errors':errors,'datasets':dataset_rows,'main_summary':summary,'main_paired_comparisons':paired,
  'hybrid_summary':hybrid_summary,'hybrid_paired_comparisons':hybrid_paired,'extrapolation_stress_summary':stress_summary,
  'notes':['Raw JSONL was parsed and checked for exact expected key coverage.',
   'Dataset hashes were regenerated from the frozen scripts and matched the manifest.',
   'The environment metadata file reflects the last high-dimensional batch process; campaign-wide seeds are reconstructed from raw logs.',
   'Confidence intervals treat repeated splits descriptively; splits reuse the same source dataset and are not independent population samples.',
   'No single aggregate score was formed across regression and classification tasks.']}
 if errors: status='FAIL'
 else: status='PASS'
 final['status']=status
 (OUT/'final_integrity_audit.json').write_text(json.dumps(final,indent=2,allow_nan=False),encoding='utf-8')
 # concise txt
 lines=[f'FINAL INTEGRITY AUDIT: {status}',f"main rows={len(main)} hybrid rows={len(hybrid)} stress rows={len(stress)}",
        f"eSonde saved models={final['counts']['eSonde_saved_models']} snapshots={len(snaps)}",
        f"main MLP parameter mismatch max={max(mism):.4f}% mean={np.mean(mism):.4f}%",
        f'errors={len(errors)}']
 lines += [f'{k}: {v}' for k,v in checks.items()]
 lines += [f'ERROR: {x}' for x in errors]
 (OUT/'final_integrity_audit.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 print('\n'.join(lines))
 if errors: raise SystemExit(1)
if __name__=='__main__': main()
