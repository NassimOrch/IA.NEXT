from pathlib import Path
import json, numpy as np
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'results'; P=ROOT/'plots_final'; P.mkdir(exist_ok=True)
s=json.loads((OUT/'benchmark_summary.json').read_text())
h=json.loads((OUT/'hybrid_benchmark_summary.json').read_text())
st=json.loads((OUT/'extrapolation_stress_summary.json').read_text())
order=['eSonde_local','MLP_param_matched','RBF_SVM','ExtraTrees']
labels=['eSonde local','MLP param. apparié','SVM RBF','ExtraTrees']
for ds in ['diabetes_real_regression','friedman1_nonlinear_regression','breast_cancer_real_binary','moons_noisy_nonlinear_binary','highdim_noisy_40d_binary']:
 rr=[next(x for x in s if x['dataset']==ds and x['model']==m) for m in order]
 task=rr[0]['task']; metric='rmse' if task=='regression' else 'f1_macro'; title=('RMSE (plus bas = meilleur)' if task=='regression' else 'F1 macro (plus haut = meilleur)')
 vals=[x[metric+'_mean'] for x in rr]; errs=[x[metric+'_sd'] for x in rr]
 fig,ax=plt.subplots(figsize=(8.8,5.2)); bars=ax.bar(labels,vals,yerr=errs,capsize=4)
 ax.set_title(ds.replace('_',' ')+' — '+title); ax.set_ylabel(metric); ax.grid(axis='y',alpha=.25);ax.set_axisbelow(True);ax.tick_params(axis='x',rotation=12)
 for b,v in zip(bars,vals): ax.annotate(f'{v:.4f}',(b.get_x()+b.get_width()/2,b.get_height()),xytext=(0,4),textcoords='offset points',ha='center',fontsize=8)
 fig.tight_layout();fig.savefig(P/f'{ds}_main.png',dpi=200);plt.close(fig)
# Primary local paired differences with CIs
import csv
pc=list(csv.DictReader((OUT/'paired_comparisons.csv').open()))
for task,dslist,metric in [('regression',['diabetes_real_regression','friedman1_nonlinear_regression'],'rmse'),('classification',['breast_cancer_real_binary','moons_noisy_nonlinear_binary','highdim_noisy_40d_binary'],'f1_macro')]:
 fig,ax=plt.subplots(figsize=(10,5.3)); y=[];x=[];lo=[];hi=[];labels2=[]
 for d in dslist:
  for b in ['MLP_param_matched','RBF_SVM','ExtraTrees']:
   r=next(z for z in pc if z['dataset']==d and z['contrast']==f'eSonde_local - {b}')
   x.append(float(r['delta_mean']));lo.append(float(r['delta_mean'])-float(r['delta_ci95_low']));hi.append(float(r['delta_ci95_high'])-float(r['delta_mean']))
   labels2.append(d.replace('_',' ')+' / '+b.replace('_',' '));y.append(len(y))
 ax.errorbar(x,y,xerr=[lo,hi],fmt='o',capsize=3);ax.axvline(0,linewidth=1);ax.set_yticks(y);ax.set_yticklabels(labels2,fontsize=8);ax.invert_yaxis();ax.set_xlabel('Différence moyenne eSonde − comparateur ('+metric+')');ax.set_title('Différences appariées, IC t descriptifs à 95%');ax.grid(axis='x',alpha=.25);fig.tight_layout();fig.savefig(P/f'paired_deltas_{task}.png',dpi=200);plt.close(fig)
# Hybrid only versus param-matched MLP
for task,dslist,metric in [('regression',['diabetes_real_regression','friedman1_nonlinear_regression'],'rmse'),('classification',['breast_cancer_real_binary','moons_noisy_nonlinear_binary','highdim_noisy_40d_binary'],'f1_macro')]:
 fig,ax=plt.subplots(figsize=(9.5,5.2)); x=np.arange(len(dslist));w=.34
 for j,(m,label) in enumerate([('eSonde_hybrid','eSonde hybride'),('MLP_param_matched_to_hybrid','MLP apparié')]):
  rr=[next(z for z in h if z['dataset']==d and z['model']==m) for d in dslist]
  vals=[z['mean'] for z in rr];errs=[z['sd'] for z in rr]
  ax.bar(x+(j-.5)*w,vals,w,label=label,yerr=errs,capsize=3)
 ax.set_xticks(x);ax.set_xticklabels([d.replace('_',' ') for d in dslist],rotation=12,ha='right');ax.set_ylabel(metric);ax.set_title('Campagne hybride — '+metric+' (5 partitions)');ax.legend();ax.grid(axis='y',alpha=.25);fig.tight_layout();fig.savefig(P/f'hybrid_{task}.png',dpi=200);plt.close(fig)
# extrapolation
models=['eSonde_local','MLP_param_matched','RBF_SVR','ExtraTrees'];labs=['eSonde local','MLP apparié','SVR RBF','ExtraTrees'];fig,ax=plt.subplots(figsize=(9,5.4));x=np.arange(2);w=.19
for j,(m,lab) in enumerate(zip(models,labs)):
 rs=[next(z for z in st if z['model']==m and z['regime']==reg) for reg in ['interpolation','extrapolation']]
 ax.bar(x+(j-1.5)*w,[z['rmse_mean'] for z in rs],w,label=lab,yerr=[z['rmse_sd'] for z in rs],capsize=3)
ax.set_xticks(x);ax.set_xticklabels(['Interpolation','Extrapolation']);ax.set_ylabel('RMSE');ax.set_title('Stress contrôlé 1D — moyenne ± écart-type (10 graines)');ax.legend();ax.grid(axis='y',alpha=.25);fig.tight_layout();fig.savefig(P/'extrapolation_stress_final.png',dpi=200);plt.close(fig)
print('figures',len(list(P.glob('*.png'))))
