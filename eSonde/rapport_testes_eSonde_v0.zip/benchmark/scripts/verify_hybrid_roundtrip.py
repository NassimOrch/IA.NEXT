#!/usr/bin/env python3
import json,hashlib
from pathlib import Path
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_diabetes,load_breast_cancer,make_friedman1,make_moons,make_classification
from sklearn.metrics import mean_squared_error,mean_absolute_error,r2_score,accuracy_score,balanced_accuracy_score,f1_score,log_loss,roc_auc_score,brier_score_loss
from esonde.model import ESonde
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'results';MODELS=ROOT/'models'
def data():
 d={};z=load_diabetes();d['diabetes_real_regression']=(z.data,z.target,'regression')
 x,y=make_friedman1(n_samples=1000,n_features=10,noise=1.5,random_state=314159);d['friedman1_nonlinear_regression']=(x,y,'regression')
 z=load_breast_cancer();d['breast_cancer_real_binary']=(z.data,z.target,'classification')
 x,y=make_moons(n_samples=1200,noise=.28,random_state=271828);d['moons_noisy_nonlinear_binary']=(x,y,'classification')
 x,y=make_classification(n_samples=1200,n_features=40,n_informative=10,n_redundant=8,n_repeated=0,n_classes=2,n_clusters_per_class=2,class_sep=.85,flip_y=.07,random_state=161803);d['highdim_noisy_40d_binary']=(x,y,'classification')
 return d
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 runs=[json.loads(x) for x in (OUT/'hybrid_benchmark_runs.jsonl').read_text().splitlines() if x.strip()];es=[r for r in runs if r['model']=='eSonde_hybrid'];ds=data();checks=[]
 for r in es:
  X,y,task=ds[r['dataset']];idx=np.arange(len(y));trv,te=train_test_split(idx,test_size=.2,random_state=r['seed'],stratify=y if task=='classification' else None)
  tr,va=train_test_split(trv,test_size=.25,random_state=r['seed']+1000,stratify=np.asarray(y)[trv] if task=='classification' else None)
  p=MODELS/f"{r['dataset']}__seed{r['seed']}__esonde_hybrid.json";m=ESonde.load(p)
  if task=='regression':
   ym=float(np.mean(np.asarray(y)[tr]));ys=max(float(np.std(np.asarray(y)[tr])),1e-12);pred=np.asarray(m.predict(np.asarray(X)[te].tolist()))*ys+ym;yt=np.asarray(y)[te]
   met={'mae':float(mean_absolute_error(yt,pred)),'rmse':float(mean_squared_error(yt,pred)**.5),'r2':float(r2_score(yt,pred))}
  else:
   yt=np.asarray(y)[te];pred=np.asarray(m.predict(np.asarray(X)[te].tolist()),int);pro=np.asarray(m.predict_proba(np.asarray(X)[te].tolist()))
   met={'accuracy':float(accuracy_score(yt,pred)),'balanced_accuracy':float(balanced_accuracy_score(yt,pred)),'f1_macro':float(f1_score(yt,pred,average='macro')),'log_loss':float(log_loss(yt,pro,labels=[0,1])),'roc_auc':float(roc_auc_score(yt,pro[:,1])),'brier':float(brier_score_loss(yt,pro[:,1]))}
  diff=max(abs(met[k]-r['metrics'][k]) for k in met)
  checks.append({'dataset':r['dataset'],'seed':r['seed'],'sha256':sha(p),'max_metric_abs_difference':diff,'pass':diff<1e-9})
 if len(checks)!=25 or not all(c['pass'] for c in checks):raise SystemExit('hybrid reload audit failed')
 (OUT/'hybrid_model_roundtrip_audit.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
 print(json.dumps({'models_reloaded':len(checks),'pass':sum(x['pass'] for x in checks),'max_abs_metric_difference':max(x['max_metric_abs_difference'] for x in checks)},indent=2))
if __name__=='__main__':main()
