#!/usr/bin/env python3
"""Dedicated 1-D interpolation/extrapolation stress test, paired by seed."""
from __future__ import annotations
import json,time,copy,argparse
from pathlib import Path
import numpy as np
from scipy import stats
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.neural_network import MLPRegressor
from sklearn.svm import SVR
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.metrics import mean_squared_error,mean_absolute_error,r2_score
from esonde.model import ESonde
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'results'; MODELS=ROOT/'models'
SEEDS=[11,23,37,53,71,89,101,131,151,173]

def f(x): return np.sin(2.4*x)+0.25*x

def metric(y,p): return {'rmse':float(mean_squared_error(y,p)**.5),'mae':float(mean_absolute_error(y,p)),'r2':float(r2_score(y,p))}

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--seeds',default=','.join(map(str,SEEDS))); ap.add_argument('--append',action='store_true'); args=ap.parse_args()
 runfile=OUT/'extrapolation_stress_runs.jsonl'
 if not args.append and runfile.exists(): runfile.unlink()
 rows=[]
 for seed in [int(x) for x in args.seeds.split(',') if x]:
  rng=np.random.default_rng(seed)
  xtr=rng.uniform(-2,2,500).reshape(-1,1); ytr=f(xtr[:,0])
  xv=rng.uniform(-2,2,150).reshape(-1,1); yv=f(xv[:,0])
  xi=rng.uniform(-2,2,300).reshape(-1,1); yi=f(xi[:,0])
  xo=np.where(rng.random(300)<.5,rng.uniform(-3.2,-2.2,300),rng.uniform(2.2,3.2,300)).reshape(-1,1); yo=f(xo[:,0])
  # eSonde
  es=ESonde(task='regression',n_probes=16,families=('local',),seed=seed,learning_rate=.025,batch_size=32,epochs=100,patience=15)
  t=time.perf_counter(); fit=es.fit(xtr.tolist(),ytr.tolist(),xv.tolist(),yv.tolist()); ts=time.perf_counter()-t
  for regime,XX,yy in [('interpolation',xi,yi),('extrapolation',xo,yo)]:
   p=np.asarray(es.predict(XX.tolist())); diag=es.diagnostics(XX.tolist())
   rows.append({'seed':seed,'model':'eSonde_local','regime':regime,'train_seconds':ts,'parameter_count':es.trainable_parameter_count(),
     'fit':fit,'metrics':metric(yy,p),'out_of_support_fraction':float(np.mean([d['out_of_support'] for d in diag]))})
  # matched MLP on train only, best validation RMSE
  target=es.trainable_parameter_count(); d=1; o=1
  h=min(range(1,100),key=lambda z:abs((d+1)*z+(z+1)*o-target))
  sc=StandardScaler().fit(xtr); A=sc.transform(xtr); V=sc.transform(xv)
  mlp=MLPRegressor(hidden_layer_sizes=(h,),solver='adam',alpha=1e-4,batch_size=32,learning_rate_init=.001,
     random_state=seed,max_iter=1,warm_start=True,tol=0,n_iter_no_change=1000)
  best=1e99; bestmodel=None; stale=0; be=0
  t=time.perf_counter()
  for ep in range(1,101):
   mlp.partial_fit(A,ytr); loss=float(np.mean((mlp.predict(V)-yv)**2))
   if loss<best-1e-9: best=loss; bestmodel=copy.deepcopy(mlp); stale=0; be=ep
   else: stale+=1
   if stale>=15: break
  mlp=bestmodel; ts=time.perf_counter()-t
  for regime,XX,yy in [('interpolation',xi,yi),('extrapolation',xo,yo)]:
   p=mlp.predict(sc.transform(XX)); rows.append({'seed':seed,'model':'MLP_param_matched','regime':regime,'train_seconds':ts,
     'parameter_count':int(sum(a.size for a in mlp.coefs_)+sum(a.size for a in mlp.intercepts_)),
     'fit':{'epochs_run':ep,'best_epoch':be,'best_validation_loss':best},'metrics':metric(yy,p)})
  # SVR
  svr=make_pipeline(StandardScaler(),SVR(C=10,epsilon=.1,gamma='scale'))
  t=time.perf_counter(); svr.fit(xtr,ytr); ts=time.perf_counter()-t
  for regime,XX,yy in [('interpolation',xi,yi),('extrapolation',xo,yo)]:
   p=svr.predict(XX); rows.append({'seed':seed,'model':'RBF_SVR','regime':regime,'train_seconds':ts,'parameter_count':None,
     'complexity_proxy_support_vectors':int(len(svr[-1].support_)),'metrics':metric(yy,p)})
  # ExtraTrees
  tree=ExtraTreesRegressor(n_estimators=250,min_samples_leaf=2,max_features=1.0,n_jobs=1,random_state=seed)
  t=time.perf_counter(); tree.fit(xtr,ytr); ts=time.perf_counter()-t
  for regime,XX,yy in [('interpolation',xi,yi),('extrapolation',xo,yo)]:
   p=tree.predict(XX); rows.append({'seed':seed,'model':'ExtraTrees','regime':regime,'train_seconds':ts,
     'complexity_proxy_nodes':int(sum(est.tree_.node_count for est in tree.estimators_)),'metrics':metric(yy,p)})
  with runfile.open('a',encoding='utf-8') as fp:
   for r in rows[-8:]: fp.write(json.dumps(r,allow_nan=False)+'\n')
  print('completed seed',seed,flush=True)
 # summary is recomputed from the complete append-only run registry.
 all_rows=[json.loads(line) for line in runfile.read_text().splitlines() if line.strip()]
 out=[]
 for model in sorted({r['model'] for r in all_rows}):
  for regime in ('interpolation','extrapolation'):
   rr=[r for r in all_rows if r['model']==model and r['regime']==regime]
   vals=np.array([r['metrics']['rmse'] for r in rr]); mean=float(vals.mean()); sd=float(vals.std(ddof=1)); half=float(stats.t.ppf(.975,len(vals)-1)*stats.sem(vals))
   out.append({'model':model,'regime':regime,'n':len(vals),'rmse_mean':mean,'rmse_sd':sd,'rmse_ci95_low':mean-half,'rmse_ci95_high':mean+half,
      'mae_mean':float(np.mean([r['metrics']['mae'] for r in rr])),'r2_mean':float(np.mean([r['metrics']['r2'] for r in rr])),
      'train_seconds_mean':float(np.mean([r['train_seconds'] for r in rr]))})
 (OUT/'extrapolation_stress_summary.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
 print(json.dumps(out,indent=2))
if __name__=='__main__': main()
