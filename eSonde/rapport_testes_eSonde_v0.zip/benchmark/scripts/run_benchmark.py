#!/usr/bin/env python3
"""Pre-registered paired benchmark for the released eSonde_v0 runtime.
All datasets/splits are generated before model fitting. Test data are scored once per fit.
"""
from __future__ import annotations
import os, sys, json, time, copy, hashlib, platform, statistics, warnings, argparse
from pathlib import Path
import numpy as np
from scipy import stats
from sklearn.datasets import load_diabetes, load_breast_cancer, make_friedman1, make_moons, make_classification
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.neural_network import MLPRegressor, MLPClassifier
from sklearn.svm import SVR, SVC
from sklearn.ensemble import ExtraTreesRegressor, ExtraTreesClassifier
from sklearn.metrics import (mean_absolute_error, mean_squared_error, r2_score,
    accuracy_score, balanced_accuracy_score, f1_score, log_loss, roc_auc_score,
    brier_score_loss)
from esonde.model import ESonde

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results'
MODELS = ROOT / 'models'
LOGS = ROOT / 'logs'
for p in (OUT, MODELS, LOGS): p.mkdir(parents=True, exist_ok=True)
SEEDS = [11, 23, 37, 53, 71, 89, 101, 131, 151, 173]
MAX_EPOCHS = 100
PATIENCE = 15
N_PROBES = 16
BATCH_SIZE = 32


def sha256(p: Path) -> str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()


def make_datasets():
    out={}
    d=load_diabetes()
    out['diabetes_real_regression']=(d.data.astype(float),d.target.astype(float),'regression','sklearn diabetes (real tabular)')
    X,y=make_friedman1(n_samples=1000,n_features=10,noise=1.5,random_state=314159)
    out['friedman1_nonlinear_regression']=(X.astype(float),y.astype(float),'regression','Friedman-1 synthetic nonlinear regression')
    d=load_breast_cancer()
    out['breast_cancer_real_binary']=(d.data.astype(float),d.target.astype(int),'classification','Wisconsin diagnostic breast-cancer (real tabular)')
    X,y=make_moons(n_samples=1200,noise=0.28,random_state=271828)
    out['moons_noisy_nonlinear_binary']=(X.astype(float),y.astype(int),'classification','Noisy two-moons synthetic classification')
    X,y=make_classification(n_samples=1200,n_features=40,n_informative=10,n_redundant=8,n_repeated=0,
        n_classes=2,n_clusters_per_class=2,class_sep=0.85,flip_y=0.07,random_state=161803)
    out['highdim_noisy_40d_binary']=(X.astype(float),y.astype(int),'classification','40D synthetic classification: 10 informative, 8 redundant, 22 noise')
    return out


def matched_hidden_width(d, out_dim, target_params):
    candidates=range(1,501)
    def p(h): return (d+1)*h + (h+1)*out_dim
    h=min(candidates,key=lambda k:(abs(p(k)-target_params),k))
    return h,p(h)


def train_mlp(Xtr, ytr, Xv, yv, task, seed, width, y_mean=0.0, y_scale=1.0):
    scaler=StandardScaler().fit(Xtr)
    A=scaler.transform(Xtr); V=scaler.transform(Xv)
    if task=='regression':
        model=MLPRegressor(hidden_layer_sizes=(width,),activation='relu',solver='adam',alpha=1e-4,
            batch_size=min(BATCH_SIZE,len(A)),learning_rate_init=1e-3,shuffle=True,random_state=seed,
            tol=0.0,n_iter_no_change=1000,max_iter=1,warm_start=True)
        yt=(np.asarray(ytr)-y_mean)/y_scale; yv0=(np.asarray(yv)-y_mean)/y_scale
        best=float('inf'); best_state=None; stale=0; best_epoch=0
        for ep in range(1,MAX_EPOCHS+1):
            model.partial_fit(A,yt)
            pv=model.predict(V)
            loss=float(np.mean((pv-yv0)**2))
            if loss < best - 1e-9:
                best=loss; best_state=copy.deepcopy(model); best_epoch=ep; stale=0
            else: stale+=1
            if stale>=PATIENCE: break
        model=best_state
        return model,scaler,{'best_epoch':best_epoch,'epochs_run':ep,'best_validation_loss':best,
            'parameter_count':int(sum(a.size for a in model.coefs_)+sum(a.size for a in model.intercepts_))}
    classes=np.unique(ytr)
    model=MLPClassifier(hidden_layer_sizes=(width,),activation='relu',solver='adam',alpha=1e-4,
        batch_size=min(BATCH_SIZE,len(A)),learning_rate_init=1e-3,shuffle=True,random_state=seed,
        tol=0.0,n_iter_no_change=1000,max_iter=1,warm_start=True)
    best=float('inf'); best_state=None; stale=0; best_epoch=0
    for ep in range(1,MAX_EPOCHS+1):
        if ep==1: model.partial_fit(A,ytr,classes=classes)
        else: model.partial_fit(A,ytr)
        pv=model.predict_proba(V)
        loss=float(log_loss(yv,pv,labels=classes))
        if loss < best - 1e-9:
            best=loss; best_state=copy.deepcopy(model); best_epoch=ep; stale=0
        else: stale+=1
        if stale>=PATIENCE: break
    model=best_state
    return model,scaler,{'best_epoch':best_epoch,'epochs_run':ep,'best_validation_loss':best,
        'parameter_count':int(sum(a.size for a in model.coefs_)+sum(a.size for a in model.intercepts_))}


def predict_timing(fn, X, repeats=25):
    # Batch latency for the whole held-out test; the model itself is not modified.
    times=[]
    for _ in range(repeats):
        t=time.perf_counter(); fn(X); times.append(time.perf_counter()-t)
    return {'batch_p50_seconds':float(np.median(times)),'batch_p95_seconds':float(np.quantile(times,.95)),
            'rows_per_second_at_p50':float(len(X)/max(np.median(times),1e-12))}


def metric_dict(task, y, pred, proba=None):
    if task=='regression':
        return {'mae':float(mean_absolute_error(y,pred)),
            'rmse':float(mean_squared_error(y,pred)**0.5),'r2':float(r2_score(y,pred))}
    return {'accuracy':float(accuracy_score(y,pred)),
        'balanced_accuracy':float(balanced_accuracy_score(y,pred)),
        'f1_macro':float(f1_score(y,pred,average='macro')),
        'log_loss':float(log_loss(y,proba,labels=[0,1])),
        'roc_auc':float(roc_auc_score(y,proba[:,1])),
        'brier':float(brier_score_loss(y,proba[:,1]))}


def run_one(name, data, seed):
    X,y,task,description=data
    idx=np.arange(len(y))
    strat=y if task=='classification' else None
    trv,te=train_test_split(idx,test_size=.20,random_state=seed,stratify=strat)
    strat2=np.asarray(y)[trv] if task=='classification' else None
    tr,va=train_test_split(trv,test_size=.25,random_state=seed+1000,stratify=strat2)
    Xtr,Xv,Xte=X[tr],X[va],X[te]
    ytr,yv,yte=np.asarray(y)[tr],np.asarray(y)[va],np.asarray(y)[te]
    # Shared train-only target scaling for regression. Same transform for all methods.
    if task=='regression':
        ym=float(np.mean(ytr)); ys=float(np.std(ytr)); ys=max(ys,1e-12)
        ytr_s=(ytr-ym)/ys; yv_s=(yv-ym)/ys
    else: ym,ys=0.0,1.0; ytr_s=ytr; yv_s=yv
    rowbase={'dataset':name,'description':description,'task':task,'seed':seed,
        'n_total':int(len(y)),'n_train':int(len(tr)),'n_validation':int(len(va)),'n_test':int(len(te)),
        'n_features':int(X.shape[1]),'test_scored_once_after_fit':True}
    rows=[]
    # eSonde local core; model's own feature normalization is train-only.
    es=ESonde(task=task,n_probes=N_PROBES,families=('local',),seed=seed,learning_rate=.025,
        batch_size=BATCH_SIZE,epochs=MAX_EPOCHS,patience=PATIENCE,temperature=1.0)
    t=time.perf_counter(); fit=es.fit(Xtr.tolist(),ytr_s.tolist() if task=='regression' else ytr.tolist(),
        Xv.tolist(),yv_s.tolist() if task=='regression' else yv.tolist()); train_s=time.perf_counter()-t
    es_path=MODELS/f'{name}__seed{seed}__esonde.json'; es.save(es_path)
    if task=='regression':
        fn=lambda xx: np.asarray(es.predict(np.asarray(xx).tolist()),dtype=float)*ys+ym
        pred=fn(Xte); metrics=metric_dict(task,yte,pred)
    else:
        fn=lambda xx: np.asarray(es.predict_proba(np.asarray(xx).tolist()),dtype=float)
        proba=fn(Xte); pred=np.asarray(es.predict(np.asarray(Xte).tolist()),dtype=int); metrics=metric_dict(task,yte,pred,proba)
    esrow={**rowbase,'model':'eSonde_local','train_seconds':train_s,'parameter_count':es.trainable_parameter_count(),
        'parameters_total':es.parameter_count(),'fit':fit,'metrics':metrics,'timing':predict_timing(fn,Xte),
        'model_sha256':sha256(es_path),'families':es.families,'n_probes':es.n_probes}
    rows.append(esrow)
    # Parameter-matched one-hidden-layer MLP, width chosen nearest to trainable eSonde count.
    out_dim=1 if task=='regression' else len(np.unique(ytr))
    width,mlp_params=matched_hidden_width(X.shape[1],out_dim,es.trainable_parameter_count())
    t=time.perf_counter(); mlp,scaler,mlpfit=train_mlp(Xtr,ytr, Xv,yv,task,seed,width,ym,ys); train_s=time.perf_counter()-t
    if task=='regression':
        fn=lambda xx: mlp.predict(scaler.transform(xx))*ys+ym
        pred=fn(Xte); metrics=metric_dict(task,yte,pred)
    else:
        fn=lambda xx: mlp.predict_proba(scaler.transform(xx))
        proba=fn(Xte); pred=mlp.predict(scaler.transform(Xte)); metrics=metric_dict(task,yte,pred,proba)
    rows.append({**rowbase,'model':'MLP_param_matched','train_seconds':train_s,'parameter_count':mlp_params,
        'hidden_width':width,'fit':mlpfit,'metrics':metrics,'timing':predict_timing(fn,Xte),
        'parameter_delta_vs_eSonde':int(mlp_params-es.trainable_parameter_count())})
    # RBF standard reference.
    if task=='regression': base=make_pipeline(StandardScaler(),SVR(C=10.0,epsilon=.1,kernel='rbf',gamma='scale'))
    else: base=make_pipeline(StandardScaler(),SVC(C=2.0,kernel='rbf',gamma='scale',probability=True,random_state=seed))
    t=time.perf_counter(); base.fit(Xtr,ytr_s if task=='regression' else ytr); train_s=time.perf_counter()-t
    if task=='regression':
        fn=lambda xx: base.predict(xx)*ys+ym; pred=fn(Xte); metrics=metric_dict(task,yte,pred)
    else:
        fn=lambda xx: base.predict_proba(xx); proba=fn(Xte); pred=base.predict(Xte); metrics=metric_dict(task,yte,pred,proba)
    rows.append({**rowbase,'model':'RBF_SVM','train_seconds':train_s,'parameter_count':None,
        'complexity_proxy':int(len(base[-1].support_vectors_)) if task=='classification' else int(len(base[-1].support_)),
        'metrics':metrics,'timing':predict_timing(fn,Xte),'hyperparameters':{'C':10.0,'epsilon':.1,'gamma':'scale'} if task=='regression' else {'C':2.0,'gamma':'scale','probability':True}})
    # Tree ensemble reference.
    if task=='regression': tree=ExtraTreesRegressor(n_estimators=250,min_samples_leaf=2,max_features=1.0,n_jobs=1,random_state=seed)
    else: tree=ExtraTreesClassifier(n_estimators=250,min_samples_leaf=2,max_features='sqrt',n_jobs=1,random_state=seed)
    t=time.perf_counter(); tree.fit(Xtr,ytr_s if task=='regression' else ytr); train_s=time.perf_counter()-t
    if task=='regression':
        fn=lambda xx: tree.predict(xx)*ys+ym; pred=fn(Xte); metrics=metric_dict(task,yte,pred)
    else:
        fn=lambda xx: tree.predict_proba(xx); proba=fn(Xte); pred=tree.predict(Xte); metrics=metric_dict(task,yte,pred,proba)
    node_count=int(sum(est.tree_.node_count for est in tree.estimators_))
    rows.append({**rowbase,'model':'ExtraTrees','train_seconds':train_s,'parameter_count':None,
        'complexity_proxy_total_tree_nodes':node_count,'metrics':metrics,'timing':predict_timing(fn,Xte),
        'hyperparameters':{'n_estimators':250,'min_samples_leaf':2,'max_features':1.0 if task=='regression' else 'sqrt'}})
    # append each complete run after it finishes, preserving partial progress.
    with (OUT/'benchmark_runs.jsonl').open('a',encoding='utf-8') as f:
        for r in rows: f.write(json.dumps(r,allow_nan=False)+'\n')
    return rows


def paired_summary(rows):
    grouped={}
    for r in rows: grouped.setdefault((r['dataset'],r['model']),[]).append(r)
    out=[]
    for (ds,model),items in sorted(grouped.items()):
        task=items[0]['task']; keys=['rmse','mae','r2'] if task=='regression' else ['accuracy','balanced_accuracy','f1_macro','log_loss','roc_auc','brier']
        rec={'dataset':ds,'task':task,'model':model,'n_splits':len(items),'train_seconds_mean':float(np.mean([x['train_seconds'] for x in items])),
             'train_seconds_sd':float(np.std([x['train_seconds'] for x in items],ddof=1))}
        for k in keys:
            vals=np.asarray([x['metrics'][k] for x in items],float)
            rec[k+'_mean']=float(np.mean(vals)); rec[k+'_sd']=float(np.std(vals,ddof=1))
            if len(vals)>1:
                half=float(stats.t.ppf(.975,len(vals)-1)*stats.sem(vals))
                rec[k+'_ci95_low']=float(np.mean(vals)-half); rec[k+'_ci95_high']=float(np.mean(vals)+half)
        out.append(rec)
    return out


def verify_snapshot_models():
    snap=Path('/mnt/data/test_esonde_runtime/Dmodel_eSond_v0/examples/models')
    idx=json.loads((snap/'MODELS_INDEX.json').read_text())
    records=[]
    for item in idx['models']:
        p=snap/item['file']; actual=sha256(p)
        if actual!=item['sha256']: raise RuntimeError(f'SHA mismatch snapshot {p.name}')
        m=ESonde.load(p)
        inf=m.inspect()
        if inf['n_features']!=item['n_features'] or inf['n_probes']!=item['n_probes']:
            raise RuntimeError(f'Snapshot metadata mismatch {p.name}')
        # Use one observation from a stored demo only where compatible dimensionality is known.
        x= [[0.0]*item['n_features']]
        pred=m.predict(x)
        if not pred: raise RuntimeError(f'No prediction from snapshot {p.name}')
        records.append({'file':item['file'],'sha256':actual,'task':item['task'],'n_features':item['n_features'],
                        'n_probes':item['n_probes'],'inspect':'PASS','inference':'PASS'})
    (OUT/'snapshot_integrity_and_inference.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    return records


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--datasets',default='all')
    ap.add_argument('--seeds',default=','.join(map(str,SEEDS)))
    ap.add_argument('--append',action='store_true')
    ap.add_argument('--verify-snapshots',action='store_true')
    args=ap.parse_args()
    runfile=OUT/'benchmark_runs.jsonl'
    if not args.append and runfile.exists(): runfile.unlink()
    allrows=[json.loads(line) for line in runfile.read_text().splitlines() if line.strip()] if args.append and runfile.exists() else []
    datasets=make_datasets()
    selected_names=list(datasets) if args.datasets=='all' else [x for x in args.datasets.split(',') if x]
    selected_seeds=[int(x) for x in args.seeds.split(',') if x]
    registry=[]
    for name,data in datasets.items():
        X,y,task,desc=data
        registry.append({'name':name,'description':desc,'task':task,'n':len(y),'d':X.shape[1],
            'X_sha256':hashlib.sha256(np.ascontiguousarray(X).tobytes()).hexdigest(),
            'y_sha256':hashlib.sha256(np.ascontiguousarray(y).tobytes()).hexdigest()})
    (OUT/'dataset_manifest.json').write_text(json.dumps(registry,indent=2),encoding='utf-8')
    for name in selected_names:
        if name not in datasets: raise ValueError(f'Unknown dataset: {name}')
        data=datasets[name]
        for seed in selected_seeds:
            print(f'RUN {name} seed={seed}',flush=True)
            rows=run_one(name,data,seed); allrows.extend(rows)
    summary=paired_summary(allrows)
    (OUT/'benchmark_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    import csv
    with (OUT/'benchmark_summary.csv').open('w',newline='',encoding='utf-8') as f:
        if summary:
            fields=sorted({k for row in summary for k in row}); w=csv.DictWriter(f,fieldnames=fields,extrasaction='raise'); w.writeheader(); w.writerows(summary)
    snaps=verify_snapshot_models() if args.verify_snapshots else []
    meta={'python':platform.python_version(),'platform':platform.platform(),'numpy':np.__version__,
          'scipy':__import__('scipy').__version__,'sklearn':__import__('sklearn').__version__,
          'seeds':selected_seeds,'datasets':selected_names,'max_epochs':MAX_EPOCHS,'patience':PATIENCE,'n_probes':N_PROBES,'batch_size':BATCH_SIZE,
          'models_per_split':['eSonde_local','MLP_param_matched','RBF_SVM','ExtraTrees'],
          'split':'60% train / 20% validation / 20% untouched test','dataset_count':len(datasets),
          'split_count':len(datasets)*len(SEEDS),'run_count':len(allrows),'snapshot_count':len(snaps)}
    (OUT/'benchmark_environment.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(json.dumps(meta,indent=2))

if __name__=='__main__': main()
