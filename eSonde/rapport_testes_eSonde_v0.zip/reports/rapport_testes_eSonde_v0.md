# Rapport de tests eSonde_v0 — 08 novembre 2026

## Description et périmètre
Campagne principale : 5 jeux × 10 graines × 4 modèles = **200 ajustements**. Campagne hybride : 5 jeux × 5 graines × 2 modèles = **50 ajustements**. Stress interpolation/extrapolation : 10 graines × 4 modèles × 2 régimes = **80 lignes de score** correspondant à 40 ajustements.

## Architecture et comparateurs
- eSonde local : 16 sondes, famille `local`.
- eSonde hybride : 16 sondes, familles `local`, `coverage`, `interaction`.
- MLP une couche cachée ReLU, largeur choisie pour apparier le compte de paramètres entraînables.
- SVR/SVC à noyau RBF.
- ExtraTrees (250 arbres).

## Résultats principaux

| Jeu | eSonde local | MLP apparié | SVM RBF | ExtraTrees |
|---|---:|---:|---:|---:|
| Diabetes RMSE ↓ | 55.287 | 55.936 | 65.581 | 56.692 |
| Friedman-1 RMSE ↓ | 1.757 | 2.102 | 2.125 | 2.304 |
| Breast Cancer F1 ↑ | 0.9704 | 0.9800 | 0.9715 | 0.9646 |
| Two-Moons F1 ↑ | 0.9283 | 0.8996 | 0.9229 | 0.9300 |
| 40D bruité F1 ↑ | 0.8795 | 0.8879 | 0.9037 | 0.8950 |

## Stress d'extrapolation

| Modèle | RMSE interpolation | RMSE extrapolation |
|---|---:|---:|
| eSonde local | 0.003916 | 1.373198 |
| MLP apparié | 0.104029 | 2.685930 |
| SVR RBF | 0.070217 | 1.354270 |
| ExtraTrees | 0.024011 | 1.472680 |

## Vérifications
- 75 modèles eSonde entraînés, fichiers présents et SHA-256 conformes.
- 75/75 audits de rechargement ; écart de métriques maximal = 0.
- 9/9 snapshots de démonstration intacts et prédiction de fumée réussie.
- Tests runtime : 15/15.
- Audit indépendant : PASS, zéro erreur.

## Interprétation
eSonde est performant sur certains cas (Friedman-1, Two-Moons) et n'est pas le meilleur sur d'autres (Breast Cancer, 40D). Le coût d'entraînement et la latence sont significativement supérieurs au MLP compact dans cette implémentation. L'extrapolation reste un point faible par rapport au meilleur comparateur du stress 1D (SVR RBF).

## Limites
Cinq jeux seulement, répétitions de partitions non indépendantes, hyperparamètres fixés (pas de HPO imbriquée), comparabilité paramétrique directe limitée au MLP. Les intervalles sont descriptifs, sans correction de multiplicité.

## Statut
Campagnes et contrôles complets au regard du protocole livré ; aucune supériorité universelle revendiquée.
