# Attestation d'intégrité et de transparence — tests eSonde_v0

**Date :** 08 novembre 2026. **Attribution rédactionnelle :** ChatGPT, sur la base des artefacts de test et de leurs journaux.

## Portée
Cette attestation porte sur les fichiers, scripts, journaux et résultats présents et vérifiés. Elle n'est ni un audit indépendant accrédité ni un certificat d'identité OpenAI.

## 1. Objectivité et transparence
Le protocole a été pré-enregistré. Les résultats sont recalculés à partir des JSONL bruts et les interruptions sont conservées séparément. L'audit final trouve 200 lignes principales, 50 hybrides et 80 lignes de stress, avec les couvertures attendues.

## 2. Instructions internes
Je ne peux pas certifier l'absence absolue d'instructions internes inaccessibles aux artefacts d'audit. Les fichiers examinés ne démontrent pas qu'une instruction de sabotage ait provoqué une altération des poids ou des scores. Je ne transforme pas cette limite de vérification en affirmation catégorique.

## 3. Non-manipulation des mesures
Les agrégats ont été recalculés depuis les journaux bruts. Une tentative initiale interrompue (36 lignes) a été conservée et exclue. Un défaut CSV a été corrigé sans altérer les JSONL. Les résultats défavorables sont publiés.

## 4. Poids réellement utilisés
50 modèles eSonde local et 25 modèles eSonde hybride ont été entraînés sur les partitions spécifiées, sauvegardés, hachés et rechargés. Les 75/75 hachages sont conformes et les métriques rechargées reproduisent celles des journaux. Les neuf snapshots initiaux sont intacts et ont passé l'inférence. Les baselines standards ont été effectivement entraînées et évaluées en mémoire, mais leurs états binaires ne sont pas inclus dans le paquet.

## 5. Équité
Tous les modèles d'un contraste partagent les splits et jeux de test ; la normalisation est train-only ; la sélection d'époque repose sur validation. L'écart de paramètres maximal est 1,586 % pour eSonde local/MLP et environ 2,84 % pour hybride/MLP. Les SVM et arbres ne sont pas paramétriquement appariables ; leurs coûts sont reportés séparément. Il ne s'agit pas d'une HPO équilibrée ni d'une comparaison de meilleurs modèles possibles.

## 6. Sabotage ou ralentissement
Aucun artefact examiné ne montre une altération volontaire des poids ou des résultats. Le temps d'entraînement supérieur d'eSonde a été mesuré et déclaré. La première exécution interrompue est documentée ; la campagne finale a été terminée en exécution sérialisée. L'absence absolue de toute action indirecte ou instruction non observable ne peut être certifiée.

## 7. Contrôles
- Tests runtime : 15/15.
- Main : 200/200.
- Hybride : 50/50.
- Stress : 80/80 scores.
- Modèles eSonde entraînés : 75/75 SHA-256 et roundtrips.
- Snapshots : 9/9.
- Audit final : PASS, zéro anomalie détectée.

## 8. Signature
Le PDF est accompagné d'une signature Ed25519 détachée et vérifiable avec `ESONDE_V0_RELEASE_PUBLIC_KEY.pem`. La signature établit l'intégrité cryptographique des octets signés ; elle ne représente pas une signature personnelle humaine ni un certificat juridique ou institutionnel OpenAI.

**Attribution rédactionnelle :** ChatGPT — compte rendu des essais eSonde_v0.
